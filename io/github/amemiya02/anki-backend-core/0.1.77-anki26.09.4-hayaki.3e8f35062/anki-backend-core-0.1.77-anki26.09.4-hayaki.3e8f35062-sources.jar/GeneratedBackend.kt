/* Auto-generated from the .proto files in AnkiDroidBackend. */

@file:Suppress("NAME_SHADOWING", "UNUSED_VARIABLE")
        
package anki.backend;

import com.google.protobuf.InvalidProtocolBufferException;

import net.ankiweb.rsdroid.BackendException;

public abstract class GeneratedBackend {

    @Throws(BackendException::class)
    protected abstract fun runMethodRaw(service: Int, method: Int, input: ByteArray): ByteArray;

    fun syncMediaRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 0, input)
    }

    open fun syncMedia(input: anki.sync.SyncAuth): Unit {
        val outputData = syncMediaRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun abortMediaSyncRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 1, input)
    }

    open fun abortMediaSync(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = abortMediaSyncRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Can be used by the frontend to detect an active sync. If the sync aborted
 with an error, the next call to this method will return the error. */
    fun mediaSyncStatusRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 2, input)
    }
/** Can be used by the frontend to detect an active sync. If the sync aborted
 with an error, the next call to this method will return the error. */

    open fun mediaSyncStatus(): anki.sync.MediaSyncStatusResponse {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = mediaSyncStatusRaw(input.toByteArray())
        val output = anki.sync.MediaSyncStatusResponse.parseFrom(outputData)
        return output
    }

    fun syncLoginRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 3, input)
    }

    open fun syncLogin(input: anki.sync.SyncLoginRequest): anki.sync.SyncAuth {
        val outputData = syncLoginRaw(input.toByteArray())
        val output = anki.sync.SyncAuth.parseFrom(outputData)
        return output
    }

    fun syncStatusRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 4, input)
    }

    open fun syncStatus(input: anki.sync.SyncAuth): anki.sync.SyncStatusResponse {
        val outputData = syncStatusRaw(input.toByteArray())
        val output = anki.sync.SyncStatusResponse.parseFrom(outputData)
        return output
    }

    fun syncCollectionRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 5, input)
    }

    open fun syncCollection(auth: anki.sync.SyncAuth, syncMedia: Boolean): anki.sync.SyncCollectionResponse {
        val builder = anki.sync.SyncCollectionRequest.newBuilder()
        builder.setAuth(auth)
        builder.setSyncMedia(syncMedia)
        val input = builder.build() 
        val outputData = syncCollectionRaw(input.toByteArray())
        val output = anki.sync.SyncCollectionResponse.parseFrom(outputData)
        return output
    }

    fun fullUploadOrDownloadRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 6, input)
    }

    open fun fullUploadOrDownload(input: anki.sync.FullUploadOrDownloadRequest): Unit {
        val outputData = fullUploadOrDownloadRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun abortSyncRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 7, input)
    }

    open fun abortSync(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = abortSyncRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun setCustomCertificateRaw(input: ByteArray): ByteArray {
        return runMethodRaw(1, 8, input)
    }

    open fun setCustomCertificate(`val`: String): Boolean {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = setCustomCertificateRaw(input.toByteArray())
        val output = anki.generic.Bool.parseFrom(outputData)
        return output.`val`
    }

    fun openCollectionRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 0, input)
    }

    open fun openCollection(collectionPath: String, mediaFolderPath: String, mediaDbPath: String): Unit {
        val builder = anki.collection.OpenCollectionRequest.newBuilder()
        builder.setCollectionPath(collectionPath)
        builder.setMediaFolderPath(mediaFolderPath)
        builder.setMediaDbPath(mediaDbPath)
        val input = builder.build() 
        val outputData = openCollectionRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun closeCollectionRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 1, input)
    }

    open fun closeCollection(downgradeToSchema11: Boolean): Unit {
        val builder = anki.collection.CloseCollectionRequest.newBuilder()
        builder.setDowngradeToSchema11(downgradeToSchema11)
        val input = builder.build() 
        val outputData = closeCollectionRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Create a no-media backup. Caller must ensure there is no active
 transaction. Unlike a collection export, does not require reopening the DB,
 as there is no downgrade step.
 Returns false if it's not time to make a backup yet. */
    fun createBackupRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 2, input)
    }
/** Create a no-media backup. Caller must ensure there is no active
 transaction. Unlike a collection export, does not require reopening the DB,
 as there is no downgrade step.
 Returns false if it's not time to make a backup yet. */

    open fun createBackup(backupFolder: String, force: Boolean, waitForCompletion: Boolean): Boolean {
        val builder = anki.collection.CreateBackupRequest.newBuilder()
        builder.setBackupFolder(backupFolder)
        builder.setForce(force)
        builder.setWaitForCompletion(waitForCompletion)
        val input = builder.build() 
        val outputData = createBackupRaw(input.toByteArray())
        val output = anki.generic.Bool.parseFrom(outputData)
        return output.`val`
    }

/** If a backup is running, wait for it to complete. Will return an error
 if the backup encountered an error. */
    fun awaitBackupCompletionRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 3, input)
    }
/** If a backup is running, wait for it to complete. Will return an error
 if the backup encountered an error. */

    open fun awaitBackupCompletion(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = awaitBackupCompletionRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun latestProgressRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 4, input)
    }

    open fun latestProgress(): anki.collection.Progress {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = latestProgressRaw(input.toByteArray())
        val output = anki.collection.Progress.parseFrom(outputData)
        return output
    }

    fun setWantsAbortRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 5, input)
    }

    open fun setWantsAbort(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = setWantsAbortRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun checkDatabaseRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 6, input)
    }

    open fun checkDatabase(): List<String> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = checkDatabaseRaw(input.toByteArray())
        val output = anki.collection.CheckDatabaseResponse.parseFrom(outputData)
        return output.problemsList
    }

    fun getUndoStatusRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 7, input)
    }

    open fun getUndoStatus(): anki.collection.UndoStatus {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getUndoStatusRaw(input.toByteArray())
        val output = anki.collection.UndoStatus.parseFrom(outputData)
        return output
    }

    fun undoRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 8, input)
    }

    open fun undo(): anki.collection.OpChangesAfterUndo {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = undoRaw(input.toByteArray())
        val output = anki.collection.OpChangesAfterUndo.parseFrom(outputData)
        return output
    }

    fun redoRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 9, input)
    }

    open fun redo(): anki.collection.OpChangesAfterUndo {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = redoRaw(input.toByteArray())
        val output = anki.collection.OpChangesAfterUndo.parseFrom(outputData)
        return output
    }

    fun addCustomUndoEntryRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 10, input)
    }

    open fun addCustomUndoEntry(`val`: String): Int {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = addCustomUndoEntryRaw(input.toByteArray())
        val output = anki.generic.UInt32.parseFrom(outputData)
        return output.`val`
    }

    fun mergeUndoEntriesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 11, input)
    }

    open fun mergeUndoEntries(`val`: Int): anki.collection.OpChanges {
        val builder = anki.generic.UInt32.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = mergeUndoEntriesRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun setLoadBalancerEnabledRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 14, input)
    }

    open fun setLoadBalancerEnabled(`val`: Boolean): anki.collection.OpChanges {
        val builder = anki.generic.Bool.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = setLoadBalancerEnabledRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getCustomColoursRaw(input: ByteArray): ByteArray {
        return runMethodRaw(3, 15, input)
    }

    open fun getCustomColours(): List<String> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getCustomColoursRaw(input.toByteArray())
        val output = anki.collection.GetCustomColoursResponse.parseFrom(outputData)
        return output.coloursList
    }

    fun getCardRaw(input: ByteArray): ByteArray {
        return runMethodRaw(5, 0, input)
    }

    open fun getCard(cid: Long): anki.cards.Card {
        val builder = anki.cards.CardId.newBuilder()
        builder.setCid(cid)
        val input = builder.build() 
        val outputData = getCardRaw(input.toByteArray())
        val output = anki.cards.Card.parseFrom(outputData)
        return output
    }

    fun updateCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(5, 1, input)
    }

    open fun updateCards(cards: Iterable<anki.cards.Card>, skipUndoEntry: Boolean): anki.collection.OpChanges {
        val builder = anki.cards.UpdateCardsRequest.newBuilder()
        builder.addAllCards(cards)
        builder.setSkipUndoEntry(skipUndoEntry)
        val input = builder.build() 
        val outputData = updateCardsRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun removeCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(5, 2, input)
    }

    open fun removeCards(cardIds: Iterable<Long>): anki.collection.OpChangesWithCount {
        val builder = anki.cards.RemoveCardsRequest.newBuilder()
        builder.addAllCardIds(cardIds)
        val input = builder.build() 
        val outputData = removeCardsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun setDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(5, 3, input)
    }

    open fun setDeck(cardIds: Iterable<Long>, deckId: Long): anki.collection.OpChangesWithCount {
        val builder = anki.cards.SetDeckRequest.newBuilder()
        builder.addAllCardIds(cardIds)
        builder.setDeckId(deckId)
        val input = builder.build() 
        val outputData = setDeckRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun setFlagRaw(input: ByteArray): ByteArray {
        return runMethodRaw(5, 4, input)
    }

    open fun setFlag(cardIds: Iterable<Long>, flag: Int): anki.collection.OpChangesWithCount {
        val builder = anki.cards.SetFlagRequest.newBuilder()
        builder.addAllCardIds(cardIds)
        builder.setFlag(flag)
        val input = builder.build() 
        val outputData = setFlagRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun newDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 0, input)
    }

    open fun newDeck(): anki.decks.Deck {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = newDeckRaw(input.toByteArray())
        val output = anki.decks.Deck.parseFrom(outputData)
        return output
    }

    fun addDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 1, input)
    }

    open fun addDeck(input: anki.decks.Deck): anki.collection.OpChangesWithId {
        val outputData = addDeckRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithId.parseFrom(outputData)
        return output
    }

    fun addDeckLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 2, input)
    }

    open fun addDeckLegacy(json: com.google.protobuf.ByteString): anki.collection.OpChangesWithId {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = addDeckLegacyRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithId.parseFrom(outputData)
        return output
    }

    fun addOrUpdateDeckLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 3, input)
    }

    open fun addOrUpdateDeckLegacy(deck: com.google.protobuf.ByteString, preserveUsnAndMtime: Boolean): Long {
        val builder = anki.decks.AddOrUpdateDeckLegacyRequest.newBuilder()
        builder.setDeck(deck)
        builder.setPreserveUsnAndMtime(preserveUsnAndMtime)
        val input = builder.build() 
        val outputData = addOrUpdateDeckLegacyRaw(input.toByteArray())
        val output = anki.decks.DeckId.parseFrom(outputData)
        return output.did
    }

    fun deckTreeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 4, input)
    }

    open fun deckTree(now: Long): anki.decks.DeckTreeNode {
        val builder = anki.decks.DeckTreeRequest.newBuilder()
        builder.setNow(now)
        val input = builder.build() 
        val outputData = deckTreeRaw(input.toByteArray())
        val output = anki.decks.DeckTreeNode.parseFrom(outputData)
        return output
    }

    fun deckTreeLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 5, input)
    }

    open fun deckTreeLegacy(): com.google.protobuf.ByteString {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = deckTreeLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getAllDecksLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 6, input)
    }

    open fun getAllDecksLegacy(): com.google.protobuf.ByteString {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getAllDecksLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getDeckIdByNameRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 7, input)
    }

    open fun getDeckIdByName(`val`: String): Long {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = getDeckIdByNameRaw(input.toByteArray())
        val output = anki.decks.DeckId.parseFrom(outputData)
        return output.did
    }

    fun getDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 8, input)
    }

    open fun getDeck(did: Long): anki.decks.Deck {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = getDeckRaw(input.toByteArray())
        val output = anki.decks.Deck.parseFrom(outputData)
        return output
    }

    fun updateDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 9, input)
    }

    open fun updateDeck(input: anki.decks.Deck): anki.collection.OpChanges {
        val outputData = updateDeckRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun updateDeckLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 10, input)
    }

    open fun updateDeckLegacy(json: com.google.protobuf.ByteString): anki.collection.OpChanges {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = updateDeckLegacyRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun setDeckCollapsedRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 11, input)
    }

    open fun setDeckCollapsed(deckId: Long, collapsed: Boolean, scope: anki.decks.SetDeckCollapsedRequest.Scope): anki.collection.OpChanges {
        val builder = anki.decks.SetDeckCollapsedRequest.newBuilder()
        builder.setDeckId(deckId)
        builder.setCollapsed(collapsed)
        builder.setScope(scope)
        val input = builder.build() 
        val outputData = setDeckCollapsedRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getDeckLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 12, input)
    }

    open fun getDeckLegacy(did: Long): com.google.protobuf.ByteString {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = getDeckLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getDeckNamesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 13, input)
    }

    open fun getDeckNames(skipEmptyDefault: Boolean, includeFiltered: Boolean): List<anki.decks.DeckNameId> {
        val builder = anki.decks.GetDeckNamesRequest.newBuilder()
        builder.setSkipEmptyDefault(skipEmptyDefault)
        builder.setIncludeFiltered(includeFiltered)
        val input = builder.build() 
        val outputData = getDeckNamesRaw(input.toByteArray())
        val output = anki.decks.DeckNames.parseFrom(outputData)
        return output.entriesList
    }

    fun getDeckAndChildNamesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 14, input)
    }

    open fun getDeckAndChildNames(did: Long): List<anki.decks.DeckNameId> {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = getDeckAndChildNamesRaw(input.toByteArray())
        val output = anki.decks.DeckNames.parseFrom(outputData)
        return output.entriesList
    }

    fun newDeckLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 15, input)
    }

    open fun newDeckLegacy(`val`: Boolean): com.google.protobuf.ByteString {
        val builder = anki.generic.Bool.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = newDeckLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun removeDecksRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 16, input)
    }

    open fun removeDecks(dids: Iterable<Long>): anki.collection.OpChangesWithCount {
        val builder = anki.decks.DeckIds.newBuilder()
        builder.addAllDids(dids)
        val input = builder.build() 
        val outputData = removeDecksRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun reparentDecksRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 17, input)
    }

    open fun reparentDecks(deckIds: Iterable<Long>, newParent: Long): anki.collection.OpChangesWithCount {
        val builder = anki.decks.ReparentDecksRequest.newBuilder()
        builder.addAllDeckIds(deckIds)
        builder.setNewParent(newParent)
        val input = builder.build() 
        val outputData = reparentDecksRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun renameDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 18, input)
    }

    open fun renameDeck(deckId: Long, newName: String): anki.collection.OpChanges {
        val builder = anki.decks.RenameDeckRequest.newBuilder()
        builder.setDeckId(deckId)
        builder.setNewName(newName)
        val input = builder.build() 
        val outputData = renameDeckRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getOrCreateFilteredDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 19, input)
    }

    open fun getOrCreateFilteredDeck(did: Long): anki.decks.FilteredDeckForUpdate {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = getOrCreateFilteredDeckRaw(input.toByteArray())
        val output = anki.decks.FilteredDeckForUpdate.parseFrom(outputData)
        return output
    }

    fun addOrUpdateFilteredDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 20, input)
    }

    open fun addOrUpdateFilteredDeck(input: anki.decks.FilteredDeckForUpdate): anki.collection.OpChangesWithId {
        val outputData = addOrUpdateFilteredDeckRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithId.parseFrom(outputData)
        return output
    }

    fun filteredDeckOrderLabelsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 21, input)
    }

    open fun filteredDeckOrderLabels(): List<String> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = filteredDeckOrderLabelsRaw(input.toByteArray())
        val output = anki.generic.StringList.parseFrom(outputData)
        return output.valsList
    }

    fun setCurrentDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 22, input)
    }

    open fun setCurrentDeck(did: Long): anki.collection.OpChanges {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = setCurrentDeckRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getCurrentDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(7, 23, input)
    }

    open fun getCurrentDeck(): anki.decks.Deck {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getCurrentDeckRaw(input.toByteArray())
        val output = anki.decks.Deck.parseFrom(outputData)
        return output
    }

    fun getConfigJsonRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 0, input)
    }

    open fun getConfigJson(`val`: String): com.google.protobuf.ByteString {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = getConfigJsonRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun setConfigJsonRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 1, input)
    }

    open fun setConfigJson(key: String, valueJson: com.google.protobuf.ByteString, undoable: Boolean): anki.collection.OpChanges {
        val builder = anki.config.SetConfigJsonRequest.newBuilder()
        builder.setKey(key)
        builder.setValueJson(valueJson)
        builder.setUndoable(undoable)
        val input = builder.build() 
        val outputData = setConfigJsonRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun setConfigJsonNoUndoRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 2, input)
    }

    open fun setConfigJsonNoUndo(key: String, valueJson: com.google.protobuf.ByteString, undoable: Boolean): Unit {
        val builder = anki.config.SetConfigJsonRequest.newBuilder()
        builder.setKey(key)
        builder.setValueJson(valueJson)
        builder.setUndoable(undoable)
        val input = builder.build() 
        val outputData = setConfigJsonNoUndoRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun removeConfigRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 3, input)
    }

    open fun removeConfig(`val`: String): anki.collection.OpChanges {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = removeConfigRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getAllConfigRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 4, input)
    }

    open fun getAllConfig(): com.google.protobuf.ByteString {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getAllConfigRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getConfigBoolRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 5, input)
    }

    open fun getConfigBool(key: anki.config.ConfigKey.Bool): Boolean {
        val builder = anki.config.GetConfigBoolRequest.newBuilder()
        builder.setKey(key)
        val input = builder.build() 
        val outputData = getConfigBoolRaw(input.toByteArray())
        val output = anki.generic.Bool.parseFrom(outputData)
        return output.`val`
    }

    fun setConfigBoolRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 6, input)
    }

    open fun setConfigBool(key: anki.config.ConfigKey.Bool, value: Boolean, undoable: Boolean): anki.collection.OpChanges {
        val builder = anki.config.SetConfigBoolRequest.newBuilder()
        builder.setKey(key)
        builder.setValue(value)
        builder.setUndoable(undoable)
        val input = builder.build() 
        val outputData = setConfigBoolRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getConfigStringRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 7, input)
    }

    open fun getConfigString(key: anki.config.ConfigKey.String): String {
        val builder = anki.config.GetConfigStringRequest.newBuilder()
        builder.setKey(key)
        val input = builder.build() 
        val outputData = getConfigStringRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun setConfigStringRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 8, input)
    }

    open fun setConfigString(key: anki.config.ConfigKey.String, value: String, undoable: Boolean): anki.collection.OpChanges {
        val builder = anki.config.SetConfigStringRequest.newBuilder()
        builder.setKey(key)
        builder.setValue(value)
        builder.setUndoable(undoable)
        val input = builder.build() 
        val outputData = setConfigStringRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getPreferencesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 9, input)
    }

    open fun getPreferences(): anki.config.Preferences {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getPreferencesRaw(input.toByteArray())
        val output = anki.config.Preferences.parseFrom(outputData)
        return output
    }

    fun setPreferencesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(9, 10, input)
    }

    open fun setPreferences(input: anki.config.Preferences): anki.collection.OpChanges {
        val outputData = setPreferencesRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun addOrUpdateDeckConfigLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 0, input)
    }

    open fun addOrUpdateDeckConfigLegacy(json: com.google.protobuf.ByteString): Long {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = addOrUpdateDeckConfigLegacyRaw(input.toByteArray())
        val output = anki.deck_config.DeckConfigId.parseFrom(outputData)
        return output.dcid
    }

    fun getDeckConfigRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 1, input)
    }

    open fun getDeckConfig(dcid: Long): anki.deck_config.DeckConfig {
        val builder = anki.deck_config.DeckConfigId.newBuilder()
        builder.setDcid(dcid)
        val input = builder.build() 
        val outputData = getDeckConfigRaw(input.toByteArray())
        val output = anki.deck_config.DeckConfig.parseFrom(outputData)
        return output
    }

    fun allDeckConfigLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 2, input)
    }

    open fun allDeckConfigLegacy(): com.google.protobuf.ByteString {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = allDeckConfigLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getDeckConfigLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 3, input)
    }

    open fun getDeckConfigLegacy(dcid: Long): com.google.protobuf.ByteString {
        val builder = anki.deck_config.DeckConfigId.newBuilder()
        builder.setDcid(dcid)
        val input = builder.build() 
        val outputData = getDeckConfigLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun newDeckConfigLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 4, input)
    }

    open fun newDeckConfigLegacy(): com.google.protobuf.ByteString {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = newDeckConfigLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun removeDeckConfigRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 5, input)
    }

    open fun removeDeckConfig(dcid: Long): Unit {
        val builder = anki.deck_config.DeckConfigId.newBuilder()
        builder.setDcid(dcid)
        val input = builder.build() 
        val outputData = removeDeckConfigRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun getDeckConfigsForUpdateRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 6, input)
    }

    open fun getDeckConfigsForUpdate(did: Long): anki.deck_config.DeckConfigsForUpdate {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = getDeckConfigsForUpdateRaw(input.toByteArray())
        val output = anki.deck_config.DeckConfigsForUpdate.parseFrom(outputData)
        return output
    }

    fun updateDeckConfigsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 7, input)
    }

    open fun updateDeckConfigs(targetDeckId: Long, configs: Iterable<anki.deck_config.DeckConfig>, removedConfigIds: Iterable<Long>, mode: anki.deck_config.UpdateDeckConfigsMode, cardStateCustomizer: String, limits: anki.deck_config.DeckConfigsForUpdate.CurrentDeck.Limits, newCardsIgnoreReviewLimit: Boolean, fsrs: Boolean, applyAllParentLimits: Boolean, fsrsReschedule: Boolean, fsrsHealthCheck: Boolean): anki.collection.OpChanges {
        val builder = anki.deck_config.UpdateDeckConfigsRequest.newBuilder()
        builder.setTargetDeckId(targetDeckId)
        builder.addAllConfigs(configs)
        builder.addAllRemovedConfigIds(removedConfigIds)
        builder.setMode(mode)
        builder.setCardStateCustomizer(cardStateCustomizer)
        builder.setLimits(limits)
        builder.setNewCardsIgnoreReviewLimit(newCardsIgnoreReviewLimit)
        builder.setFsrs(fsrs)
        builder.setApplyAllParentLimits(applyAllParentLimits)
        builder.setFsrsReschedule(fsrsReschedule)
        builder.setFsrsHealthCheck(fsrsHealthCheck)
        val input = builder.build() 
        val outputData = updateDeckConfigsRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getIgnoredBeforeCountRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 8, input)
    }

    open fun getIgnoredBeforeCount(ignoreRevlogsBeforeDate: String, search: String): anki.deck_config.GetIgnoredBeforeCountResponse {
        val builder = anki.deck_config.GetIgnoredBeforeCountRequest.newBuilder()
        builder.setIgnoreRevlogsBeforeDate(ignoreRevlogsBeforeDate)
        builder.setSearch(search)
        val input = builder.build() 
        val outputData = getIgnoredBeforeCountRaw(input.toByteArray())
        val output = anki.deck_config.GetIgnoredBeforeCountResponse.parseFrom(outputData)
        return output
    }

    fun getRetentionWorkloadRaw(input: ByteArray): ByteArray {
        return runMethodRaw(11, 9, input)
    }

    open fun getRetentionWorkload(w: Iterable<Float>, search: String): Map<Int,Float> {
        val builder = anki.deck_config.GetRetentionWorkloadRequest.newBuilder()
        builder.addAllW(w)
        builder.setSearch(search)
        val input = builder.build() 
        val outputData = getRetentionWorkloadRaw(input.toByteArray())
        val output = anki.deck_config.GetRetentionWorkloadResponse.parseFrom(outputData)
        return output.costs
    }

    fun computeFsrsParamsFromItemsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 0, input)
    }

    open fun computeFsrsParamsFromItems(items: Iterable<anki.scheduler.FsrsItem>): anki.scheduler.ComputeFsrsParamsResponse {
        val builder = anki.scheduler.ComputeFsrsParamsFromItemsRequest.newBuilder()
        builder.addAllItems(items)
        val input = builder.build() 
        val outputData = computeFsrsParamsFromItemsRaw(input.toByteArray())
        val output = anki.scheduler.ComputeFsrsParamsResponse.parseFrom(outputData)
        return output
    }

/** Generates parameters used for FSRS's scheduler benchmarks. */
    fun fsrsBenchmarkRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 1, input)
    }
/** Generates parameters used for FSRS's scheduler benchmarks. */

    open fun fsrsBenchmark(trainSet: Iterable<anki.scheduler.FsrsItem>): List<Float> {
        val builder = anki.scheduler.FsrsBenchmarkRequest.newBuilder()
        builder.addAllTrainSet(trainSet)
        val input = builder.build() 
        val outputData = fsrsBenchmarkRaw(input.toByteArray())
        val output = anki.scheduler.FsrsBenchmarkResponse.parseFrom(outputData)
        return output.paramsList
    }

/** Used for exporting revlogs for algorithm research. */
    fun exportDatasetRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 2, input)
    }
/** Used for exporting revlogs for algorithm research. */

    open fun exportDataset(minEntries: Int, targetPath: String): Unit {
        val builder = anki.scheduler.ExportDatasetRequest.newBuilder()
        builder.setMinEntries(minEntries)
        builder.setTargetPath(targetPath)
        val input = builder.build() 
        val outputData = exportDatasetRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun getQueuedCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 3, input)
    }

    open fun getQueuedCards(fetchLimit: Int, intradayLearningOnly: Boolean): anki.scheduler.QueuedCards {
        val builder = anki.scheduler.GetQueuedCardsRequest.newBuilder()
        builder.setFetchLimit(fetchLimit)
        builder.setIntradayLearningOnly(intradayLearningOnly)
        val input = builder.build() 
        val outputData = getQueuedCardsRaw(input.toByteArray())
        val output = anki.scheduler.QueuedCards.parseFrom(outputData)
        return output
    }

    fun answerCardRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 4, input)
    }

    open fun answerCard(input: anki.scheduler.CardAnswer): anki.collection.OpChanges {
        val outputData = answerCardRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun schedTimingTodayRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 5, input)
    }

    open fun schedTimingToday(): anki.scheduler.SchedTimingTodayResponse {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = schedTimingTodayRaw(input.toByteArray())
        val output = anki.scheduler.SchedTimingTodayResponse.parseFrom(outputData)
        return output
    }

    fun studiedTodayRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 6, input)
    }

    open fun studiedToday(): String {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = studiedTodayRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun studiedTodayMessageRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 7, input)
    }

    open fun studiedTodayMessage(cards: Int, seconds: Double): String {
        val builder = anki.scheduler.StudiedTodayMessageRequest.newBuilder()
        builder.setCards(cards)
        builder.setSeconds(seconds)
        val input = builder.build() 
        val outputData = studiedTodayMessageRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun updateStatsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 8, input)
    }

    open fun updateStats(deckId: Long, newDelta: Int, reviewDelta: Int, millisecondDelta: Int): Unit {
        val builder = anki.scheduler.UpdateStatsRequest.newBuilder()
        builder.setDeckId(deckId)
        builder.setNewDelta(newDelta)
        builder.setReviewDelta(reviewDelta)
        builder.setMillisecondDelta(millisecondDelta)
        val input = builder.build() 
        val outputData = updateStatsRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun extendLimitsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 9, input)
    }

    open fun extendLimits(deckId: Long, newDelta: Int, reviewDelta: Int): Unit {
        val builder = anki.scheduler.ExtendLimitsRequest.newBuilder()
        builder.setDeckId(deckId)
        builder.setNewDelta(newDelta)
        builder.setReviewDelta(reviewDelta)
        val input = builder.build() 
        val outputData = extendLimitsRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun countsForDeckTodayRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 10, input)
    }

    open fun countsForDeckToday(did: Long): anki.scheduler.CountsForDeckTodayResponse {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = countsForDeckTodayRaw(input.toByteArray())
        val output = anki.scheduler.CountsForDeckTodayResponse.parseFrom(outputData)
        return output
    }

    fun congratsInfoRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 11, input)
    }

    open fun congratsInfo(): anki.scheduler.CongratsInfoResponse {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = congratsInfoRaw(input.toByteArray())
        val output = anki.scheduler.CongratsInfoResponse.parseFrom(outputData)
        return output
    }

    fun restoreBuriedAndSuspendedCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 12, input)
    }

    open fun restoreBuriedAndSuspendedCards(cids: Iterable<Long>): anki.collection.OpChanges {
        val builder = anki.cards.CardIds.newBuilder()
        builder.addAllCids(cids)
        val input = builder.build() 
        val outputData = restoreBuriedAndSuspendedCardsRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun unburyDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 13, input)
    }

    open fun unburyDeck(deckId: Long, mode: anki.scheduler.UnburyDeckRequest.Mode): anki.collection.OpChanges {
        val builder = anki.scheduler.UnburyDeckRequest.newBuilder()
        builder.setDeckId(deckId)
        builder.setMode(mode)
        val input = builder.build() 
        val outputData = unburyDeckRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun buryOrSuspendCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 14, input)
    }

    open fun buryOrSuspendCards(cardIds: Iterable<Long>, noteIds: Iterable<Long>, mode: anki.scheduler.BuryOrSuspendCardsRequest.Mode): anki.collection.OpChangesWithCount {
        val builder = anki.scheduler.BuryOrSuspendCardsRequest.newBuilder()
        builder.addAllCardIds(cardIds)
        builder.addAllNoteIds(noteIds)
        builder.setMode(mode)
        val input = builder.build() 
        val outputData = buryOrSuspendCardsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun emptyFilteredDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 15, input)
    }

    open fun emptyFilteredDeck(did: Long): anki.collection.OpChanges {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = emptyFilteredDeckRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun rebuildFilteredDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 16, input)
    }

    open fun rebuildFilteredDeck(did: Long): anki.collection.OpChangesWithCount {
        val builder = anki.decks.DeckId.newBuilder()
        builder.setDid(did)
        val input = builder.build() 
        val outputData = rebuildFilteredDeckRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun scheduleCardsAsNewRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 17, input)
    }

    open fun scheduleCardsAsNew(input: anki.scheduler.ScheduleCardsAsNewRequest): anki.collection.OpChanges {
        val outputData = scheduleCardsAsNewRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun scheduleCardsAsNewDefaultsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 18, input)
    }

    open fun scheduleCardsAsNewDefaults(context: anki.scheduler.ScheduleCardsAsNewRequest.Context): anki.scheduler.ScheduleCardsAsNewDefaultsResponse {
        val builder = anki.scheduler.ScheduleCardsAsNewDefaultsRequest.newBuilder()
        builder.setContext(context)
        val input = builder.build() 
        val outputData = scheduleCardsAsNewDefaultsRaw(input.toByteArray())
        val output = anki.scheduler.ScheduleCardsAsNewDefaultsResponse.parseFrom(outputData)
        return output
    }

    fun setDueDateRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 19, input)
    }

    open fun setDueDate(cardIds: Iterable<Long>, days: String, configKey: anki.config.OptionalStringConfigKey): anki.collection.OpChanges {
        val builder = anki.scheduler.SetDueDateRequest.newBuilder()
        builder.addAllCardIds(cardIds)
        builder.setDays(days)
        builder.setConfigKey(configKey)
        val input = builder.build() 
        val outputData = setDueDateRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun gradeNowRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 20, input)
    }

    open fun gradeNow(cardIds: Iterable<Long>, rating: anki.scheduler.CardAnswer.Rating): anki.collection.OpChanges {
        val builder = anki.scheduler.GradeNowRequest.newBuilder()
        builder.addAllCardIds(cardIds)
        builder.setRating(rating)
        val input = builder.build() 
        val outputData = gradeNowRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun sortCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 21, input)
    }

    open fun sortCards(cardIds: Iterable<Long>, startingFrom: Int, stepSize: Int, randomize: Boolean, shiftExisting: Boolean): anki.collection.OpChangesWithCount {
        val builder = anki.scheduler.SortCardsRequest.newBuilder()
        builder.addAllCardIds(cardIds)
        builder.setStartingFrom(startingFrom)
        builder.setStepSize(stepSize)
        builder.setRandomize(randomize)
        builder.setShiftExisting(shiftExisting)
        val input = builder.build() 
        val outputData = sortCardsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun sortDeckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 22, input)
    }

    open fun sortDeck(deckId: Long, randomize: Boolean): anki.collection.OpChangesWithCount {
        val builder = anki.scheduler.SortDeckRequest.newBuilder()
        builder.setDeckId(deckId)
        builder.setRandomize(randomize)
        val input = builder.build() 
        val outputData = sortDeckRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun getSchedulingStatesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 23, input)
    }

    open fun getSchedulingStates(cid: Long): anki.scheduler.SchedulingStates {
        val builder = anki.cards.CardId.newBuilder()
        builder.setCid(cid)
        val input = builder.build() 
        val outputData = getSchedulingStatesRaw(input.toByteArray())
        val output = anki.scheduler.SchedulingStates.parseFrom(outputData)
        return output
    }

    fun describeNextStatesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 24, input)
    }

    open fun describeNextStates(input: anki.scheduler.SchedulingStates): List<String> {
        val outputData = describeNextStatesRaw(input.toByteArray())
        val output = anki.generic.StringList.parseFrom(outputData)
        return output.valsList
    }

    fun stateIsLeechRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 25, input)
    }

    open fun stateIsLeech(input: anki.scheduler.SchedulingState): Boolean {
        val outputData = stateIsLeechRaw(input.toByteArray())
        val output = anki.generic.Bool.parseFrom(outputData)
        return output.`val`
    }

    fun upgradeSchedulerRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 26, input)
    }

    open fun upgradeScheduler(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = upgradeSchedulerRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun customStudyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 27, input)
    }

    open fun customStudy(input: anki.scheduler.CustomStudyRequest): anki.collection.OpChanges {
        val outputData = customStudyRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun customStudyDefaultsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 28, input)
    }

    open fun customStudyDefaults(deckId: Long): anki.scheduler.CustomStudyDefaultsResponse {
        val builder = anki.scheduler.CustomStudyDefaultsRequest.newBuilder()
        builder.setDeckId(deckId)
        val input = builder.build() 
        val outputData = customStudyDefaultsRaw(input.toByteArray())
        val output = anki.scheduler.CustomStudyDefaultsResponse.parseFrom(outputData)
        return output
    }

    fun repositionDefaultsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 29, input)
    }

    open fun repositionDefaults(): anki.scheduler.RepositionDefaultsResponse {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = repositionDefaultsRaw(input.toByteArray())
        val output = anki.scheduler.RepositionDefaultsResponse.parseFrom(outputData)
        return output
    }

    fun computeFsrsParamsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 30, input)
    }

    open fun computeFsrsParams(search: String, currentParams: Iterable<Float>, ignoreRevlogsBeforeMs: Long, numOfRelearningSteps: Int, healthCheck: Boolean): anki.scheduler.ComputeFsrsParamsResponse {
        val builder = anki.scheduler.ComputeFsrsParamsRequest.newBuilder()
        builder.setSearch(search)
        builder.addAllCurrentParams(currentParams)
        builder.setIgnoreRevlogsBeforeMs(ignoreRevlogsBeforeMs)
        builder.setNumOfRelearningSteps(numOfRelearningSteps)
        builder.setHealthCheck(healthCheck)
        val input = builder.build() 
        val outputData = computeFsrsParamsRaw(input.toByteArray())
        val output = anki.scheduler.ComputeFsrsParamsResponse.parseFrom(outputData)
        return output
    }

    fun getOptimalRetentionParametersRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 31, input)
    }

    open fun getOptimalRetentionParameters(search: String): anki.scheduler.GetOptimalRetentionParametersResponse {
        val builder = anki.scheduler.GetOptimalRetentionParametersRequest.newBuilder()
        builder.setSearch(search)
        val input = builder.build() 
        val outputData = getOptimalRetentionParametersRaw(input.toByteArray())
        val output = anki.scheduler.GetOptimalRetentionParametersResponse.parseFrom(outputData)
        return output
    }

    fun computeOptimalRetentionRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 32, input)
    }

    open fun computeOptimalRetention(input: anki.scheduler.SimulateFsrsReviewRequest): Float {
        val outputData = computeOptimalRetentionRaw(input.toByteArray())
        val output = anki.scheduler.ComputeOptimalRetentionResponse.parseFrom(outputData)
        return output.optimalRetention
    }

    fun simulateFsrsReviewRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 33, input)
    }

    open fun simulateFsrsReview(input: anki.scheduler.SimulateFsrsReviewRequest): anki.scheduler.SimulateFsrsReviewResponse {
        val outputData = simulateFsrsReviewRaw(input.toByteArray())
        val output = anki.scheduler.SimulateFsrsReviewResponse.parseFrom(outputData)
        return output
    }

    fun simulateFsrsWorkloadRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 34, input)
    }

    open fun simulateFsrsWorkload(input: anki.scheduler.SimulateFsrsReviewRequest): anki.scheduler.SimulateFsrsWorkloadResponse {
        val outputData = simulateFsrsWorkloadRaw(input.toByteArray())
        val output = anki.scheduler.SimulateFsrsWorkloadResponse.parseFrom(outputData)
        return output
    }

    fun evaluateParamsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 35, input)
    }

    open fun evaluateParams(search: String, ignoreRevlogsBeforeMs: Long, numOfRelearningSteps: Int): anki.scheduler.EvaluateParamsResponse {
        val builder = anki.scheduler.EvaluateParamsRequest.newBuilder()
        builder.setSearch(search)
        builder.setIgnoreRevlogsBeforeMs(ignoreRevlogsBeforeMs)
        builder.setNumOfRelearningSteps(numOfRelearningSteps)
        val input = builder.build() 
        val outputData = evaluateParamsRaw(input.toByteArray())
        val output = anki.scheduler.EvaluateParamsResponse.parseFrom(outputData)
        return output
    }

    fun evaluateParamsLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 36, input)
    }

    open fun evaluateParamsLegacy(params: Iterable<Float>, search: String, ignoreRevlogsBeforeMs: Long): anki.scheduler.EvaluateParamsResponse {
        val builder = anki.scheduler.EvaluateParamsLegacyRequest.newBuilder()
        builder.addAllParams(params)
        builder.setSearch(search)
        builder.setIgnoreRevlogsBeforeMs(ignoreRevlogsBeforeMs)
        val input = builder.build() 
        val outputData = evaluateParamsLegacyRaw(input.toByteArray())
        val output = anki.scheduler.EvaluateParamsResponse.parseFrom(outputData)
        return output
    }

    fun computeMemoryStateRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 37, input)
    }

    open fun computeMemoryState(cid: Long): anki.scheduler.ComputeMemoryStateResponse {
        val builder = anki.cards.CardId.newBuilder()
        builder.setCid(cid)
        val input = builder.build() 
        val outputData = computeMemoryStateRaw(input.toByteArray())
        val output = anki.scheduler.ComputeMemoryStateResponse.parseFrom(outputData)
        return output
    }

/** The number of days the calculated interval was fuzzed by on the previous
 review (if any). Utilized by the FSRS add-on. */
    fun fuzzDeltaRaw(input: ByteArray): ByteArray {
        return runMethodRaw(13, 38, input)
    }
/** The number of days the calculated interval was fuzzed by on the previous
 review (if any). Utilized by the FSRS add-on. */

    open fun fuzzDelta(cardId: Long, interval: Int): Int {
        val builder = anki.scheduler.FuzzDeltaRequest.newBuilder()
        builder.setCardId(cardId)
        builder.setInterval(interval)
        val input = builder.build() 
        val outputData = fuzzDeltaRaw(input.toByteArray())
        val output = anki.scheduler.FuzzDeltaResponse.parseFrom(outputData)
        return output.deltaDays
    }

    fun schedTimingTodayLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 0, input)
    }

    open fun schedTimingTodayLegacy(input: anki.ankidroid.SchedTimingTodayLegacyRequest): anki.scheduler.SchedTimingTodayResponse {
        val outputData = schedTimingTodayLegacyRaw(input.toByteArray())
        val output = anki.scheduler.SchedTimingTodayResponse.parseFrom(outputData)
        return output
    }

    fun localMinutesWestLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 1, input)
    }

    open fun localMinutesWestLegacy(`val`: Long): Int {
        val builder = anki.generic.Int64.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = localMinutesWestLegacyRaw(input.toByteArray())
        val output = anki.generic.Int32.parseFrom(outputData)
        return output.`val`
    }

    fun setPageSizeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 2, input)
    }

    open fun setPageSize(`val`: Long): Unit {
        val builder = anki.generic.Int64.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = setPageSizeRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun debugProduceErrorRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 3, input)
    }

    open fun debugProduceError(`val`: String): Unit {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = debugProduceErrorRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun runDbCommandRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 4, input)
    }

    open fun runDbCommand(json: com.google.protobuf.ByteString): com.google.protobuf.ByteString {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = runDbCommandRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun runDbCommandProtoRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 5, input)
    }

    open fun runDbCommandProto(json: com.google.protobuf.ByteString): anki.ankidroid.DbResponse {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = runDbCommandProtoRaw(input.toByteArray())
        val output = anki.ankidroid.DbResponse.parseFrom(outputData)
        return output
    }

    fun insertForIdRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 6, input)
    }

    open fun insertForId(json: com.google.protobuf.ByteString): Long {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = insertForIdRaw(input.toByteArray())
        val output = anki.generic.Int64.parseFrom(outputData)
        return output.`val`
    }

    fun runDbCommandForRowCountRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 7, input)
    }

    open fun runDbCommandForRowCount(json: com.google.protobuf.ByteString): Long {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = runDbCommandForRowCountRaw(input.toByteArray())
        val output = anki.generic.Int64.parseFrom(outputData)
        return output.`val`
    }

    fun flushAllQueriesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 8, input)
    }

    open fun flushAllQueries(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = flushAllQueriesRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun flushQueryRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 9, input)
    }

    open fun flushQuery(`val`: Int): Unit {
        val builder = anki.generic.Int32.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = flushQueryRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun getNextResultPageRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 10, input)
    }

    open fun getNextResultPage(sequence: Int, index: Long): anki.ankidroid.DbResponse {
        val builder = anki.ankidroid.GetNextResultPageRequest.newBuilder()
        builder.setSequence(sequence)
        builder.setIndex(index)
        val input = builder.build() 
        val outputData = getNextResultPageRaw(input.toByteArray())
        val output = anki.ankidroid.DbResponse.parseFrom(outputData)
        return output
    }

    fun getColumnNamesFromQueryRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 11, input)
    }

    open fun getColumnNamesFromQuery(`val`: String): List<String> {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = getColumnNamesFromQueryRaw(input.toByteArray())
        val output = anki.generic.StringList.parseFrom(outputData)
        return output.valsList
    }

    fun getActiveSequenceNumbersRaw(input: ByteArray): ByteArray {
        return runMethodRaw(15, 12, input)
    }

    open fun getActiveSequenceNumbers(): List<Int> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getActiveSequenceNumbersRaw(input.toByteArray())
        val output = anki.ankidroid.GetActiveSequenceNumbersResponse.parseFrom(outputData)
        return output.numbersList
    }

    fun ankihubLoginRaw(input: ByteArray): ByteArray {
        return runMethodRaw(17, 0, input)
    }

    open fun ankihubLogin(id: String, password: String): String {
        val builder = anki.ankihub.LoginRequest.newBuilder()
        builder.setId(id)
        builder.setPassword(password)
        val input = builder.build() 
        val outputData = ankihubLoginRaw(input.toByteArray())
        val output = anki.ankihub.LoginResponse.parseFrom(outputData)
        return output.token
    }

    fun ankihubLogoutRaw(input: ByteArray): ByteArray {
        return runMethodRaw(17, 1, input)
    }

    open fun ankihubLogout(token: String): Unit {
        val builder = anki.ankihub.LogoutRequest.newBuilder()
        builder.setToken(token)
        val input = builder.build() 
        val outputData = ankihubLogoutRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Fetch info on add-ons from AnkiWeb. A maximum of 25 can be queried at one
 time. If an add-on doesn't have a branch compatible with the provided
 version, that add-on will not be included in the returned list. */
    fun getAddonInfoRaw(input: ByteArray): ByteArray {
        return runMethodRaw(19, 0, input)
    }
/** Fetch info on add-ons from AnkiWeb. A maximum of 25 can be queried at one
 time. If an add-on doesn't have a branch compatible with the provided
 version, that add-on will not be included in the returned list. */

    open fun getAddonInfo(clientVersion: Int, addonIds: Iterable<Int>): List<anki.ankiweb.AddonInfo> {
        val builder = anki.ankiweb.GetAddonInfoRequest.newBuilder()
        builder.setClientVersion(clientVersion)
        builder.addAllAddonIds(addonIds)
        val input = builder.build() 
        val outputData = getAddonInfoRaw(input.toByteArray())
        val output = anki.ankiweb.GetAddonInfoResponse.parseFrom(outputData)
        return output.infoList
    }

    fun checkForUpdateRaw(input: ByteArray): ByteArray {
        return runMethodRaw(19, 1, input)
    }

    open fun checkForUpdate(version: Int, buildhash: String, os: String, installId: Long, lastMessageId: Int): anki.ankiweb.CheckForUpdateResponse {
        val builder = anki.ankiweb.CheckForUpdateRequest.newBuilder()
        builder.setVersion(version)
        builder.setBuildhash(buildhash)
        builder.setOs(os)
        builder.setInstallId(installId)
        builder.setLastMessageId(lastMessageId)
        val input = builder.build() 
        val outputData = checkForUpdateRaw(input.toByteArray())
        val output = anki.ankiweb.CheckForUpdateResponse.parseFrom(outputData)
        return output
    }

    fun helpPageLinkRaw(input: ByteArray): ByteArray {
        return runMethodRaw(21, 0, input)
    }

    open fun helpPageLink(page: anki.links.HelpPageLinkRequest.HelpPage): String {
        val builder = anki.links.HelpPageLinkRequest.newBuilder()
        builder.setPage(page)
        val input = builder.build() 
        val outputData = helpPageLinkRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun addNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 0, input)
    }

    open fun addNotetype(input: anki.notetypes.Notetype): anki.collection.OpChangesWithId {
        val outputData = addNotetypeRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithId.parseFrom(outputData)
        return output
    }

    fun updateNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 1, input)
    }

    open fun updateNotetype(input: anki.notetypes.Notetype): anki.collection.OpChanges {
        val outputData = updateNotetypeRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun addNotetypeLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 2, input)
    }

    open fun addNotetypeLegacy(json: com.google.protobuf.ByteString): anki.collection.OpChangesWithId {
        val builder = anki.generic.Json.newBuilder()
        builder.setJson(json)
        val input = builder.build() 
        val outputData = addNotetypeLegacyRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithId.parseFrom(outputData)
        return output
    }

    fun updateNotetypeLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 3, input)
    }

    open fun updateNotetypeLegacy(json: com.google.protobuf.ByteString, skipChecks: Boolean): anki.collection.OpChanges {
        val builder = anki.notetypes.UpdateNotetypeLegacyRequest.newBuilder()
        builder.setJson(json)
        builder.setSkipChecks(skipChecks)
        val input = builder.build() 
        val outputData = updateNotetypeLegacyRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun addOrUpdateNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 4, input)
    }

    open fun addOrUpdateNotetype(json: com.google.protobuf.ByteString, preserveUsnAndMtime: Boolean, skipChecks: Boolean): Long {
        val builder = anki.notetypes.AddOrUpdateNotetypeRequest.newBuilder()
        builder.setJson(json)
        builder.setPreserveUsnAndMtime(preserveUsnAndMtime)
        builder.setSkipChecks(skipChecks)
        val input = builder.build() 
        val outputData = addOrUpdateNotetypeRaw(input.toByteArray())
        val output = anki.notetypes.NotetypeId.parseFrom(outputData)
        return output.ntid
    }

    fun getStockNotetypeLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 5, input)
    }

    open fun getStockNotetypeLegacy(kind: anki.notetypes.StockNotetype.Kind): com.google.protobuf.ByteString {
        val builder = anki.notetypes.StockNotetype.newBuilder()
        builder.setKind(kind)
        val input = builder.build() 
        val outputData = getStockNotetypeLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 6, input)
    }

    open fun getNotetype(ntid: Long): anki.notetypes.Notetype {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = getNotetypeRaw(input.toByteArray())
        val output = anki.notetypes.Notetype.parseFrom(outputData)
        return output
    }

    fun getNotetypeLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 7, input)
    }

    open fun getNotetypeLegacy(ntid: Long): com.google.protobuf.ByteString {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = getNotetypeLegacyRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getNotetypeNamesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 8, input)
    }

    open fun getNotetypeNames(): List<anki.notetypes.NotetypeNameId> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getNotetypeNamesRaw(input.toByteArray())
        val output = anki.notetypes.NotetypeNames.parseFrom(outputData)
        return output.entriesList
    }

    fun getNotetypeNamesAndCountsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 9, input)
    }

    open fun getNotetypeNamesAndCounts(): List<anki.notetypes.NotetypeNameIdUseCount> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getNotetypeNamesAndCountsRaw(input.toByteArray())
        val output = anki.notetypes.NotetypeUseCounts.parseFrom(outputData)
        return output.entriesList
    }

    fun getNotetypeIdByNameRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 10, input)
    }

    open fun getNotetypeIdByName(`val`: String): Long {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = getNotetypeIdByNameRaw(input.toByteArray())
        val output = anki.notetypes.NotetypeId.parseFrom(outputData)
        return output.ntid
    }

    fun removeNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 11, input)
    }

    open fun removeNotetype(ntid: Long): anki.collection.OpChanges {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = removeNotetypeRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getAuxNotetypeConfigKeyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 12, input)
    }

    open fun getAuxNotetypeConfigKey(id: Long, key: String): String {
        val builder = anki.notetypes.GetAuxConfigKeyRequest.newBuilder()
        builder.setId(id)
        builder.setKey(key)
        val input = builder.build() 
        val outputData = getAuxNotetypeConfigKeyRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun getAuxTemplateConfigKeyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 13, input)
    }

    open fun getAuxTemplateConfigKey(notetypeId: Long, cardOrdinal: Int, key: String): String {
        val builder = anki.notetypes.GetAuxTemplateConfigKeyRequest.newBuilder()
        builder.setNotetypeId(notetypeId)
        builder.setCardOrdinal(cardOrdinal)
        builder.setKey(key)
        val input = builder.build() 
        val outputData = getAuxTemplateConfigKeyRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun getChangeNotetypeInfoRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 14, input)
    }

    open fun getChangeNotetypeInfo(oldNotetypeId: Long, newNotetypeId: Long): anki.notetypes.ChangeNotetypeInfo {
        val builder = anki.notetypes.GetChangeNotetypeInfoRequest.newBuilder()
        builder.setOldNotetypeId(oldNotetypeId)
        builder.setNewNotetypeId(newNotetypeId)
        val input = builder.build() 
        val outputData = getChangeNotetypeInfoRaw(input.toByteArray())
        val output = anki.notetypes.ChangeNotetypeInfo.parseFrom(outputData)
        return output
    }

    fun changeNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 15, input)
    }

    open fun changeNotetype(noteIds: Iterable<Long>, newFields: Iterable<Int>, newTemplates: Iterable<Int>, oldNotetypeId: Long, newNotetypeId: Long, currentSchema: Long, oldNotetypeName: String, isCloze: Boolean): anki.collection.OpChanges {
        val builder = anki.notetypes.ChangeNotetypeRequest.newBuilder()
        builder.addAllNoteIds(noteIds)
        builder.addAllNewFields(newFields)
        builder.addAllNewTemplates(newTemplates)
        builder.setOldNotetypeId(oldNotetypeId)
        builder.setNewNotetypeId(newNotetypeId)
        builder.setCurrentSchema(currentSchema)
        builder.setOldNotetypeName(oldNotetypeName)
        builder.setIsCloze(isCloze)
        val input = builder.build() 
        val outputData = changeNotetypeRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getFieldNamesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 16, input)
    }

    open fun getFieldNames(ntid: Long): List<String> {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = getFieldNamesRaw(input.toByteArray())
        val output = anki.generic.StringList.parseFrom(outputData)
        return output.valsList
    }

    fun restoreNotetypeToStockRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 17, input)
    }

    open fun restoreNotetypeToStock(input: anki.notetypes.RestoreNotetypeToStockRequest): anki.collection.OpChanges {
        val outputData = restoreNotetypeToStockRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getClozeFieldOrdsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(23, 18, input)
    }

    open fun getClozeFieldOrds(ntid: Long): List<Int> {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = getClozeFieldOrdsRaw(input.toByteArray())
        val output = anki.notetypes.GetClozeFieldOrdsResponse.parseFrom(outputData)
        return output.ordsList
    }

    fun newNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 0, input)
    }

    open fun newNote(ntid: Long): anki.notes.Note {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = newNoteRaw(input.toByteArray())
        val output = anki.notes.Note.parseFrom(outputData)
        return output
    }

    fun addNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 1, input)
    }

    open fun addNote(note: anki.notes.Note, deckId: Long): anki.notes.AddNoteResponse {
        val builder = anki.notes.AddNoteRequest.newBuilder()
        builder.setNote(note)
        builder.setDeckId(deckId)
        val input = builder.build() 
        val outputData = addNoteRaw(input.toByteArray())
        val output = anki.notes.AddNoteResponse.parseFrom(outputData)
        return output
    }

    fun addNotesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 2, input)
    }

    open fun addNotes(requests: Iterable<anki.notes.AddNoteRequest>): anki.notes.AddNotesResponse {
        val builder = anki.notes.AddNotesRequest.newBuilder()
        builder.addAllRequests(requests)
        val input = builder.build() 
        val outputData = addNotesRaw(input.toByteArray())
        val output = anki.notes.AddNotesResponse.parseFrom(outputData)
        return output
    }

    fun defaultsForAddingRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 3, input)
    }

    open fun defaultsForAdding(homeDeckOfCurrentReviewCard: Long): anki.notes.DeckAndNotetype {
        val builder = anki.notes.DefaultsForAddingRequest.newBuilder()
        builder.setHomeDeckOfCurrentReviewCard(homeDeckOfCurrentReviewCard)
        val input = builder.build() 
        val outputData = defaultsForAddingRaw(input.toByteArray())
        val output = anki.notes.DeckAndNotetype.parseFrom(outputData)
        return output
    }

    fun defaultDeckForNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 4, input)
    }

    open fun defaultDeckForNotetype(ntid: Long): Long {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = defaultDeckForNotetypeRaw(input.toByteArray())
        val output = anki.decks.DeckId.parseFrom(outputData)
        return output.did
    }

    fun updateNotesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 5, input)
    }

    open fun updateNotes(notes: Iterable<anki.notes.Note>, skipUndoEntry: Boolean): anki.collection.OpChanges {
        val builder = anki.notes.UpdateNotesRequest.newBuilder()
        builder.addAllNotes(notes)
        builder.setSkipUndoEntry(skipUndoEntry)
        val input = builder.build() 
        val outputData = updateNotesRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun getNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 6, input)
    }

    open fun getNote(nid: Long): anki.notes.Note {
        val builder = anki.notes.NoteId.newBuilder()
        builder.setNid(nid)
        val input = builder.build() 
        val outputData = getNoteRaw(input.toByteArray())
        val output = anki.notes.Note.parseFrom(outputData)
        return output
    }

    fun removeNotesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 7, input)
    }

    open fun removeNotes(noteIds: Iterable<Long>, cardIds: Iterable<Long>): anki.collection.OpChangesWithCount {
        val builder = anki.notes.RemoveNotesRequest.newBuilder()
        builder.addAllNoteIds(noteIds)
        builder.addAllCardIds(cardIds)
        val input = builder.build() 
        val outputData = removeNotesRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun clozeNumbersInNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 8, input)
    }

    open fun clozeNumbersInNote(input: anki.notes.Note): List<Int> {
        val outputData = clozeNumbersInNoteRaw(input.toByteArray())
        val output = anki.notes.ClozeNumbersInNoteResponse.parseFrom(outputData)
        return output.numbersList
    }

    fun afterNoteUpdatesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 9, input)
    }

    open fun afterNoteUpdates(nids: Iterable<Long>, markNotesModified: Boolean, generateCards: Boolean): anki.collection.OpChangesWithCount {
        val builder = anki.notes.AfterNoteUpdatesRequest.newBuilder()
        builder.addAllNids(nids)
        builder.setMarkNotesModified(markNotesModified)
        builder.setGenerateCards(generateCards)
        val input = builder.build() 
        val outputData = afterNoteUpdatesRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun fieldNamesForNotesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 10, input)
    }

    open fun fieldNamesForNotes(nids: Iterable<Long>): List<String> {
        val builder = anki.notes.FieldNamesForNotesRequest.newBuilder()
        builder.addAllNids(nids)
        val input = builder.build() 
        val outputData = fieldNamesForNotesRaw(input.toByteArray())
        val output = anki.notes.FieldNamesForNotesResponse.parseFrom(outputData)
        return output.fieldsList
    }

    fun noteFieldsCheckRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 11, input)
    }

    open fun noteFieldsCheck(input: anki.notes.Note): anki.notes.NoteFieldsCheckResponse {
        val outputData = noteFieldsCheckRaw(input.toByteArray())
        val output = anki.notes.NoteFieldsCheckResponse.parseFrom(outputData)
        return output
    }

    fun cardsOfNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 12, input)
    }

    open fun cardsOfNote(nid: Long): List<Long> {
        val builder = anki.notes.NoteId.newBuilder()
        builder.setNid(nid)
        val input = builder.build() 
        val outputData = cardsOfNoteRaw(input.toByteArray())
        val output = anki.cards.CardIds.parseFrom(outputData)
        return output.cidsList
    }

    fun getSingleNotetypeOfNotesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(25, 13, input)
    }

    open fun getSingleNotetypeOfNotes(noteIds: Iterable<Long>): Long {
        val builder = anki.notes.NoteIds.newBuilder()
        builder.addAllNoteIds(noteIds)
        val input = builder.build() 
        val outputData = getSingleNotetypeOfNotesRaw(input.toByteArray())
        val output = anki.notetypes.NotetypeId.parseFrom(outputData)
        return output.ntid
    }

    fun stripHtmlRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 0, input)
    }

    open fun stripHtml(text: String, mode: anki.card_rendering.StripHtmlRequest.Mode): String {
        val builder = anki.card_rendering.StripHtmlRequest.newBuilder()
        builder.setText(text)
        builder.setMode(mode)
        val input = builder.build() 
        val outputData = stripHtmlRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun allTtsVoicesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 1, input)
    }

    open fun allTtsVoices(validate: Boolean): List<anki.card_rendering.AllTtsVoicesResponse.TtsVoice> {
        val builder = anki.card_rendering.AllTtsVoicesRequest.newBuilder()
        builder.setValidate(validate)
        val input = builder.build() 
        val outputData = allTtsVoicesRaw(input.toByteArray())
        val output = anki.card_rendering.AllTtsVoicesResponse.parseFrom(outputData)
        return output.voicesList
    }

    fun writeTtsStreamRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 2, input)
    }

    open fun writeTtsStream(path: String, voiceId: String, speed: Float, text: String): Unit {
        val builder = anki.card_rendering.WriteTtsStreamRequest.newBuilder()
        builder.setPath(path)
        builder.setVoiceId(voiceId)
        builder.setSpeed(speed)
        builder.setText(text)
        val input = builder.build() 
        val outputData = writeTtsStreamRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun extractAvTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 3, input)
    }

    open fun extractAvTags(text: String, questionSide: Boolean): anki.card_rendering.ExtractAvTagsResponse {
        val builder = anki.card_rendering.ExtractAvTagsRequest.newBuilder()
        builder.setText(text)
        builder.setQuestionSide(questionSide)
        val input = builder.build() 
        val outputData = extractAvTagsRaw(input.toByteArray())
        val output = anki.card_rendering.ExtractAvTagsResponse.parseFrom(outputData)
        return output
    }

    fun extractLatexRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 4, input)
    }

    open fun extractLatex(text: String, svg: Boolean, expandClozes: Boolean): anki.card_rendering.ExtractLatexResponse {
        val builder = anki.card_rendering.ExtractLatexRequest.newBuilder()
        builder.setText(text)
        builder.setSvg(svg)
        builder.setExpandClozes(expandClozes)
        val input = builder.build() 
        val outputData = extractLatexRaw(input.toByteArray())
        val output = anki.card_rendering.ExtractLatexResponse.parseFrom(outputData)
        return output
    }

    fun getEmptyCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 5, input)
    }

    open fun getEmptyCards(): anki.card_rendering.EmptyCardsReport {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getEmptyCardsRaw(input.toByteArray())
        val output = anki.card_rendering.EmptyCardsReport.parseFrom(outputData)
        return output
    }

    fun renderExistingCardRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 6, input)
    }

    open fun renderExistingCard(cardId: Long, browser: Boolean, partialRender: Boolean): anki.card_rendering.RenderCardResponse {
        val builder = anki.card_rendering.RenderExistingCardRequest.newBuilder()
        builder.setCardId(cardId)
        builder.setBrowser(browser)
        builder.setPartialRender(partialRender)
        val input = builder.build() 
        val outputData = renderExistingCardRaw(input.toByteArray())
        val output = anki.card_rendering.RenderCardResponse.parseFrom(outputData)
        return output
    }

    fun renderUncommittedCardRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 7, input)
    }

    open fun renderUncommittedCard(note: anki.notes.Note, cardOrd: Int, template: anki.notetypes.Notetype.Template, fillEmpty: Boolean, partialRender: Boolean): anki.card_rendering.RenderCardResponse {
        val builder = anki.card_rendering.RenderUncommittedCardRequest.newBuilder()
        builder.setNote(note)
        builder.setCardOrd(cardOrd)
        builder.setTemplate(template)
        builder.setFillEmpty(fillEmpty)
        builder.setPartialRender(partialRender)
        val input = builder.build() 
        val outputData = renderUncommittedCardRaw(input.toByteArray())
        val output = anki.card_rendering.RenderCardResponse.parseFrom(outputData)
        return output
    }

    fun renderUncommittedCardLegacyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 8, input)
    }

    open fun renderUncommittedCardLegacy(note: anki.notes.Note, cardOrd: Int, template: com.google.protobuf.ByteString, fillEmpty: Boolean, partialRender: Boolean): anki.card_rendering.RenderCardResponse {
        val builder = anki.card_rendering.RenderUncommittedCardLegacyRequest.newBuilder()
        builder.setNote(note)
        builder.setCardOrd(cardOrd)
        builder.setTemplate(template)
        builder.setFillEmpty(fillEmpty)
        builder.setPartialRender(partialRender)
        val input = builder.build() 
        val outputData = renderUncommittedCardLegacyRaw(input.toByteArray())
        val output = anki.card_rendering.RenderCardResponse.parseFrom(outputData)
        return output
    }

    fun stripAvTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 9, input)
    }

    open fun stripAvTags(`val`: String): String {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = stripAvTagsRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun renderMarkdownRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 10, input)
    }

    open fun renderMarkdown(markdown: String, sanitize: Boolean): String {
        val builder = anki.card_rendering.RenderMarkdownRequest.newBuilder()
        builder.setMarkdown(markdown)
        builder.setSanitize(sanitize)
        val input = builder.build() 
        val outputData = renderMarkdownRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun encodeIriPathsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 11, input)
    }

    open fun encodeIriPaths(`val`: String): String {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = encodeIriPathsRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun decodeIriPathsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 12, input)
    }

    open fun decodeIriPaths(`val`: String): String {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = decodeIriPathsRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun htmlToTextLineRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 14, input)
    }

    open fun htmlToTextLine(text: String, preserveMediaFilenames: Boolean): String {
        val builder = anki.card_rendering.HtmlToTextLineRequest.newBuilder()
        builder.setText(text)
        builder.setPreserveMediaFilenames(preserveMediaFilenames)
        val input = builder.build() 
        val outputData = htmlToTextLineRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun compareAnswerRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 15, input)
    }

    open fun compareAnswer(expected: String, provided: String, combining: Boolean): String {
        val builder = anki.card_rendering.CompareAnswerRequest.newBuilder()
        builder.setExpected(expected)
        builder.setProvided(provided)
        builder.setCombining(combining)
        val input = builder.build() 
        val outputData = compareAnswerRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun extractClozeForTypingRaw(input: ByteArray): ByteArray {
        return runMethodRaw(27, 16, input)
    }

    open fun extractClozeForTyping(text: String, ordinal: Int): String {
        val builder = anki.card_rendering.ExtractClozeForTypingRequest.newBuilder()
        builder.setText(text)
        builder.setOrdinal(ordinal)
        val input = builder.build() 
        val outputData = extractClozeForTypingRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun buildSearchStringRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 0, input)
    }

    open fun buildSearchString(input: anki.search.SearchNode): String {
        val outputData = buildSearchStringRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun searchCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 1, input)
    }

    open fun searchCards(search: String, order: anki.search.SortOrder): List<Long> {
        val builder = anki.search.SearchRequest.newBuilder()
        builder.setSearch(search)
        builder.setOrder(order)
        val input = builder.build() 
        val outputData = searchCardsRaw(input.toByteArray())
        val output = anki.search.SearchResponse.parseFrom(outputData)
        return output.idsList
    }

    fun searchNotesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 2, input)
    }

    open fun searchNotes(search: String, order: anki.search.SortOrder): List<Long> {
        val builder = anki.search.SearchRequest.newBuilder()
        builder.setSearch(search)
        builder.setOrder(order)
        val input = builder.build() 
        val outputData = searchNotesRaw(input.toByteArray())
        val output = anki.search.SearchResponse.parseFrom(outputData)
        return output.idsList
    }

    fun joinSearchNodesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 3, input)
    }

    open fun joinSearchNodes(joiner: anki.search.SearchNode.Group.Joiner, existingNode: anki.search.SearchNode, additionalNode: anki.search.SearchNode): String {
        val builder = anki.search.JoinSearchNodesRequest.newBuilder()
        builder.setJoiner(joiner)
        builder.setExistingNode(existingNode)
        builder.setAdditionalNode(additionalNode)
        val input = builder.build() 
        val outputData = joinSearchNodesRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun replaceSearchNodeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 4, input)
    }

    open fun replaceSearchNode(existingNode: anki.search.SearchNode, replacementNode: anki.search.SearchNode): String {
        val builder = anki.search.ReplaceSearchNodeRequest.newBuilder()
        builder.setExistingNode(existingNode)
        builder.setReplacementNode(replacementNode)
        val input = builder.build() 
        val outputData = replaceSearchNodeRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun findAndReplaceRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 5, input)
    }

    open fun findAndReplace(nids: Iterable<Long>, search: String, replacement: String, regex: Boolean, matchCase: Boolean, fieldName: String): anki.collection.OpChangesWithCount {
        val builder = anki.search.FindAndReplaceRequest.newBuilder()
        builder.addAllNids(nids)
        builder.setSearch(search)
        builder.setReplacement(replacement)
        builder.setRegex(regex)
        builder.setMatchCase(matchCase)
        builder.setFieldName(fieldName)
        val input = builder.build() 
        val outputData = findAndReplaceRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun allBrowserColumnsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 6, input)
    }

    open fun allBrowserColumns(): List<anki.search.BrowserColumns.Column> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = allBrowserColumnsRaw(input.toByteArray())
        val output = anki.search.BrowserColumns.parseFrom(outputData)
        return output.columnsList
    }

    fun browserRowForIdRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 7, input)
    }

    open fun browserRowForId(`val`: Long): anki.search.BrowserRow {
        val builder = anki.generic.Int64.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = browserRowForIdRaw(input.toByteArray())
        val output = anki.search.BrowserRow.parseFrom(outputData)
        return output
    }

    fun setActiveBrowserColumnsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(29, 8, input)
    }

    open fun setActiveBrowserColumns(vals: Iterable<String>): Unit {
        val builder = anki.generic.StringList.newBuilder()
        builder.addAllVals(vals)
        val input = builder.build() 
        val outputData = setActiveBrowserColumnsRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Returns values from the reviewer */
    fun getSchedulingStatesWithContextRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 0, input)
    }
/** Returns values from the reviewer */

    open fun getSchedulingStatesWithContext(): anki.frontend.SchedulingStatesWithContext {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getSchedulingStatesWithContextRaw(input.toByteArray())
        val output = anki.frontend.SchedulingStatesWithContext.parseFrom(outputData)
        return output
    }

/** Updates reviewer state */
    fun setSchedulingStatesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 1, input)
    }
/** Updates reviewer state */

    open fun setSchedulingStates(key: String, states: anki.scheduler.SchedulingStates): Unit {
        val builder = anki.frontend.SetSchedulingStatesRequest.newBuilder()
        builder.setKey(key)
        builder.setStates(states)
        val input = builder.build() 
        val outputData = setSchedulingStatesRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Notify Qt layer so window modality can be updated. */
    fun importDoneRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 2, input)
    }
/** Notify Qt layer so window modality can be updated. */

    open fun importDone(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = importDoneRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun searchInBrowserRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 3, input)
    }

    open fun searchInBrowser(input: anki.search.SearchNode): Unit {
        val outputData = searchInBrowserRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Force closing the deck options. */
    fun deckOptionsRequireCloseRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 4, input)
    }
/** Force closing the deck options. */

    open fun deckOptionsRequireClose(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = deckOptionsRequireCloseRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Warns python that the deck option web view is ready to receive requests. */
    fun deckOptionsReadyRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 5, input)
    }
/** Warns python that the deck option web view is ready to receive requests. */

    open fun deckOptionsReady(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = deckOptionsReadyRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Editor */
    fun convertPastedImageRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 6, input)
    }
/** Editor */

    open fun convertPastedImage(data: com.google.protobuf.ByteString, ext: String): com.google.protobuf.ByteString {
        val builder = anki.frontend.ConvertPastedImageRequest.newBuilder()
        builder.setData(data)
        builder.setExt(ext)
        val input = builder.build() 
        val outputData = convertPastedImageRaw(input.toByteArray())
        val output = anki.frontend.ConvertPastedImageResponse.parseFrom(outputData)
        return output.data
    }

    fun openFilePickerRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 7, input)
    }

    open fun openFilePicker(title: String, key: String, filterDescription: String, extensions: Iterable<String>): String {
        val builder = anki.frontend.openFilePickerRequest.newBuilder()
        builder.setTitle(title)
        builder.setKey(key)
        builder.setFilterDescription(filterDescription)
        builder.addAllExtensions(extensions)
        val input = builder.build() 
        val outputData = openFilePickerRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun openMediaRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 8, input)
    }

    open fun openMedia(`val`: String): Unit {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = openMediaRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun showInMediaFolderRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 9, input)
    }

    open fun showInMediaFolder(`val`: String): Unit {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = showInMediaFolderRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun recordAudioRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 10, input)
    }

    open fun recordAudio(): String {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = recordAudioRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun playFileRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 11, input)
    }

    open fun playFile(`val`: String): Unit {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = playFileRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun closeAddCardsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 12, input)
    }

    open fun closeAddCards(`val`: Boolean): Unit {
        val builder = anki.generic.Bool.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = closeAddCardsRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun closeEditCurrentRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 13, input)
    }

    open fun closeEditCurrent(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = closeEditCurrentRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun openLinkRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 14, input)
    }

    open fun openLink(`val`: String): Unit {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = openLinkRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun askUserRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 15, input)
    }

    open fun askUser(input: anki.frontend.AskUserRequest): Boolean {
        val outputData = askUserRaw(input.toByteArray())
        val output = anki.generic.Bool.parseFrom(outputData)
        return output.`val`
    }

    fun showMessageBoxRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 16, input)
    }

    open fun showMessageBox(input: anki.frontend.ShowMessageBoxRequest): Unit {
        val outputData = showMessageBoxRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun openFieldsDialogRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 17, input)
    }

    open fun openFieldsDialog(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = openFieldsDialogRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun openCardsDialogRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 18, input)
    }

    open fun openCardsDialog(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = openCardsDialogRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Profile config */
    fun getProfileConfigJsonRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 19, input)
    }
/** Profile config */

    open fun getProfileConfigJson(`val`: String): com.google.protobuf.ByteString {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = getProfileConfigJsonRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun setProfileConfigJsonRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 20, input)
    }

    open fun setProfileConfigJson(key: String, valueJson: com.google.protobuf.ByteString): Unit {
        val builder = anki.frontend.SetSettingJsonRequest.newBuilder()
        builder.setKey(key)
        builder.setValueJson(valueJson)
        val input = builder.build() 
        val outputData = setProfileConfigJsonRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Metadata */
    fun getMetaJsonRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 21, input)
    }
/** Metadata */

    open fun getMetaJson(`val`: String): com.google.protobuf.ByteString {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = getMetaJsonRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun setMetaJsonRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 22, input)
    }

    open fun setMetaJson(key: String, valueJson: com.google.protobuf.ByteString): Unit {
        val builder = anki.frontend.SetSettingJsonRequest.newBuilder()
        builder.setKey(key)
        builder.setValueJson(valueJson)
        val input = builder.build() 
        val outputData = setMetaJsonRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Clipboard */
    fun readClipboardRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 23, input)
    }
/** Clipboard */

    open fun readClipboard(types: Iterable<String>): Map<String,com.google.protobuf.ByteString> {
        val builder = anki.frontend.ReadClipboardRequest.newBuilder()
        builder.addAllTypes(types)
        val input = builder.build() 
        val outputData = readClipboardRaw(input.toByteArray())
        val output = anki.frontend.ReadClipboardResponse.parseFrom(outputData)
        return output.data
    }

    fun writeClipboardRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 24, input)
    }

    open fun writeClipboard(data: Map<String,com.google.protobuf.ByteString>): Unit {
        val builder = anki.frontend.WriteClipboardRequest.newBuilder()
        builder.putAllData(data)
        val input = builder.build() 
        val outputData = writeClipboardRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** Save colour picker's custom colour palette */
    fun saveCustomColoursRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 25, input)
    }
/** Save colour picker's custom colour palette */

    open fun saveCustomColours(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = saveCustomColoursRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

/** CSV import */
    fun importDialogRequireCloseRaw(input: ByteArray): ByteArray {
        return runMethodRaw(31, 26, input)
    }
/** CSV import */

    open fun importDialogRequireClose(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = importDialogRequireCloseRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun getLatestReleaseRaw(input: ByteArray): ByteArray {
        return runMethodRaw(33, 0, input)
    }

    open fun getLatestRelease(includePrerelease: Boolean): anki.github.GithubRelease {
        val builder = anki.github.LatestReleaseRequest.newBuilder()
        builder.setIncludePrerelease(includePrerelease)
        val input = builder.build() 
        val outputData = getLatestReleaseRaw(input.toByteArray())
        val output = anki.github.GithubRelease.parseFrom(outputData)
        return output
    }

    fun downloadReleaseRaw(input: ByteArray): ByteArray {
        return runMethodRaw(33, 1, input)
    }

    open fun downloadRelease(input: anki.github.GithubRelease): String {
        val outputData = downloadReleaseRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun translateStringRaw(input: ByteArray): ByteArray {
        return runMethodRaw(35, 0, input)
    }

    open fun translateString(moduleIndex: Int, messageIndex: Int, args: Map<String,anki.i18n.TranslateArgValue>): String {
        val builder = anki.i18n.TranslateStringRequest.newBuilder()
        builder.setModuleIndex(moduleIndex)
        builder.setMessageIndex(messageIndex)
        builder.putAllArgs(args)
        val input = builder.build() 
        val outputData = translateStringRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun formatTimespanRaw(input: ByteArray): ByteArray {
        return runMethodRaw(35, 1, input)
    }

    open fun formatTimespan(seconds: Float, context: anki.i18n.FormatTimespanRequest.Context): String {
        val builder = anki.i18n.FormatTimespanRequest.newBuilder()
        builder.setSeconds(seconds)
        builder.setContext(context)
        val input = builder.build() 
        val outputData = formatTimespanRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun i18nResourcesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(35, 2, input)
    }

    open fun i18nResources(modules: Iterable<String>): com.google.protobuf.ByteString {
        val builder = anki.i18n.I18nResourcesRequest.newBuilder()
        builder.addAllModules(modules)
        val input = builder.build() 
        val outputData = i18nResourcesRaw(input.toByteArray())
        val output = anki.generic.Json.parseFrom(outputData)
        return output.json
    }

    fun getImageForOcclusionRaw(input: ByteArray): ByteArray {
        return runMethodRaw(37, 0, input)
    }

    open fun getImageForOcclusion(path: String): anki.image_occlusion.GetImageForOcclusionResponse {
        val builder = anki.image_occlusion.GetImageForOcclusionRequest.newBuilder()
        builder.setPath(path)
        val input = builder.build() 
        val outputData = getImageForOcclusionRaw(input.toByteArray())
        val output = anki.image_occlusion.GetImageForOcclusionResponse.parseFrom(outputData)
        return output
    }

    fun getImageOcclusionNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(37, 1, input)
    }

    open fun getImageOcclusionNote(noteId: Long): anki.image_occlusion.GetImageOcclusionNoteResponse {
        val builder = anki.image_occlusion.GetImageOcclusionNoteRequest.newBuilder()
        builder.setNoteId(noteId)
        val input = builder.build() 
        val outputData = getImageOcclusionNoteRaw(input.toByteArray())
        val output = anki.image_occlusion.GetImageOcclusionNoteResponse.parseFrom(outputData)
        return output
    }

    fun getImageOcclusionFieldsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(37, 2, input)
    }

    open fun getImageOcclusionFields(notetypeId: Long): anki.image_occlusion.ImageOcclusionFieldIndexes {
        val builder = anki.image_occlusion.GetImageOcclusionFieldsRequest.newBuilder()
        builder.setNotetypeId(notetypeId)
        val input = builder.build() 
        val outputData = getImageOcclusionFieldsRaw(input.toByteArray())
        val output = anki.image_occlusion.GetImageOcclusionFieldsResponse.parseFrom(outputData)
        return output.fields
    }

/** Adds an I/O notetype if none exists in the collection. */
    fun addImageOcclusionNotetypeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(37, 3, input)
    }
/** Adds an I/O notetype if none exists in the collection. */

    open fun addImageOcclusionNotetype(): anki.collection.OpChanges {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = addImageOcclusionNotetypeRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

/** These two are used by the standalone I/O page, but not used when using
 I/O inside Anki's editor */
    fun addImageOcclusionNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(37, 4, input)
    }
/** These two are used by the standalone I/O page, but not used when using
 I/O inside Anki's editor */

    open fun addImageOcclusionNote(imagePath: String, occlusions: String, header: String, backExtra: String, tags: Iterable<String>, notetypeId: Long): anki.collection.OpChanges {
        val builder = anki.image_occlusion.AddImageOcclusionNoteRequest.newBuilder()
        builder.setImagePath(imagePath)
        builder.setOcclusions(occlusions)
        builder.setHeader(header)
        builder.setBackExtra(backExtra)
        builder.addAllTags(tags)
        builder.setNotetypeId(notetypeId)
        val input = builder.build() 
        val outputData = addImageOcclusionNoteRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun updateImageOcclusionNoteRaw(input: ByteArray): ByteArray {
        return runMethodRaw(37, 5, input)
    }

    open fun updateImageOcclusionNote(noteId: Long, occlusions: String, header: String, backExtra: String, tags: Iterable<String>): anki.collection.OpChanges {
        val builder = anki.image_occlusion.UpdateImageOcclusionNoteRequest.newBuilder()
        builder.setNoteId(noteId)
        builder.setOcclusions(occlusions)
        builder.setHeader(header)
        builder.setBackExtra(backExtra)
        builder.addAllTags(tags)
        val input = builder.build() 
        val outputData = updateImageOcclusionNoteRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun importCollectionPackageRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 0, input)
    }

    open fun importCollectionPackage(colPath: String, backupPath: String, mediaFolder: String, mediaDb: String): Unit {
        val builder = anki.import_export.ImportCollectionPackageRequest.newBuilder()
        builder.setColPath(colPath)
        builder.setBackupPath(backupPath)
        builder.setMediaFolder(mediaFolder)
        builder.setMediaDb(mediaDb)
        val input = builder.build() 
        val outputData = importCollectionPackageRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun exportCollectionPackageRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 1, input)
    }

    open fun exportCollectionPackage(outPath: String, includeMedia: Boolean, legacy: Boolean): Unit {
        val builder = anki.import_export.ExportCollectionPackageRequest.newBuilder()
        builder.setOutPath(outPath)
        builder.setIncludeMedia(includeMedia)
        builder.setLegacy(legacy)
        val input = builder.build() 
        val outputData = exportCollectionPackageRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun importAnkiPackageRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 2, input)
    }

    open fun importAnkiPackage(packagePath: String, options: anki.import_export.ImportAnkiPackageOptions): anki.import_export.ImportResponse {
        val builder = anki.import_export.ImportAnkiPackageRequest.newBuilder()
        builder.setPackagePath(packagePath)
        builder.setOptions(options)
        val input = builder.build() 
        val outputData = importAnkiPackageRaw(input.toByteArray())
        val output = anki.import_export.ImportResponse.parseFrom(outputData)
        return output
    }

    fun getImportAnkiPackagePresetsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 3, input)
    }

    open fun getImportAnkiPackagePresets(): anki.import_export.ImportAnkiPackageOptions {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getImportAnkiPackagePresetsRaw(input.toByteArray())
        val output = anki.import_export.ImportAnkiPackageOptions.parseFrom(outputData)
        return output
    }

    fun exportAnkiPackageRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 4, input)
    }

    open fun exportAnkiPackage(outPath: String, options: anki.import_export.ExportAnkiPackageOptions, limit: anki.import_export.ExportLimit): Int {
        val builder = anki.import_export.ExportAnkiPackageRequest.newBuilder()
        builder.setOutPath(outPath)
        builder.setOptions(options)
        builder.setLimit(limit)
        val input = builder.build() 
        val outputData = exportAnkiPackageRaw(input.toByteArray())
        val output = anki.generic.UInt32.parseFrom(outputData)
        return output.`val`
    }

    fun getCsvMetadataRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 5, input)
    }

    open fun getCsvMetadata(input: anki.import_export.CsvMetadataRequest): anki.import_export.CsvMetadata {
        val outputData = getCsvMetadataRaw(input.toByteArray())
        val output = anki.import_export.CsvMetadata.parseFrom(outputData)
        return output
    }

    fun importCsvRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 6, input)
    }

    open fun importCsv(path: String, metadata: anki.import_export.CsvMetadata): anki.import_export.ImportResponse {
        val builder = anki.import_export.ImportCsvRequest.newBuilder()
        builder.setPath(path)
        builder.setMetadata(metadata)
        val input = builder.build() 
        val outputData = importCsvRaw(input.toByteArray())
        val output = anki.import_export.ImportResponse.parseFrom(outputData)
        return output
    }

    fun exportNoteCsvRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 7, input)
    }

    open fun exportNoteCsv(outPath: String, withHtml: Boolean, withTags: Boolean, withDeck: Boolean, withNotetype: Boolean, withGuid: Boolean, limit: anki.import_export.ExportLimit): Int {
        val builder = anki.import_export.ExportNoteCsvRequest.newBuilder()
        builder.setOutPath(outPath)
        builder.setWithHtml(withHtml)
        builder.setWithTags(withTags)
        builder.setWithDeck(withDeck)
        builder.setWithNotetype(withNotetype)
        builder.setWithGuid(withGuid)
        builder.setLimit(limit)
        val input = builder.build() 
        val outputData = exportNoteCsvRaw(input.toByteArray())
        val output = anki.generic.UInt32.parseFrom(outputData)
        return output.`val`
    }

    fun exportCardCsvRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 8, input)
    }

    open fun exportCardCsv(outPath: String, withHtml: Boolean, limit: anki.import_export.ExportLimit): Int {
        val builder = anki.import_export.ExportCardCsvRequest.newBuilder()
        builder.setOutPath(outPath)
        builder.setWithHtml(withHtml)
        builder.setLimit(limit)
        val input = builder.build() 
        val outputData = exportCardCsvRaw(input.toByteArray())
        val output = anki.generic.UInt32.parseFrom(outputData)
        return output.`val`
    }

    fun importJsonFileRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 9, input)
    }

    open fun importJsonFile(`val`: String): anki.import_export.ImportResponse {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = importJsonFileRaw(input.toByteArray())
        val output = anki.import_export.ImportResponse.parseFrom(outputData)
        return output
    }

    fun importJsonStringRaw(input: ByteArray): ByteArray {
        return runMethodRaw(39, 10, input)
    }

    open fun importJsonString(`val`: String): anki.import_export.ImportResponse {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = importJsonStringRaw(input.toByteArray())
        val output = anki.import_export.ImportResponse.parseFrom(outputData)
        return output
    }

    fun addMediaFromUrlRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 0, input)
    }

    open fun addMediaFromUrl(url: String): anki.media.AddMediaFromUrlResponse {
        val builder = anki.media.AddMediaFromUrlRequest.newBuilder()
        builder.setUrl(url)
        val input = builder.build() 
        val outputData = addMediaFromUrlRaw(input.toByteArray())
        val output = anki.media.AddMediaFromUrlResponse.parseFrom(outputData)
        return output
    }

    fun checkMediaRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 1, input)
    }

    open fun checkMedia(): anki.media.CheckMediaResponse {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = checkMediaRaw(input.toByteArray())
        val output = anki.media.CheckMediaResponse.parseFrom(outputData)
        return output
    }

    fun addMediaFileRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 2, input)
    }

    open fun addMediaFile(desiredName: String, data: com.google.protobuf.ByteString): String {
        val builder = anki.media.AddMediaFileRequest.newBuilder()
        builder.setDesiredName(desiredName)
        builder.setData(data)
        val input = builder.build() 
        val outputData = addMediaFileRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun addMediaFromPathRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 3, input)
    }

    open fun addMediaFromPath(path: String): String {
        val builder = anki.media.AddMediaFromPathRequest.newBuilder()
        builder.setPath(path)
        val input = builder.build() 
        val outputData = addMediaFromPathRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun trashMediaFilesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 4, input)
    }

    open fun trashMediaFiles(fnames: Iterable<String>): Unit {
        val builder = anki.media.TrashMediaFilesRequest.newBuilder()
        builder.addAllFnames(fnames)
        val input = builder.build() 
        val outputData = trashMediaFilesRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun emptyTrashRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 5, input)
    }

    open fun emptyTrash(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = emptyTrashRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun restoreTrashRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 6, input)
    }

    open fun restoreTrash(): Unit {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = restoreTrashRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun extractStaticMediaFilesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 7, input)
    }

    open fun extractStaticMediaFiles(ntid: Long): List<String> {
        val builder = anki.notetypes.NotetypeId.newBuilder()
        builder.setNtid(ntid)
        val input = builder.build() 
        val outputData = extractStaticMediaFilesRaw(input.toByteArray())
        val output = anki.generic.StringList.parseFrom(outputData)
        return output.valsList
    }

    fun extractMediaFilesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 8, input)
    }

    open fun extractMediaFiles(`val`: String): List<String> {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = extractMediaFilesRaw(input.toByteArray())
        val output = anki.generic.StringList.parseFrom(outputData)
        return output.valsList
    }

    fun getAbsoluteMediaPathRaw(input: ByteArray): ByteArray {
        return runMethodRaw(41, 9, input)
    }

    open fun getAbsoluteMediaPath(`val`: String): String {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = getAbsoluteMediaPathRaw(input.toByteArray())
        val output = anki.generic.String.parseFrom(outputData)
        return output.`val`
    }

    fun cardStatsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(43, 0, input)
    }

    open fun cardStats(cid: Long): anki.stats.CardStatsResponse {
        val builder = anki.cards.CardId.newBuilder()
        builder.setCid(cid)
        val input = builder.build() 
        val outputData = cardStatsRaw(input.toByteArray())
        val output = anki.stats.CardStatsResponse.parseFrom(outputData)
        return output
    }

    fun getReviewLogsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(43, 1, input)
    }

    open fun getReviewLogs(cid: Long): List<anki.stats.CardStatsResponse.StatsRevlogEntry> {
        val builder = anki.cards.CardId.newBuilder()
        builder.setCid(cid)
        val input = builder.build() 
        val outputData = getReviewLogsRaw(input.toByteArray())
        val output = anki.stats.ReviewLogs.parseFrom(outputData)
        return output.entriesList
    }

    fun graphsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(43, 2, input)
    }

    open fun graphs(search: String, days: Int): anki.stats.GraphsResponse {
        val builder = anki.stats.GraphsRequest.newBuilder()
        builder.setSearch(search)
        builder.setDays(days)
        val input = builder.build() 
        val outputData = graphsRaw(input.toByteArray())
        val output = anki.stats.GraphsResponse.parseFrom(outputData)
        return output
    }

    fun getGraphPreferencesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(43, 3, input)
    }

    open fun getGraphPreferences(): anki.stats.GraphPreferences {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = getGraphPreferencesRaw(input.toByteArray())
        val output = anki.stats.GraphPreferences.parseFrom(outputData)
        return output
    }

    fun setGraphPreferencesRaw(input: ByteArray): ByteArray {
        return runMethodRaw(43, 4, input)
    }

    open fun setGraphPreferences(input: anki.stats.GraphPreferences): Unit {
        val outputData = setGraphPreferencesRaw(input.toByteArray())
        val output = anki.generic.Empty.parseFrom(outputData)
        return 
    }

    fun clearUnusedTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 0, input)
    }

    open fun clearUnusedTags(): anki.collection.OpChangesWithCount {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = clearUnusedTagsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun allTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 1, input)
    }

    open fun allTags(): List<String> {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = allTagsRaw(input.toByteArray())
        val output = anki.generic.StringList.parseFrom(outputData)
        return output.valsList
    }

    fun removeTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 2, input)
    }

    open fun removeTags(`val`: String): anki.collection.OpChangesWithCount {
        val builder = anki.generic.String.newBuilder()
        builder.setVal(`val`)
        val input = builder.build() 
        val outputData = removeTagsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun setTagCollapsedRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 3, input)
    }

    open fun setTagCollapsed(name: String, collapsed: Boolean): anki.collection.OpChanges {
        val builder = anki.tags.SetTagCollapsedRequest.newBuilder()
        builder.setName(name)
        builder.setCollapsed(collapsed)
        val input = builder.build() 
        val outputData = setTagCollapsedRaw(input.toByteArray())
        val output = anki.collection.OpChanges.parseFrom(outputData)
        return output
    }

    fun tagTreeRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 4, input)
    }

    open fun tagTree(): anki.tags.TagTreeNode {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = tagTreeRaw(input.toByteArray())
        val output = anki.tags.TagTreeNode.parseFrom(outputData)
        return output
    }

    fun reparentTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 5, input)
    }

    open fun reparentTags(tags: Iterable<String>, newParent: String): anki.collection.OpChangesWithCount {
        val builder = anki.tags.ReparentTagsRequest.newBuilder()
        builder.addAllTags(tags)
        builder.setNewParent(newParent)
        val input = builder.build() 
        val outputData = reparentTagsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun renameTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 6, input)
    }

    open fun renameTags(currentPrefix: String, newPrefix: String): anki.collection.OpChangesWithCount {
        val builder = anki.tags.RenameTagsRequest.newBuilder()
        builder.setCurrentPrefix(currentPrefix)
        builder.setNewPrefix(newPrefix)
        val input = builder.build() 
        val outputData = renameTagsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun addNoteTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 7, input)
    }

    open fun addNoteTags(noteIds: Iterable<Long>, tags: String): anki.collection.OpChangesWithCount {
        val builder = anki.tags.NoteIdsAndTagsRequest.newBuilder()
        builder.addAllNoteIds(noteIds)
        builder.setTags(tags)
        val input = builder.build() 
        val outputData = addNoteTagsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun removeNoteTagsRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 8, input)
    }

    open fun removeNoteTags(noteIds: Iterable<Long>, tags: String): anki.collection.OpChangesWithCount {
        val builder = anki.tags.NoteIdsAndTagsRequest.newBuilder()
        builder.addAllNoteIds(noteIds)
        builder.setTags(tags)
        val input = builder.build() 
        val outputData = removeNoteTagsRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun findAndReplaceTagRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 9, input)
    }

    open fun findAndReplaceTag(noteIds: Iterable<Long>, search: String, replacement: String, regex: Boolean, matchCase: Boolean): anki.collection.OpChangesWithCount {
        val builder = anki.tags.FindAndReplaceTagRequest.newBuilder()
        builder.addAllNoteIds(noteIds)
        builder.setSearch(search)
        builder.setReplacement(replacement)
        builder.setRegex(regex)
        builder.setMatchCase(matchCase)
        val input = builder.build() 
        val outputData = findAndReplaceTagRaw(input.toByteArray())
        val output = anki.collection.OpChangesWithCount.parseFrom(outputData)
        return output
    }

    fun completeTagRaw(input: ByteArray): ByteArray {
        return runMethodRaw(45, 10, input)
    }

    open fun completeTag(input: String, matchLimit: Int): List<String> {
        val builder = anki.tags.CompleteTagRequest.newBuilder()
        builder.setInput(input)
        builder.setMatchLimit(matchLimit)
        val input = builder.build() 
        val outputData = completeTagRaw(input.toByteArray())
        val output = anki.tags.CompleteTagResponse.parseFrom(outputData)
        return output.tagsList
    }

/** RWKV scheduling (Hayaki ADR-0009): whether the switch is on and whether
 the model is ready. */
    fun rwkvStatusRaw(input: ByteArray): ByteArray {
        return runMethodRaw(47, 0, input)
    }
/** RWKV scheduling (Hayaki ADR-0009): whether the switch is on and whether
 the model is ready. */

    open fun rwkvStatus(): anki.zz_hayaki.RwkvStatusResponse {
        val builder = anki.generic.Empty.newBuilder()
        val input = builder.build() 
        val outputData = rwkvStatusRaw(input.toByteArray())
        val output = anki.zz_hayaki.RwkvStatusResponse.parseFrom(outputData)
        return output
    }

/** Downloads the model weights into weights_dir if they are missing, loads
 them, and starts preparing the open collection in the background.
 Returns once preparation has started; poll RwkvStatus for progress. */
    fun prepareRwkvRaw(input: ByteArray): ByteArray {
        return runMethodRaw(47, 1, input)
    }
/** Downloads the model weights into weights_dir if they are missing, loads
 them, and starts preparing the open collection in the background.
 Returns once preparation has started; poll RwkvStatus for progress. */

    open fun prepareRwkv(weightsDir: String): anki.zz_hayaki.RwkvStatusResponse {
        val builder = anki.zz_hayaki.PrepareRwkvRequest.newBuilder()
        builder.setWeightsDir(weightsDir)
        val input = builder.build() 
        val outputData = prepareRwkvRaw(input.toByteArray())
        val output = anki.zz_hayaki.RwkvStatusResponse.parseFrom(outputData)
        return output
    }

}

