// Copyright: Ankitects Pty Ltd and contributors
// License: GNU AGPL, version 3 or later; http://www.gnu.org/licenses/agpl.html

package anki.i18n;

import anki.i18n.TranslateArgValue

fun asTranslateArg(arg: Any): TranslateArgValue {
    val builder = TranslateArgValue.newBuilder()
    when (arg) {
        is String -> builder.setStr(arg)
        is Int -> builder.setNumber(arg.toDouble())
        is Double -> builder.setNumber(arg)
        else -> throw Exception("invalid arg provided to translation")
    }
    return builder.build()
}

// This should be either String, Double or Int
typealias TranslateArg = Any

typealias TranslateArgMap = Map<String, TranslateArgValue>

interface GeneratedTranslations {
    fun translate(module: Int, translation: Int, args: TranslateArgMap): String;



    /** A big thanks to all the people who have provided suggestions, bug reports and donations. */
    fun aboutABigThanksToAllThe(): String {
        return translate(0, 0, mapOf())
    }


    /** About Anki */
    fun aboutAboutAnki(): String {
        return translate(0, 1, mapOf())
    }


    /** and others */
    fun aboutAndOthers(): String {
        return translate(0, 2, mapOf())
    }


    /** Anki is a friendly, intelligent spaced learning system. It's free and open source. */
    fun aboutAnkiIsAFriendlyIntelligentSpaced(): String {
        return translate(0, 3, mapOf())
    }


    /** Anki is licensed under the AGPL3 license. Please see the license file in the source distribution for more information. */
    fun aboutAnkiIsLicensedUnderTheAgpl3(): String {
        return translate(0, 4, mapOf())
    }


    /** Copied to clipboard */
    fun aboutCopiedToClipboard(): String {
        return translate(0, 5, mapOf())
    }


    /** Copy Debug Info */
    fun aboutCopyDebugInfo(): String {
        return translate(0, 6, mapOf())
    }


    /** If you have contributed and are not on this list, please get in touch. */
    fun aboutIfYouHaveContributedAndAre(): String {
        return translate(0, 7, mapOf())
    }


    /** Version {$val} */
    fun aboutVersion(`val`: TranslateArg): String {
        return translate(0, 8, mapOf("val" to asTranslateArg(`val`)))
    }


    /** <a href='{$val}'>Visit website</a> */
    fun aboutVisitWebsite(`val`: TranslateArg): String {
        return translate(0, 9, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Written by Damien Elmes, with patches, translation,    testing and design from:<p>{$cont} */
    fun aboutWrittenByDamienElmesWithPatches(`cont`: String): String {
        return translate(0, 10, mapOf("cont" to asTranslateArg(`cont`)))
    }


    /** Add */
    fun actionsAdd(): String {
        return translate(1, 0, mapOf())
    }


    /** Add Deck */
    fun actionsAddDeck(): String {
        return translate(1, 1, mapOf())
    }


    /** Add Note */
    fun actionsAddNote(): String {
        return translate(1, 2, mapOf())
    }


    /** Add Note Type */
    fun actionsAddNotetype(): String {
        return translate(1, 3, mapOf())
    }


    /** All selected */
    fun actionsAllSelected(): String {
        return translate(1, 4, mapOf())
    }


    /** Answer Card */
    fun actionsAnswerCard(): String {
        return translate(1, 5, mapOf())
    }


    /** Any selected */
    fun actionsAnySelected(): String {
        return translate(1, 6, mapOf())
    }


    /** Auto Advance */
    fun actionsAutoAdvance(): String {
        return translate(1, 7, mapOf())
    }


    /** Auto Advance enabled */
    fun actionsAutoAdvanceActivated(): String {
        return translate(1, 8, mapOf())
    }


    /** Auto Advance disabled */
    fun actionsAutoAdvanceDeactivated(): String {
        return translate(1, 9, mapOf())
    }


    /** Build Deck */
    fun actionsBuildFilteredDeck(): String {
        return translate(1, 10, mapOf())
    }


    /** Cancel */
    fun actionsCancel(): String {
        return translate(1, 11, mapOf())
    }


    /** Card Info */
    fun actionsCardInfo(): String {
        return translate(1, 12, mapOf())
    }


    /** Choose */
    fun actionsChoose(): String {
        return translate(1, 13, mapOf())
    }


    /** Close */
    fun actionsClose(): String {
        return translate(1, 14, mapOf())
    }


    /** Copy */
    fun actionsCopy(): String {
        return translate(1, 15, mapOf())
    }


    /** Create Copy */
    fun actionsCreateCopy(): String {
        return translate(1, 16, mapOf())
    }


    /** Custom Study */
    fun actionsCustomStudy(): String {
        return translate(1, 17, mapOf())
    }


    /** Decks */
    fun actionsDecks(): String {
        return translate(1, 18, mapOf())
    }


    /** Decrement value */
    fun actionsDecrementValue(): String {
        return translate(1, 19, mapOf())
    }


    /** Delete */
    fun actionsDelete(): String {
        return translate(1, 20, mapOf())
    }


    /** Discard */
    fun actionsDiscard(): String {
        return translate(1, 21, mapOf())
    }


    /** Empty Cards */
    fun actionsEmptyCards(): String {
        return translate(1, 22, mapOf())
    }


    /** Export */
    fun actionsExport(): String {
        return translate(1, 23, mapOf())
    }


    /** Filter */
    fun actionsFilter(): String {
        return translate(1, 24, mapOf())
    }


    /** Blue */
    fun actionsFlagBlue(): String {
        return translate(1, 25, mapOf())
    }


    /** Green */
    fun actionsFlagGreen(): String {
        return translate(1, 26, mapOf())
    }


    /** Flag {$number} */
    fun actionsFlagNumber(`number`: TranslateArg): String {
        return translate(1, 27, mapOf("number" to asTranslateArg(`number`)))
    }


    /** Orange */
    fun actionsFlagOrange(): String {
        return translate(1, 28, mapOf())
    }


    /** Pink */
    fun actionsFlagPink(): String {
        return translate(1, 29, mapOf())
    }


    /** Purple */
    fun actionsFlagPurple(): String {
        return translate(1, 30, mapOf())
    }


    /** Red */
    fun actionsFlagRed(): String {
        return translate(1, 31, mapOf())
    }


    /** Turquoise */
    fun actionsFlagTurquoise(): String {
        return translate(1, 32, mapOf())
    }


    /** Reset Card */
    fun actionsForgetCard(): String {
        return translate(1, 33, mapOf())
    }


    /** Full screen mode is not supported for your video driver. Try switching to a different one from the preferences screen. */
    fun actionsFullscreenUnsupported(): String {
        return translate(1, 34, mapOf())
    }


    /** Grade Now */
    fun actionsGradeNow(): String {
        return translate(1, 35, mapOf())
    }


    /** Help */
    fun actionsHelp(): String {
        return translate(1, 36, mapOf())
    }


    /** Import */
    fun actionsImport(): String {
        return translate(1, 37, mapOf())
    }


    /** Increment value */
    fun actionsIncrementValue(): String {
        return translate(1, 38, mapOf())
    }


    /** Manage... */
    fun actionsManage(): String {
        return translate(1, 39, mapOf())
    }


    /** Name: */
    fun actionsName(): String {
        return translate(1, 40, mapOf())
    }


    /** New */
    fun actionsNew(): String {
        return translate(1, 41, mapOf())
    }


    /** New name: */
    fun actionsNewName(): String {
        return translate(1, 42, mapOf())
    }


    /** Nothing to redo */
    fun actionsNothingToRedo(): String {
        return translate(1, 43, mapOf())
    }


    /** Nothing to undo */
    fun actionsNothingToUndo(): String {
        return translate(1, 44, mapOf())
    }


    /** Options */
    fun actionsOptions(): String {
        return translate(1, 45, mapOf())
    }


    /** Options for {$val} */
    fun actionsOptionsFor(`val`: TranslateArg): String {
        return translate(1, 46, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Preview */
    fun actionsPreview(): String {
        return translate(1, 47, mapOf())
    }


    /** Previous Card Info */
    fun actionsPreviousCardInfo(): String {
        return translate(1, 48, mapOf())
    }


    /** Processing... */
    fun actionsProcessing(): String {
        return translate(1, 49, mapOf())
    }


    /** Rebuild */
    fun actionsRebuild(): String {
        return translate(1, 50, mapOf())
    }


    /** Remove Note Type */
    fun actionsRemoveNotetype(): String {
        return translate(1, 51, mapOf())
    }


    /** Remove Tag */
    fun actionsRemoveTag(): String {
        return translate(1, 52, mapOf())
    }


    /** Rename */
    fun actionsRename(): String {
        return translate(1, 53, mapOf())
    }


    /** Rename Deck */
    fun actionsRenameDeck(): String {
        return translate(1, 54, mapOf())
    }


    /** Rename Tag */
    fun actionsRenameTag(): String {
        return translate(1, 55, mapOf())
    }


    /** Rename with Parents */
    fun actionsRenameWithParents(): String {
        return translate(1, 56, mapOf())
    }


    /** Replay Audio */
    fun actionsReplayAudio(): String {
        return translate(1, 57, mapOf())
    }


    /** Reposition */
    fun actionsReposition(): String {
        return translate(1, 58, mapOf())
    }


    /** Save */
    fun actionsSave(): String {
        return translate(1, 59, mapOf())
    }


    /** Search */
    fun actionsSearch(): String {
        return translate(1, 60, mapOf())
    }


    /** Select */
    fun actionsSelect(): String {
        return translate(1, 61, mapOf())
    }


    /** Set Due Date */
    fun actionsSetDueDate(): String {
        return translate(1, 62, mapOf())
    }


    /** Set Flag */
    fun actionsSetFlag(): String {
        return translate(1, 63, mapOf())
    }


    /** Shortcut key: {$val} */
    fun actionsShortcutKey(`val`: TranslateArg): String {
        return translate(1, 64, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Suspend Card */
    fun actionsSuspendCard(): String {
        return translate(1, 65, mapOf())
    }


    /** Toggle Load Balancer */
    fun actionsToggleLoadBalancer(): String {
        return translate(1, 66, mapOf())
    }


    /** Unbury/Unsuspend */
    fun actionsUnburyUnsuspend(): String {
        return translate(1, 67, mapOf())
    }


    /** Update Card */
    fun actionsUpdateCard(): String {
        return translate(1, 68, mapOf())
    }


    /** Update Config */
    fun actionsUpdateConfig(): String {
        return translate(1, 69, mapOf())
    }


    /** Update Deck */
    fun actionsUpdateDeck(): String {
        return translate(1, 70, mapOf())
    }


    /** Update Note */
    fun actionsUpdateNote(): String {
        return translate(1, 71, mapOf())
    }


    /** Update Note Type */
    fun actionsUpdateNotetype(): String {
        return translate(1, 72, mapOf())
    }


    /** Update Tag */
    fun actionsUpdateTag(): String {
        return translate(1, 73, mapOf())
    }


    /** {$action}... */
    fun actionsWithEllipsis(`action`: String): String {
        return translate(1, 74, mapOf("action" to asTranslateArg(`action`)))
    }


    /** Add (shortcut: ctrl+enter) */
    fun addingAddShortcutCtrlandenter(): String {
        return translate(2, 0, mapOf())
    }


    /** Added */
    fun addingAdded(): String {
        return translate(2, 1, mapOf())
    }


    /** Cloze deletion can only be used in fields which use the 'cloze:' filter. This is typically the first field. */
    fun addingClozeOutsideClozeField(): String {
        return translate(2, 2, mapOf())
    }


    /** Cloze deletion can only be used on cloze note types. */
    fun addingClozeOutsideClozeNotetype(): String {
        return translate(2, 3, mapOf())
    }


    /** Discard current input? */
    fun addingDiscardCurrentInput(): String {
        return translate(2, 4, mapOf())
    }


    /** Edit "{$val}" */
    fun addingEdit(`val`: TranslateArg): String {
        return translate(2, 5, mapOf("val" to asTranslateArg(`val`)))
    }


    /** History */
    fun addingHistory(): String {
        return translate(2, 6, mapOf())
    }


    /** Keep Editing */
    fun addingKeepEditing(): String {
        return translate(2, 7, mapOf())
    }


    /** (Note deleted) */
    fun addingNoteDeleted(): String {
        return translate(2, 8, mapOf())
    }


    /** Shortcut: {$val} */
    fun addingShortcut(`val`: TranslateArg): String {
        return translate(2, 9, mapOf("val" to asTranslateArg(`val`)))
    }


    /** The first field is empty. */
    fun addingTheFirstFieldIsEmpty(): String {
        return translate(2, 10, mapOf())
    }


    /** You have a cloze note type but have not made any cloze deletions. Proceed? */
    fun addingYouHaveAClozeDeletionNote(): String {
        return translate(2, 11, mapOf())
    }


    /** Add-on has no configuration. */
    fun addonsAddonHasNoConfiguration(): String {
        return translate(3, 0, mapOf())
    }


    /** Add-on installation error */
    fun addonsAddonInstallationError(): String {
        return translate(3, 1, mapOf())
    }


    /** Browse Add-ons */
    fun addonsBrowseAddons(): String {
        return translate(3, 2, mapOf())
    }


    /** Changes will take effect when Anki is restarted. */
    fun addonsChangesWillTakeEffectWhenAnki(): String {
        return translate(3, 3, mapOf())
    }


    /** Check for Updates */
    fun addonsCheckForUpdates(): String {
        return translate(3, 4, mapOf())
    }


    /** Checking... */
    fun addonsChecking(): String {
        return translate(3, 5, mapOf())
    }


    /** Update All */
    fun addonsChooseUpdateUpdateAll(): String {
        return translate(3, 6, mapOf())
    }


    /** Update Add-ons */
    fun addonsChooseUpdateWindowTitle(): String {
        return translate(3, 7, mapOf())
    }


    /** Code: */
    fun addonsCode(): String {
        return translate(3, 8, mapOf())
    }


    /** Config */
    fun addonsConfig(): String {
        return translate(3, 9, mapOf())
    }


    /** There was a problem with the provided configuration: {$problem}, at path {$path}, against schema {$schema}. */
    fun addonsConfigValidationError(`problem`: String, `path`: String, `schema`: String): String {
        return translate(3, 10, mapOf("problem" to asTranslateArg(`problem`), "path" to asTranslateArg(`path`), "schema" to asTranslateArg(`schema`)))
    }


    /** Configure '{$name}' */
    fun addonsConfigWindowTitle(`name`: String): String {
        return translate(3, 11, mapOf("name" to asTranslateArg(`name`)))
    }


    /** Configuration */
    fun addonsConfiguration(): String {
        return translate(3, 12, mapOf())
    }


    /** Corrupt add-on file. */
    fun addonsCorruptAddonFile(): String {
        return translate(3, 13, mapOf())
    }


    /** Delete the {$count} selected add-ons? */
    fun addonsDeleteTheNumdSelectedAddon(`count`: Int): String {
        return translate(3, 14, mapOf("count" to asTranslateArg(`count`)))
    }


    /** (disabled) */
    fun addonsDisabled(): String {
        return translate(3, 15, mapOf())
    }


    /** (disabled) */
    fun addonsDisabled2(): String {
        return translate(3, 16, mapOf())
    }


    /** Download complete. Please restart Anki to apply changes. */
    fun addonsDownloadCompletePleaseRestartAnkiTo(): String {
        return translate(3, 17, mapOf())
    }


    /** Downloaded {$fname} */
    fun addonsDownloadedFnames(`fname`: String): String {
        return translate(3, 18, mapOf("fname" to asTranslateArg(`fname`)))
    }


    /** Downloading {$part}/{$total} ({$kilobytes}KB)... */
    fun addonsDownloadingAdbdKb02fkb(`part`: TranslateArg, `total`: Int, `kilobytes`: Int): String {
        return translate(3, 19, mapOf("part" to asTranslateArg(`part`), "total" to asTranslateArg(`total`), "kilobytes" to asTranslateArg(`kilobytes`)))
    }


    /** Error downloading <i>{$id}</i>: {$error} */
    fun addonsErrorDownloadingIdsErrors(`id`: String, `error`: String): String {
        return translate(3, 20, mapOf("id" to asTranslateArg(`id`), "error" to asTranslateArg(`error`)))
    }


    /** Error installing <i>{$base}</i>: {$error} */
    fun addonsErrorInstallingBasesErrors(`base`: String, `error`: String): String {
        return translate(3, 21, mapOf("base" to asTranslateArg(`base`), "error" to asTranslateArg(`error`)))
    }


    /** An add-on you installed failed to load. If problems persist, please go to the Tools>Add-ons menu, and disable or delete the add-on.

When loading '{$name}':
{$traceback} */
    fun addonsFailedToLoad(`name`: String, `traceback`: String): String {
        return translate(3, 22, mapOf("name" to asTranslateArg(`name`), "traceback" to asTranslateArg(`traceback`)))
    }


    /** The following add-ons failed to load:
{$addons}

They may need to be updated to support this version of Anki. Click the  button
to see if any updates are available.

You can use the  button to get information that you can paste in a report to
the add-on author.

For add-ons that don't have an update available, you can disable or delete the add-on to prevent this
message from appearing. */
    fun addonsFailedToLoad2(`addons`: String): String {
        return translate(3, 23, mapOf("addons" to asTranslateArg(`addons`)))
    }


    /** Get Add-ons... */
    fun addonsGetAddons(): String {
        return translate(3, 24, mapOf())
    }


    /** <b>Important</b>: As add-ons are programs downloaded from the internet, they are potentially malicious.<b>You should only install add-ons you trust.</b><br><br>Are you sure you want to proceed with the installation of the following Anki add-on(s)?<br><br>%(names)s */
    fun addonsImportantAsAddonsAreProgramsDownloaded(): String {
        return translate(3, 25, mapOf())
    }


    /** Install Add-on */
    fun addonsInstallAddon(): String {
        return translate(3, 26, mapOf())
    }


    /** Install Add-on(s) */
    fun addonsInstallAddons(): String {
        return translate(3, 27, mapOf())
    }


    /** Install Anki add-on */
    fun addonsInstallAnkiAddon(): String {
        return translate(3, 28, mapOf())
    }


    /** Install from file... */
    fun addonsInstallFromFile(): String {
        return translate(3, 29, mapOf())
    }


    /** Installation complete */
    fun addonsInstallationComplete(): String {
        return translate(3, 30, mapOf())
    }


    /** Installed {$name} */
    fun addonsInstalledNames(`name`: String): String {
        return translate(3, 31, mapOf("name" to asTranslateArg(`name`)))
    }


    /** Installed successfully. */
    fun addonsInstalledSuccessfully(): String {
        return translate(3, 32, mapOf())
    }


    /** Invalid add-on manifest. */
    fun addonsInvalidAddonManifest(): String {
        return translate(3, 33, mapOf())
    }


    /** Invalid code. */
    fun addonsInvalidCode(): String {
        return translate(3, 34, mapOf())
    }


    /** Invalid code, or add-on not available for your version of Anki. */
    fun addonsInvalidCodeOrAddonNotAvailable(): String {
        return translate(3, 35, mapOf())
    }


    /** Invalid configuration: */
    fun addonsInvalidConfiguration(): String {
        return translate(3, 36, mapOf())
    }


    /** Invalid configuration: top level object must be a map */
    fun addonsInvalidConfigurationTopLevelObjectMust(): String {
        return translate(3, 37, mapOf())
    }


    /** No updates available. */
    fun addonsNoUpdatesAvailable(): String {
        return translate(3, 38, mapOf())
    }


    /** One or more errors occurred: */
    fun addonsOneOrMoreErrorsOccurred(): String {
        return translate(3, 39, mapOf())
    }


    /** Packaged Anki Add-on */
    fun addonsPackagedAnkiAddon(): String {
        return translate(3, 40, mapOf())
    }


    /** Please check your internet connection. */
    fun addonsPleaseCheckYourInternetConnection(): String {
        return translate(3, 41, mapOf())
    }


    /** Please report this to the respective add-on author(s). */
    fun addonsPleaseReportThisToTheRespective(): String {
        return translate(3, 42, mapOf())
    }


    /** <b>Please restart Anki to complete the installation.</b> */
    fun addonsPleaseRestartAnkiToCompleteThe(): String {
        return translate(3, 43, mapOf())
    }


    /** Please select a single add-on first. */
    fun addonsPleaseSelectASingleAddonFirst(): String {
        return translate(3, 44, mapOf())
    }


    /** Add-ons possibly involved: {$addons} */
    fun addonsPossiblyInvolved(`addons`: String): String {
        return translate(3, 45, mapOf("addons" to asTranslateArg(`addons`)))
    }


    /** (requires {$val}) */
    fun addonsRequires(`val`: TranslateArg): String {
        return translate(3, 46, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Restored defaults */
    fun addonsRestoredDefaults(): String {
        return translate(3, 47, mapOf())
    }


    /** Add-on Startup Failed */
    fun addonsStartupFailed(): String {
        return translate(3, 48, mapOf())
    }


    /** The following add-ons are incompatible with {$name} and have been disabled: {$found} */
    fun addonsTheFollowingAddonsAreIncompatibleWith(`name`: String, `found`: TranslateArg): String {
        return translate(3, 49, mapOf("name" to asTranslateArg(`name`), "found" to asTranslateArg(`found`)))
    }


    /** The following add-ons have updates available. Install them now? */
    fun addonsTheFollowingAddonsHaveUpdatesAvailable(): String {
        return translate(3, 50, mapOf())
    }


    /** The following conflicting add-ons were disabled: */
    fun addonsTheFollowingConflictingAddonsWereDisabled(): String {
        return translate(3, 51, mapOf())
    }


    /** This add-on is not compatible with your version of Anki. */
    fun addonsThisAddonIsNotCompatibleWith(): String {
        return translate(3, 52, mapOf())
    }


    /** To browse add-ons, please click the browse button below.<br><br>When you've found an add-on you like, please paste its code below. You can paste multiple codes, separated by spaces. */
    fun addonsToBrowseAddonsPleaseClickThe(): String {
        return translate(3, 53, mapOf())
    }


    /** Toggle Enabled */
    fun addonsToggleEnabled(): String {
        return translate(3, 54, mapOf())
    }


    /** Unable to update or delete add-on. Please start Anki while holding down the shift key to temporarily disable add-ons, then try again.  Debug info: {$val} */
    fun addonsUnableToUpdateOrDeleteAddon(`val`: TranslateArg): String {
        return translate(3, 55, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Unknown error: {$val} */
    fun addonsUnknownError(`val`: TranslateArg): String {
        return translate(3, 56, mapOf("val" to asTranslateArg(`val`)))
    }


    /** View Add-on Page */
    fun addonsViewAddonPage(): String {
        return translate(3, 57, mapOf())
    }


    /** View Files */
    fun addonsViewFiles(): String {
        return translate(3, 58, mapOf())
    }


    /** Add-ons */
    fun addonsWindowTitle(): String {
        return translate(3, 59, mapOf())
    }


    /** Add Notes... */
    fun browsingAddNotes(): String {
        return translate(4, 0, mapOf())
    }


    /** Add Tags... */
    fun browsingAddTags2(): String {
        return translate(4, 1, mapOf())
    }


    /** Add to Selected Notes */
    fun browsingAddToSelectedNotes(): String {
        return translate(4, 2, mapOf())
    }


    /** Added */
    fun browsingAddedToday(): String {
        return translate(4, 3, mapOf())
    }


    /** Add-on */
    fun browsingAddon(): String {
        return translate(4, 4, mapOf())
    }


    /** Again */
    fun browsingAgainToday(): String {
        return translate(4, 5, mapOf())
    }


    /** All Fields */
    fun browsingAllFields(): String {
        return translate(4, 6, mapOf())
    }


    /** Answer */
    fun browsingAnswer(): String {
        return translate(4, 7, mapOf())
    }


    /** Any Flag */
    fun browsingAnyFlag(): String {
        return translate(4, 8, mapOf())
    }


    /** Avg. Ease */
    fun browsingAverageEase(): String {
        return translate(4, 9, mapOf())
    }


    /** Avg. Interval */
    fun browsingAverageInterval(): String {
        return translate(4, 10, mapOf())
    }


    /** Browser Appearance */
    fun browsingBrowserAppearance(): String {
        return translate(4, 11, mapOf())
    }


    /** Browser Options */
    fun browsingBrowserOptions(): String {
        return translate(4, 12, mapOf())
    }


    /** Buried */
    fun browsingBuried(): String {
        return translate(4, 13, mapOf())
    }


    /** Card */
    fun browsingCard(): String {
        return translate(4, 14, mapOf())
    }


    /** C */
    fun browsingCardInitial(): String {
        return translate(4, 15, mapOf())
    }


    /** Card List */
    fun browsingCardList(): String {
        return translate(4, 16, mapOf())
    }


    /** Cards */
    fun browsingCards(): String {
        return translate(4, 17, mapOf())
    }


    /** Cards can't be manually moved into a filtered deck. */
    fun browsingCardsCantBeManuallyMovedInto(): String {
        return translate(4, 18, mapOf())
    }


    /** {$count} cards deleted. */
    fun browsingCardsDeleted(`count`: Int): String {
        return translate(4, 19, mapOf("count" to asTranslateArg(`count`)))
    }


    /** {$count} cards deleted from {$deck_name}. */
    fun browsingCardsDeletedWithDeckname(`count`: Int, `deckName`: String): String {
        return translate(4, 20, mapOf("count" to asTranslateArg(`count`), "deck_name" to asTranslateArg(`deckName`)))
    }


    /** {$count} cards updated. */
    fun browsingCardsUpdated(`count`: Int): String {
        return translate(4, 21, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Change Deck */
    fun browsingChangeDeck(): String {
        return translate(4, 22, mapOf())
    }


    /** Change Deck... */
    fun browsingChangeDeck2(): String {
        return translate(4, 23, mapOf())
    }


    /** Change Note Type */
    fun browsingChangeNoteType(): String {
        return translate(4, 24, mapOf())
    }


    /** Change Note Type... */
    fun browsingChangeNoteType2(): String {
        return translate(4, 25, mapOf())
    }


    /** Change Note Type */
    fun browsingChangeNotetype(): String {
        return translate(4, 26, mapOf())
    }


    /** Changed position of {$count} new cards. */
    fun browsingChangedNewPosition(`count`: Int): String {
        return translate(4, 27, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Clear Unused Tags */
    fun browsingClearUnusedTags(): String {
        return translate(4, 28, mapOf())
    }


    /** A saved search with the name {$name} already exists. Do you want to overwrite it? */
    fun browsingConfirmSavedSearchOverwrite(`name`: String): String {
        return translate(4, 29, mapOf("name" to asTranslateArg(`name`)))
    }


    /** Created */
    fun browsingCreated(): String {
        return translate(4, 30, mapOf())
    }


    /** Current Deck */
    fun browsingCurrentDeck(): String {
        return translate(4, 31, mapOf())
    }


    /** Current note type: */
    fun browsingCurrentNoteType(): String {
        return translate(4, 32, mapOf())
    }


    /** Delete Notes */
    fun browsingDeleteNotes(): String {
        return translate(4, 33, mapOf())
    }


    /** Now */
    fun browsingDueNow(): String {
        return translate(4, 34, mapOf())
    }


    /** duplicate */
    fun browsingDuplicate(): String {
        return translate(4, 35, mapOf())
    }


    /** Ease */
    fun browsingEase(): String {
        return translate(4, 36, mapOf())
    }


    /** Edited */
    fun browsingEditedToday(): String {
        return translate(4, 37, mapOf())
    }


    /** Clear search */
    fun browsingEmptyClearSearch(): String {
        return translate(4, 38, mapOf())
    }


    /** No cards yet */
    fun browsingEmptyCollectionTitle(`notesMode`: String): String {
        return translate(4, 39, mapOf("notes-mode" to asTranslateArg(`notesMode`)))
    }


    /** No cards match this search */
    fun browsingEmptyNoMatchTitle(`notesMode`: String): String {
        return translate(4, 40, mapOf("notes-mode" to asTranslateArg(`notesMode`)))
    }


    /** Enter tags to add: */
    fun browsingEnterTagsToAdd(): String {
        return translate(4, 41, mapOf())
    }


    /** Enter tags to delete: */
    fun browsingEnterTagsToDelete(): String {
        return translate(4, 42, mapOf())
    }


    /** (filtered) */
    fun browsingFiltered(): String {
        return translate(4, 43, mapOf())
    }


    /** <b>Find</b>: */
    fun browsingFind(): String {
        return translate(4, 44, mapOf())
    }


    /** Find and Replace */
    fun browsingFindAndReplace(): String {
        return translate(4, 45, mapOf())
    }


    /** Find Duplicates */
    fun browsingFindDuplicates(): String {
        return translate(4, 46, mapOf())
    }


    /** First Card */
    fun browsingFirstCard(): String {
        return translate(4, 47, mapOf())
    }


    /** Flag */
    fun browsingFlag(): String {
        return translate(4, 48, mapOf())
    }


    /** <b>Font</b>: */
    fun browsingFont(): String {
        return translate(4, 49, mapOf())
    }


    /** <b>Font Size</b>: */
    fun browsingFontSize(): String {
        return translate(4, 50, mapOf())
    }


    /** Found {$part} across {$whole}. */
    fun browsingFoundAsAcrossBs(`part`: TranslateArg, `whole`: String): String {
        return translate(4, 51, mapOf("part" to asTranslateArg(`part`), "whole" to asTranslateArg(`whole`)))
    }


    /** {$count} groups */
    fun browsingGroup(`count`: Int): String {
        return translate(4, 52, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Ignore case */
    fun browsingIgnoreCase(): String {
        return translate(4, 53, mapOf())
    }


    /** <b>In</b>: */
    fun browsingIn(): String {
        return translate(4, 54, mapOf())
    }


    /** Interval */
    fun browsingInterval(): String {
        return translate(4, 55, mapOf())
    }


    /** Last Card */
    fun browsingLastCard(): String {
        return translate(4, 56, mapOf())
    }


    /** (learning) */
    fun browsingLearning(): String {
        return translate(4, 57, mapOf())
    }


    /** Leech */
    fun browsingLeech(): String {
        return translate(4, 58, mapOf())
    }


    /** Leech, {$count} lapses */
    fun browsingLeechLapses(`count`: Int): String {
        return translate(4, 59, mapOf("count" to asTranslateArg(`count`)))
    }


    /** <b>Line Size</b>: */
    fun browsingLineSize(): String {
        return translate(4, 60, mapOf())
    }


    /** Manage Note Types */
    fun browsingManageNoteTypes(): String {
        return translate(4, 61, mapOf())
    }


    /** {$count} more tags */
    fun browsingMoreTags(`count`: Int): String {
        return translate(4, 62, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Move Cards */
    fun browsingMoveCards(): String {
        return translate(4, 63, mapOf())
    }


    /** Move cards to deck: */
    fun browsingMoveCardsToDeck(): String {
        return translate(4, 64, mapOf())
    }


    /** (new) */
    fun browsingNew(): String {
        return translate(4, 65, mapOf())
    }


    /** New note type: */
    fun browsingNewNoteType(): String {
        return translate(4, 66, mapOf())
    }


    /** No Flag */
    fun browsingNoFlag(): String {
        return translate(4, 67, mapOf())
    }


    /** No cards or notes selected. */
    fun browsingNoSelection(): String {
        return translate(4, 68, mapOf())
    }


    /** Note */
    fun browsingNote(): String {
        return translate(4, 69, mapOf())
    }


    /** {$count} notes */
    fun browsingNoteCount(`count`: Int): String {
        return translate(4, 70, mapOf("count" to asTranslateArg(`count`)))
    }


    /** N */
    fun browsingNoteInitial(): String {
        return translate(4, 71, mapOf())
    }


    /** Notes */
    fun browsingNotes(): String {
        return translate(4, 72, mapOf())
    }


    /** {$count} notes updated. */
    fun browsingNotesUpdated(`count`: Int): String {
        return translate(4, 73, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Optional filter: */
    fun browsingOptionalFilter(): String {
        return translate(4, 74, mapOf())
    }


    /** Override back template: */
    fun browsingOverrideBackTemplate(): String {
        return translate(4, 75, mapOf())
    }


    /** Override font: */
    fun browsingOverrideFont(): String {
        return translate(4, 76, mapOf())
    }


    /** Override front template: */
    fun browsingOverrideFrontTemplate(): String {
        return translate(4, 77, mapOf())
    }


    /** Please give your filter a name: */
    fun browsingPleaseGiveYourFilterAName(): String {
        return translate(4, 78, mapOf())
    }


    /** Preview Selected Card ({$val}) */
    fun browsingPreviewSelectedCard(`val`: TranslateArg): String {
        return translate(4, 79, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Question */
    fun browsingQuestion(): String {
        return translate(4, 80, mapOf())
    }


    /** Queue bottom: {$val} */
    fun browsingQueueBottom(`val`: TranslateArg): String {
        return translate(4, 81, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Queue top: {$val} */
    fun browsingQueueTop(`val`: TranslateArg): String {
        return translate(4, 82, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Randomize order */
    fun browsingRandomizeOrder(): String {
        return translate(4, 83, mapOf())
    }


    /** Remove from Selected Notes */
    fun browsingRemoveFromSelectedNotes(): String {
        return translate(4, 84, mapOf())
    }


    /** Remove Tags... */
    fun browsingRemoveTags(): String {
        return translate(4, 85, mapOf())
    }


    /** Removed {$count} unused tags. */
    fun browsingRemovedUnusedTagsCount(`count`: Int): String {
        return translate(4, 86, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Renamed {$count} decks. */
    fun browsingReparentedDecks(`count`: Int): String {
        return translate(4, 87, mapOf("count" to asTranslateArg(`count`)))
    }


    /** <b>Replace With</b>: */
    fun browsingReplaceWith(): String {
        return translate(4, 88, mapOf())
    }


    /** Reposition... */
    fun browsingReposition(): String {
        return translate(4, 89, mapOf())
    }


    /** Reposition New Cards */
    fun browsingRepositionNewCards(): String {
        return translate(4, 90, mapOf())
    }


    /** Reschedule */
    fun browsingReschedule(): String {
        return translate(4, 91, mapOf())
    }


    /** (deleted) */
    fun browsingRowDeleted(): String {
        return translate(4, 92, mapOf())
    }


    /** Search cards/notes (type text, then press Enter) */
    fun browsingSearchBarHint(): String {
        return translate(4, 93, mapOf())
    }


    /** Filter by */
    fun browsingSearchFacetStarters(): String {
        return translate(4, 94, mapOf())
    }


    /** Search in: */
    fun browsingSearchIn(): String {
        return translate(4, 95, mapOf())
    }


    /** Quick filters */
    fun browsingSearchQuick(): String {
        return translate(4, 96, mapOf())
    }


    /** Flagged */
    fun browsingSearchQuickFlagged(): String {
        return translate(4, 97, mapOf())
    }


    /** Leeches */
    fun browsingSearchQuickLeeches(): String {
        return translate(4, 98, mapOf())
    }


    /** Recent */
    fun browsingSearchRecent(): String {
        return translate(4, 99, mapOf())
    }


    /** Results unchanged until the search is valid */
    fun browsingSearchResultsUnchanged(): String {
        return translate(4, 100, mapOf())
    }


    /** Suggestions */
    fun browsingSearchSuggestions(): String {
        return translate(4, 101, mapOf())
    }


    /** Syntax mode */
    fun browsingSearchSyntaxMode(): String {
        return translate(4, 102, mapOf())
    }


    /** Search "{$query}" */
    fun browsingSearchTextMatch(`query`: String): String {
        return translate(4, 103, mapOf("query" to asTranslateArg(`query`)))
    }


    /** Search within formatting (slow) */
    fun browsingSearchWithinFormattingSlow(): String {
        return translate(4, 104, mapOf())
    }


    /** Select Deck */
    fun browsingSelectDeck(): String {
        return translate(4, 105, mapOf())
    }


    /** Selected notes only */
    fun browsingSelectedNotesOnly(): String {
        return translate(4, 106, mapOf())
    }


    /** Shift position of existing cards */
    fun browsingShiftPositionOfExistingCards(): String {
        return translate(4, 107, mapOf())
    }


    /** Sidebar */
    fun browsingSidebar(): String {
        return translate(4, 108, mapOf())
    }


    /** Card State */
    fun browsingSidebarCardState(): String {
        return translate(4, 109, mapOf())
    }


    /** Review */
    fun browsingSidebarCardStateReview(): String {
        return translate(4, 110, mapOf())
    }


    /** Collapse */
    fun browsingSidebarCollapse(): String {
        return translate(4, 111, mapOf())
    }


    /** Collapse Children */
    fun browsingSidebarCollapseChildren(): String {
        return translate(4, 112, mapOf())
    }


    /** Decks */
    fun browsingSidebarDecks(): String {
        return translate(4, 113, mapOf())
    }


    /** Due */
    fun browsingSidebarDueToday(): String {
        return translate(4, 114, mapOf())
    }


    /** Expand */
    fun browsingSidebarExpand(): String {
        return translate(4, 115, mapOf())
    }


    /** Expand Children */
    fun browsingSidebarExpandChildren(): String {
        return translate(4, 116, mapOf())
    }


    /** Sidebar filter */
    fun browsingSidebarFilter(): String {
        return translate(4, 117, mapOf())
    }


    /** First Review */
    fun browsingSidebarFirstReview(): String {
        return translate(4, 118, mapOf())
    }


    /** Flags */
    fun browsingSidebarFlags(): String {
        return translate(4, 119, mapOf())
    }


    /** Note Types */
    fun browsingSidebarNotetypes(): String {
        return translate(4, 120, mapOf())
    }


    /** Overdue */
    fun browsingSidebarOverdue(): String {
        return translate(4, 121, mapOf())
    }


    /** Rescheduled */
    fun browsingSidebarRescheduled(): String {
        return translate(4, 122, mapOf())
    }


    /** Save Current Search */
    fun browsingSidebarSaveCurrentSearch(): String {
        return translate(4, 123, mapOf())
    }


    /** Saved Searches */
    fun browsingSidebarSavedSearches(): String {
        return translate(4, 124, mapOf())
    }


    /** Tags */
    fun browsingSidebarTags(): String {
        return translate(4, 125, mapOf())
    }


    /** Untagged */
    fun browsingSidebarUntagged(): String {
        return translate(4, 126, mapOf())
    }


    /** Sort Field */
    fun browsingSortField(): String {
        return translate(4, 127, mapOf())
    }


    /** Sorting on this column is not supported. Please choose another. */
    fun browsingSortingOnThisColumnIsNot(): String {
        return translate(4, 128, mapOf())
    }


    /** Start position: */
    fun browsingStartPosition(): String {
        return translate(4, 129, mapOf())
    }


    /** Step: */
    fun browsingStep(): String {
        return translate(4, 130, mapOf())
    }


    /** Studied */
    fun browsingStudiedToday(): String {
        return translate(4, 131, mapOf())
    }


    /** Suspended */
    fun browsingSuspended(): String {
        return translate(4, 132, mapOf())
    }


    /** Tag Duplicates */
    fun browsingTagDuplicates(): String {
        return translate(4, 133, mapOf())
    }


    /** You can't rename a tag that has no notes. */
    fun browsingTagRenameWarningEmpty(): String {
        return translate(4, 134, mapOf())
    }


    /** Target field: */
    fun browsingTargetField(): String {
        return translate(4, 135, mapOf())
    }


    /** Today */
    fun browsingToday(): String {
        return translate(4, 136, mapOf())
    }


    /** Toggle Bury */
    fun browsingToggleBury(): String {
        return translate(4, 137, mapOf())
    }


    /** Toggle Mark */
    fun browsingToggleMark(): String {
        return translate(4, 138, mapOf())
    }


    /** Toggle Cards/Notes */
    fun browsingToggleShowingCardsNotes(): String {
        return translate(4, 139, mapOf())
    }


    /** Toggle Suspend */
    fun browsingToggleSuspend(): String {
        return translate(4, 140, mapOf())
    }


    /** The back side of a card, customisable in the card template editor */
    fun browsingTooltipAnswer(): String {
        return translate(4, 141, mapOf())
    }


    /** The name of a card's card template */
    fun browsingTooltipCard(): String {
        return translate(4, 142, mapOf())
    }


    /** The last time changes were made to a card, including reviews, flags and deck changes */
    fun browsingTooltipCardModified(): String {
        return translate(4, 143, mapOf())
    }


    /** The number of cards a note has */
    fun browsingTooltipCards(): String {
        return translate(4, 144, mapOf())
    }


    /** The last time changes were made to a note, usually field content or tag edits */
    fun browsingTooltipNoteModified(): String {
        return translate(4, 145, mapOf())
    }


    /** The name of a note's note type */
    fun browsingTooltipNotetype(): String {
        return translate(4, 146, mapOf())
    }


    /** The front side of a card, customisable in the card template editor */
    fun browsingTooltipQuestion(): String {
        return translate(4, 147, mapOf())
    }


    /** Treat input as regular expression */
    fun browsingTreatInputAsRegularExpression(): String {
        return translate(4, 148, mapOf())
    }


    /** Update with Current Search */
    fun browsingUpdateSavedSearch(): String {
        return translate(4, 149, mapOf())
    }


    /** Whole Collection */
    fun browsingWholeCollection(): String {
        return translate(4, 150, mapOf())
    }


    /** Browse ({$selected} of {$total} cards selected) */
    fun browsingWindowTitle(`selected`: Int, `total`: Int): String {
        return translate(4, 151, mapOf("selected" to asTranslateArg(`selected`), "total" to asTranslateArg(`total`)))
    }


    /** Browse ({$selected} of {$total} notes selected) */
    fun browsingWindowTitleNotes(`selected`: Int, `total`: Int): String {
        return translate(4, 152, mapOf("selected" to asTranslateArg(`selected`), "total" to asTranslateArg(`total`)))
    }


    /** You must have at least one column. */
    fun browsingYouMustHaveAtLeastOne(): String {
        return translate(4, 153, mapOf())
    }


    /** Added */
    fun cardStatsAdded(): String {
        return translate(5, 0, mapOf())
    }


    /** Average Time */
    fun cardStatsAverageTime(): String {
        return translate(5, 1, mapOf())
    }


    /** Card ID */
    fun cardStatsCardId(): String {
        return translate(5, 2, mapOf())
    }


    /** Card Type */
    fun cardStatsCardTemplate(): String {
        return translate(5, 3, mapOf())
    }


    /** Current Card ({$context}) */
    fun cardStatsCurrentCard(`context`: String): String {
        return translate(5, 4, mapOf("context" to asTranslateArg(`context`)))
    }


    /** Custom Data */
    fun cardStatsCustomData(): String {
        return translate(5, 5, mapOf())
    }


    /** Deck */
    fun cardStatsDeckName(): String {
        return translate(5, 6, mapOf())
    }


    /** Ease */
    fun cardStatsEase(): String {
        return translate(5, 7, mapOf())
    }


    /** First Review */
    fun cardStatsFirstReview(): String {
        return translate(5, 8, mapOf())
    }


    /** Difficulty */
    fun cardStatsFsrsDifficulty(): String {
        return translate(5, 9, mapOf())
    }


    /** All Time */
    fun cardStatsFsrsForgettingCurveAllTime(): String {
        return translate(5, 10, mapOf())
    }


    /** Desired Retention */
    fun cardStatsFsrsForgettingCurveDesiredRetention(): String {
        return translate(5, 11, mapOf())
    }


    /** First Month */
    fun cardStatsFsrsForgettingCurveFirstMonth(): String {
        return translate(5, 12, mapOf())
    }


    /** First Week */
    fun cardStatsFsrsForgettingCurveFirstWeek(): String {
        return translate(5, 13, mapOf())
    }


    /** First Year */
    fun cardStatsFsrsForgettingCurveFirstYear(): String {
        return translate(5, 14, mapOf())
    }


    /** Probability of Recall */
    fun cardStatsFsrsForgettingCurveProbabilityOfRecalling(): String {
        return translate(5, 15, mapOf())
    }


    /** Forgetting Curve */
    fun cardStatsFsrsForgettingCurveTitle(): String {
        return translate(5, 16, mapOf())
    }


    /** Retrievability */
    fun cardStatsFsrsRetrievability(): String {
        return translate(5, 17, mapOf())
    }


    /** Stability */
    fun cardStatsFsrsStability(): String {
        return translate(5, 18, mapOf())
    }


    /** Interval */
    fun cardStatsInterval(): String {
        return translate(5, 19, mapOf())
    }


    /** Lapses */
    fun cardStatsLapseCount(): String {
        return translate(5, 20, mapOf())
    }


    /** Latest Review */
    fun cardStatsLatestReview(): String {
        return translate(5, 21, mapOf())
    }


    /** Position */
    fun cardStatsNewCardPosition(): String {
        return translate(5, 22, mapOf())
    }


    /** (No card to display.) */
    fun cardStatsNoCard(): String {
        return translate(5, 23, mapOf())
    }


    /** Note ID */
    fun cardStatsNoteId(): String {
        return translate(5, 24, mapOf())
    }


    /** Note Type */
    fun cardStatsNoteType(): String {
        return translate(5, 25, mapOf())
    }


    /** Preset */
    fun cardStatsPreset(): String {
        return translate(5, 26, mapOf())
    }


    /** Previous Card ({$context}) */
    fun cardStatsPreviousCard(`context`: String): String {
        return translate(5, 27, mapOf("context" to asTranslateArg(`context`)))
    }


    /** Reviews */
    fun cardStatsReviewCount(): String {
        return translate(5, 28, mapOf())
    }


    /** Date */
    fun cardStatsReviewLogDate(): String {
        return translate(5, 29, mapOf())
    }


    /** Elapsed Time */
    fun cardStatsReviewLogElapsedTime(): String {
        return translate(5, 30, mapOf())
    }


    /** Rating */
    fun cardStatsReviewLogRating(): String {
        return translate(5, 31, mapOf())
    }


    /** Time */
    fun cardStatsReviewLogTimeTaken(): String {
        return translate(5, 32, mapOf())
    }


    /** Type */
    fun cardStatsReviewLogType(): String {
        return translate(5, 33, mapOf())
    }


    /** Filtered */
    fun cardStatsReviewLogTypeFiltered(): String {
        return translate(5, 34, mapOf())
    }


    /** Learn */
    fun cardStatsReviewLogTypeLearn(): String {
        return translate(5, 35, mapOf())
    }


    /** Manual */
    fun cardStatsReviewLogTypeManual(): String {
        return translate(5, 36, mapOf())
    }


    /** Relearn */
    fun cardStatsReviewLogTypeRelearn(): String {
        return translate(5, 37, mapOf())
    }


    /** Rescheduled */
    fun cardStatsReviewLogTypeRescheduled(): String {
        return translate(5, 38, mapOf())
    }


    /** Review */
    fun cardStatsReviewLogTypeReview(): String {
        return translate(5, 39, mapOf())
    }


    /** Total Time */
    fun cardStatsTotalTime(): String {
        return translate(5, 40, mapOf())
    }


    /** Back template has a problem: */
    fun cardTemplateRenderingBackSideProblem(): String {
        return translate(6, 0, mapOf())
    }


    /** Browser-specific back template has a problem: */
    fun cardTemplateRenderingBrowserBackSideProblem(): String {
        return translate(6, 1, mapOf())
    }


    /** Browser-specific front template has a problem: */
    fun cardTemplateRenderingBrowserFrontSideProblem(): String {
        return translate(6, 2, mapOf())
    }


    /** Missing '{$missing}' */
    fun cardTemplateRenderingConditionalNotClosed(`missing`: String): String {
        return translate(6, 3, mapOf("missing" to asTranslateArg(`missing`)))
    }


    /** Found '{$found}', but missing '{$missing1}' or '{$missing2}' */
    fun cardTemplateRenderingConditionalNotOpen(`found`: TranslateArg, `missing1`: String, `missing2`: String): String {
        return translate(6, 4, mapOf("found" to asTranslateArg(`found`), "missing1" to asTranslateArg(`missing1`), "missing2" to asTranslateArg(`missing2`)))
    }


    /** The front of this card is blank. */
    fun cardTemplateRenderingEmptyFront(): String {
        return translate(6, 5, mapOf())
    }


    /** Front template has a problem: */
    fun cardTemplateRenderingFrontSideProblem(): String {
        return translate(6, 6, mapOf())
    }


    /** No cloze {$number} found on card.
Please either add a cloze deletion, or use the Empty Cards tool. */
    fun cardTemplateRenderingMissingCloze(`number`: TranslateArg): String {
        return translate(6, 7, mapOf("number" to asTranslateArg(`number`)))
    }


    /** More information */
    fun cardTemplateRenderingMoreInfo(): String {
        return translate(6, 8, mapOf())
    }


    /** Missing '{$missing}' in '{$tag}' */
    fun cardTemplateRenderingNoClosingBrackets(`missing`: String, `tag`: String): String {
        return translate(6, 9, mapOf("missing" to asTranslateArg(`missing`), "tag" to asTranslateArg(`tag`)))
    }


    /** Found '{$found}', but there is no field called '{$field}' */
    fun cardTemplateRenderingNoSuchField(`found`: TranslateArg, `field`: String): String {
        return translate(6, 10, mapOf("found" to asTranslateArg(`found`), "field" to asTranslateArg(`field`)))
    }


    /** Found '{$found}', but expected '{$expected}' */
    fun cardTemplateRenderingWrongConditionalClosed(`found`: TranslateArg, `expected`: TranslateArg): String {
        return translate(6, 11, mapOf("found" to asTranslateArg(`found`), "expected" to asTranslateArg(`expected`)))
    }


    /** Add Card Type... */
    fun cardTemplatesAddCardType(): String {
        return translate(7, 0, mapOf())
    }


    /** Add Mobile Class */
    fun cardTemplatesAddMobileClass(): String {
        return translate(7, 1, mapOf())
    }


    /** Anki couldn't find the line between the question and answer. Please adjust the template manually to switch the question and answer. */
    fun cardTemplatesAnkiCouldntFindTheLineBetween(): String {
        return translate(7, 2, mapOf())
    }


    /** At least one card type is required. */
    fun cardTemplatesAtLeastOneCardTypeIs(): String {
        return translate(7, 3, mapOf())
    }


    /** Back Preview */
    fun cardTemplatesBackPreview(): String {
        return translate(7, 4, mapOf())
    }


    /** Back Template */
    fun cardTemplatesBackTemplate(): String {
        return translate(7, 5, mapOf())
    }


    /** blank */
    fun cardTemplatesBlank(): String {
        return translate(7, 6, mapOf())
    }


    /** Browser Appearance... */
    fun cardTemplatesBrowserAppearance(): String {
        return translate(7, 7, mapOf())
    }


    /** Card {$val} */
    fun cardTemplatesCard(`val`: TranslateArg): String {
        return translate(7, 8, mapOf("val" to asTranslateArg(`val`)))
    }


    /** {$count} cards */
    fun cardTemplatesCardCount(`count`: Int): String {
        return translate(7, 9, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Card Type: */
    fun cardTemplatesCardType(): String {
        return translate(7, 10, mapOf())
    }


    /** Card Types for {$val} */
    fun cardTemplatesCardTypesFor(`val`: TranslateArg): String {
        return translate(7, 11, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Changes saved. */
    fun cardTemplatesChangesSaved(): String {
        return translate(7, 12, mapOf())
    }


    /** Changes below will affect the {$count} notes that use this card type. */
    fun cardTemplatesChangesWillAffectNotes(`count`: Int): String {
        return translate(7, 13, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Cloze {$val} */
    fun cardTemplatesCloze(`val`: TranslateArg): String {
        return translate(7, 14, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Copy Info to Clipboard */
    fun cardTemplatesCopyInfo(): String {
        return translate(7, 15, mapOf())
    }


    /** Deck Override... */
    fun cardTemplatesDeckOverride(): String {
        return translate(7, 16, mapOf())
    }


    /** Delete the '{$template}' card type, and its {$cards}? */
    fun cardTemplatesDeleteTheAsCardTypeAnd(`template`: String, `cards`: Int): String {
        return translate(7, 17, mapOf("template" to asTranslateArg(`template`), "cards" to asTranslateArg(`cards`)))
    }


    /** Discard changes? */
    fun cardTemplatesDiscardChanges(): String {
        return translate(7, 18, mapOf())
    }


    /** Enter deck to place new {$val} cards in, or leave blank: */
    fun cardTemplatesEnterDeckToPlaceNew(`val`: TranslateArg): String {
        return translate(7, 19, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Enter new card position (1...{$val}): */
    fun cardTemplatesEnterNewCardPosition1(`val`: TranslateArg): String {
        return translate(7, 20, mapOf("val" to asTranslateArg(`val`)))
    }


    /** 'cloze:' can only be used on cloze note types. */
    fun cardTemplatesExtraneousCloze(): String {
        return translate(7, 21, mapOf())
    }


    /** Field '{$field}' not found. */
    fun cardTemplatesFieldNotFound(`field`: String): String {
        return translate(7, 22, mapOf("field" to asTranslateArg(`field`)))
    }


    /** Fill Empty Fields */
    fun cardTemplatesFillEmpty(): String {
        return translate(7, 23, mapOf())
    }


    /** Flip */
    fun cardTemplatesFlip(): String {
        return translate(7, 24, mapOf())
    }


    /** Form */
    fun cardTemplatesForm(): String {
        return translate(7, 25, mapOf())
    }


    /** Front Preview */
    fun cardTemplatesFrontPreview(): String {
        return translate(7, 26, mapOf())
    }


    /** Front Template */
    fun cardTemplatesFrontTemplate(): String {
        return translate(7, 27, mapOf())
    }


    /** The front side is identical to card template {$number}. */
    fun cardTemplatesIdenticalFront(`number`: TranslateArg): String {
        return translate(7, 28, mapOf("number" to asTranslateArg(`number`)))
    }


    /** Card template {$number} in note type '{$notetype}' has a problem. */
    fun cardTemplatesInvalidTemplateNumber(`number`: TranslateArg, `notetype`: String): String {
        return translate(7, 29, mapOf("number" to asTranslateArg(`number`), "notetype" to asTranslateArg(`notetype`)))
    }


    /** Expected to find 'cloze:Text' or similar on the front and back of the card template. */
    fun cardTemplatesMissingCloze(): String {
        return translate(7, 30, mapOf())
    }


    /** Night Mode */
    fun cardTemplatesNightMode(): String {
        return translate(7, 31, mapOf())
    }


    /** Expected to find a field replacement on the front of the card template. */
    fun cardTemplatesNoFrontField(): String {
        return translate(7, 32, mapOf())
    }


    /** (off) */
    fun cardTemplatesOff(): String {
        return translate(7, 33, mapOf())
    }


    /** (on) */
    fun cardTemplatesOn(): String {
        return translate(7, 34, mapOf())
    }


    /** Preview */
    fun cardTemplatesPreviewBox(): String {
        return translate(7, 35, mapOf())
    }


    /** Options */
    fun cardTemplatesPreviewSettings(): String {
        return translate(7, 36, mapOf())
    }


    /** Remove Card Type... */
    fun cardTemplatesRemoveCardType(): String {
        return translate(7, 37, mapOf())
    }


    /** Rename Card Type... */
    fun cardTemplatesRenameCardType(): String {
        return translate(7, 38, mapOf())
    }


    /** Reposition Card Type... */
    fun cardTemplatesRepositionCardType(): String {
        return translate(7, 39, mapOf())
    }


    /** Restore to Default */
    fun cardTemplatesRestoreToDefault(): String {
        return translate(7, 40, mapOf())
    }


    /** This will reset all fields and templates in this note type to their default values, removing any extra fields/templates and their content, and any custom styling. Do you wish to proceed? */
    fun cardTemplatesRestoreToDefaultConfirmation(): String {
        return translate(7, 41, mapOf())
    }


    /** Note type has been restored to its original state. */
    fun cardTemplatesRestoredToDefault(): String {
        return translate(7, 42, mapOf())
    }


    /** This is a sample cloze deletion. */
    fun cardTemplatesSampleCloze(): String {
        return translate(7, 43, mapOf())
    }


    /** See the preview for more information. */
    fun cardTemplatesSeePreview(): String {
        return translate(7, 44, mapOf())
    }


    /** Template */
    fun cardTemplatesTemplateBox(): String {
        return translate(7, 45, mapOf())
    }


    /** Styling */
    fun cardTemplatesTemplateStyling(): String {
        return translate(7, 46, mapOf())
    }


    /** This will create {$count} cards. Proceed? */
    fun cardTemplatesThisWillCreateCardProceed(`count`: Int): String {
        return translate(7, 47, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Only one typing box per card template is supported. */
    fun cardTemplatesTypeBoxesWarning(): String {
        return translate(7, 48, mapOf())
    }


    /** Collapse */
    fun changeNotetypeCollapse(): String {
        return translate(8, 0, mapOf())
    }


    /** Current */
    fun changeNotetypeCurrent(): String {
        return translate(8, 1, mapOf())
    }


    /** Expand */
    fun changeNotetypeExpand(): String {
        return translate(8, 2, mapOf())
    }


    /** Fields */
    fun changeNotetypeFields(): String {
        return translate(8, 3, mapOf())
    }


    /** New */
    fun changeNotetypeNew(): String {
        return translate(8, 4, mapOf())
    }


    /** (Nothing) */
    fun changeNotetypeNothing(): String {
        return translate(8, 5, mapOf())
    }


    /** Templates */
    fun changeNotetypeTemplates(): String {
        return translate(8, 6, mapOf())
    }


    /** When changing to or from a Cloze note type, card numbers remain unchanged.

If changing to a regular note type, and there are more cloze deletions
than available card templates, any extra cards will be removed. */
    fun changeNotetypeToFromCloze(): String {
        return translate(8, 7, mapOf())
    }


    /** Will remove the following cards: */
    fun changeNotetypeWillDiscardCards(): String {
        return translate(8, 8, mapOf())
    }


    /** Will discard content on the following fields: */
    fun changeNotetypeWillDiscardContent(): String {
        return translate(8, 9, mapOf())
    }


    /** All cards in random order (don't reschedule) */
    fun customStudyAllCardsInRandomOrderDont(): String {
        return translate(9, 0, mapOf())
    }


    /** All review cards in random order */
    fun customStudyAllReviewCardsInRandomOrder(): String {
        return translate(9, 1, mapOf())
    }


    /** ({$count} in subdecks) */
    fun customStudyAvailableChildCount(`count`: Int): String {
        return translate(9, 2, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Available new cards: {$count} */
    fun customStudyAvailableNewCards(`count`: Int): String {
        return translate(9, 3, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Available new cards: {$countString} */
    fun customStudyAvailableNewCards2(`countString`: String): String {
        return translate(9, 4, mapOf("countString" to asTranslateArg(`countString`)))
    }


    /** Available review cards: {$count} */
    fun customStudyAvailableReviewCards(`count`: Int): String {
        return translate(9, 5, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Available review cards: {$countString} */
    fun customStudyAvailableReviewCards2(`countString`: String): String {
        return translate(9, 6, mapOf("countString" to asTranslateArg(`countString`)))
    }


    /** cards */
    fun customStudyCards(`count`: Int): String {
        return translate(9, 7, mapOf("count" to asTranslateArg(`count`)))
    }


    /** cards from the deck */
    fun customStudyCardsFromTheDeck(`count`: Int): String {
        return translate(9, 8, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Choose Tags */
    fun customStudyChooseTags(): String {
        return translate(9, 9, mapOf())
    }


    /** Custom Study Session */
    fun customStudyCustomStudySession(): String {
        return translate(9, 10, mapOf())
    }


    /** days */
    fun customStudyDays(`count`: Int): String {
        return translate(9, 11, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Due cards only */
    fun customStudyDueCardsOnly(): String {
        return translate(9, 12, mapOf())
    }


    /** Increase today's new card limit */
    fun customStudyIncreaseTodaysNewCardLimit(): String {
        return translate(9, 13, mapOf())
    }


    /** Increase today's new card limit by */
    fun customStudyIncreaseTodaysNewCardLimitBy(): String {
        return translate(9, 14, mapOf())
    }


    /** Increase today's review card limit */
    fun customStudyIncreaseTodaysReviewCardLimit(): String {
        return translate(9, 15, mapOf())
    }


    /** Increase today's review limit by */
    fun customStudyIncreaseTodaysReviewLimitBy(): String {
        return translate(9, 16, mapOf())
    }


    /** Please rename the existing Custom Study deck first. */
    fun customStudyMustRenameDeck(): String {
        return translate(9, 17, mapOf())
    }


    /** New cards only */
    fun customStudyNewCardsOnly(): String {
        return translate(9, 18, mapOf())
    }


    /** No cards matched the criteria you provided. */
    fun customStudyNoCardsMatchedTheCriteriaYou(): String {
        return translate(9, 19, mapOf())
    }


    /** OK */
    fun customStudyOk(): String {
        return translate(9, 20, mapOf())
    }


    /** Preview new cards */
    fun customStudyPreviewNewCards(): String {
        return translate(9, 21, mapOf())
    }


    /** Preview new cards added in the last */
    fun customStudyPreviewNewCardsAddedInThe(): String {
        return translate(9, 22, mapOf())
    }


    /** Require one or more of these tags: */
    fun customStudyRequireOneOrMoreOfThese(): String {
        return translate(9, 23, mapOf())
    }


    /** Review ahead */
    fun customStudyReviewAhead(): String {
        return translate(9, 24, mapOf())
    }


    /** Review ahead by */
    fun customStudyReviewAheadBy(): String {
        return translate(9, 25, mapOf())
    }


    /** Review cards forgotten in the last */
    fun customStudyReviewCardsForgottenInLast(): String {
        return translate(9, 26, mapOf())
    }


    /** Review forgotten cards */
    fun customStudyReviewForgottenCards(): String {
        return translate(9, 27, mapOf())
    }


    /** Select */
    fun customStudySelect(): String {
        return translate(9, 28, mapOf())
    }


    /** Select tags to exclude: */
    fun customStudySelectTagsToExclude(): String {
        return translate(9, 29, mapOf())
    }


    /** Selective Study */
    fun customStudySelectiveStudy(): String {
        return translate(9, 30, mapOf())
    }


    /** Study by card state or tag */
    fun customStudyStudyByCardStateOrTag(): String {
        return translate(9, 31, mapOf())
    }


    /** Added last review time to {$count} cards. */
    fun databaseCheckCardLastReviewTimeEmpty(`count`: Int): String {
        return translate(10, 0, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Deleted {$count} cards with missing note. */
    fun databaseCheckCardMissingNote(`count`: Int): String {
        return translate(10, 1, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Fixed {$count} invalid card properties. */
    fun databaseCheckCardProperties(`count`: Int): String {
        return translate(10, 2, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Checking cards... */
    fun databaseCheckCheckingCards(): String {
        return translate(10, 3, mapOf())
    }


    /** Checking history... */
    fun databaseCheckCheckingHistory(): String {
        return translate(10, 4, mapOf())
    }


    /** Checking collection... */
    fun databaseCheckCheckingIntegrity(): String {
        return translate(10, 5, mapOf())
    }


    /** Checking notes... */
    fun databaseCheckCheckingNotes(): String {
        return translate(10, 6, mapOf())
    }


    /** Collection file is corrupt. Please restore from an automatic backup. */
    fun databaseCheckCorrupt(): String {
        return translate(10, 7, mapOf())
    }


    /** Deleted {$count} cards with duplicate template. */
    fun databaseCheckDuplicateCardOrds(`count`: Int): String {
        return translate(10, 8, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Fixed {$count} notes with wrong field count. */
    fun databaseCheckFieldCount(`count`: Int): String {
        return translate(10, 9, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Fixed {$count} objects with timestamps in the future. */
    fun databaseCheckFixedInvalidIds(`count`: Int): String {
        return translate(10, 10, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Fixed {$count} missing decks. */
    fun databaseCheckMissingDecks(`count`: Int): String {
        return translate(10, 11, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Deleted {$count} cards with missing template. */
    fun databaseCheckMissingTemplates(`count`: Int): String {
        return translate(10, 12, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Found {$count} new cards with a due number >= 1,000,000 - consider repositioning them in the Browse screen. */
    fun databaseCheckNewCardHighDue(`count`: Int): String {
        return translate(10, 13, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Fixed {$count} notes with invalid utf8 characters. */
    fun databaseCheckNotesWithInvalidUtf8(`count`: Int): String {
        return translate(10, 14, mapOf("count" to asTranslateArg(`count`)))
    }


    /** One or more note types were missing. The notes that used them have been given new note types starting with "db-check", but field names and card design have been lost, so you may be better off restoring from an automatic backup. */
    fun databaseCheckNotetypesRecovered(): String {
        return translate(10, 15, mapOf())
    }


    /** Rebuilding... */
    fun databaseCheckRebuilding(): String {
        return translate(10, 16, mapOf())
    }


    /** Database rebuilt and optimized. */
    fun databaseCheckRebuilt(): String {
        return translate(10, 17, mapOf())
    }


    /** Fixed {$count} review entries with invalid properties. */
    fun databaseCheckRevlogProperties(`count`: Int): String {
        return translate(10, 18, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Check Database */
    fun databaseCheckTitle(): String {
        return translate(10, 19, mapOf())
    }


    /** A 100 day interval will become {$days} days. */
    fun deckConfigA100DayInterval(`days`: Int): String {
        return translate(11, 0, mapOf("days" to asTranslateArg(`days`)))
    }


    /** Add Preset */
    fun deckConfigAddGroup(): String {
        return translate(11, 1, mapOf())
    }


    /** Additional new cards to simulate */
    fun deckConfigAdditionalNewCardsToSimulate(): String {
        return translate(11, 2, mapOf())
    }


    /** Advanced Settings */
    fun deckConfigAdvancedSettings(): String {
        return translate(11, 3, mapOf())
    }


    /** Advanced */
    fun deckConfigAdvancedTitle(): String {
        return translate(11, 4, mapOf())
    }


    /** Affects the entire collection. */
    fun deckConfigAffectsEntireCollection(): String {
        return translate(11, 5, mapOf())
    }


    /** Whether the question audio should be included when the Replay action is
used while looking at the answer side of a card. */
    fun deckConfigAlwaysIncludeQuestionAudioTooltip(): String {
        return translate(11, 6, mapOf())
    }


    /** Answer action */
    fun deckConfigAnswerAction(): String {
        return translate(11, 7, mapOf())
    }


    /** The action to perform on the current card before automatically advancing to the next one. */
    fun deckConfigAnswerActionTooltip(): String {
        return translate(11, 8, mapOf())
    }


    /** The action to perform after the answer is shown, and time has elapsed. */
    fun deckConfigAnswerActionTooltip2(): String {
        return translate(11, 9, mapOf())
    }


    /** Answer Again */
    fun deckConfigAnswerAgain(): String {
        return translate(11, 10, mapOf())
    }


    /** Answer Good */
    fun deckConfigAnswerGood(): String {
        return translate(11, 11, mapOf())
    }


    /** Answer Hard */
    fun deckConfigAnswerHard(): String {
        return translate(11, 12, mapOf())
    }


    /** Limits start from top */
    fun deckConfigApplyAllParentLimits(): String {
        return translate(11, 13, mapOf())
    }


    /** By default, the daily limits of a higher-level deck do not apply if you're studying from its subdeck.
If this option is enabled, the limits will
start from the top-level deck instead, which can be useful if you wish to study individual
subdecks, while enforcing a total limit on cards for the deck tree. */
    fun deckConfigApplyAllParentLimitsTooltip(): String {
        return translate(11, 14, mapOf())
    }


    /** Audio */
    fun deckConfigAudioTitle(): String {
        return translate(11, 15, mapOf())
    }


    /** Bury if new */
    fun deckConfigBuryIfNew(): String {
        return translate(11, 16, mapOf())
    }


    /** Bury if new or review */
    fun deckConfigBuryIfNewOrReview(): String {
        return translate(11, 17, mapOf())
    }


    /** Bury if new, review, or interday learning */
    fun deckConfigBuryIfNewReviewOrInterday(): String {
        return translate(11, 18, mapOf())
    }


    /** Bury interday learning siblings */
    fun deckConfigBuryInterdayLearningSiblings(): String {
        return translate(11, 19, mapOf())
    }


    /** Whether other `learning` cards of the same note with intervals > 1 day
will be delayed until the next day. */
    fun deckConfigBuryInterdayLearningTooltip(): String {
        return translate(11, 20, mapOf())
    }


    /** Bury new siblings */
    fun deckConfigBuryNewSiblings(): String {
        return translate(11, 21, mapOf())
    }


    /** Whether other `new` cards of the same note (e.g. reverse cards, adjacent cloze deletions)
will be delayed until the next day. */
    fun deckConfigBuryNewTooltip(): String {
        return translate(11, 22, mapOf())
    }


    /** When Anki gathers cards, it first gathers intraday learning cards, then
interday learning cards, then review cards, and finally new cards. This affects
how burying works:

- If you have all burying options enabled, the sibling that comes earliest in
that list will be shown. For example, a review card will be shown in preference
to a new card.
- Siblings later in the list can not bury earlier card types. For example, if you
disable burying of new cards, and study a new card, it will not bury any interday
learning or review cards, and you may see both a review sibling and new sibling in the
same session. */
    fun deckConfigBuryPriorityTooltip(): String {
        return translate(11, 23, mapOf())
    }


    /** Bury review siblings */
    fun deckConfigBuryReviewSiblings(): String {
        return translate(11, 24, mapOf())
    }


    /** Whether other `review` cards of the same note will be delayed until the next day. */
    fun deckConfigBuryReviewTooltip(): String {
        return translate(11, 25, mapOf())
    }


    /** Bury siblings */
    fun deckConfigBurySiblings(): String {
        return translate(11, 26, mapOf())
    }


    /** Burying */
    fun deckConfigBuryTitle(): String {
        return translate(11, 27, mapOf())
    }


    /** Siblings are other cards from the same note (eg forward/reverse cards, or
other cloze deletions from the same text).

When this option is off, multiple cards from the same note may be seen on the same
day. When enabled, Anki will automatically *bury* siblings, hiding them until the next
day. This option allows you to choose which kinds of cards may be buried when you answer
one of their siblings.

When using the V3 scheduler, interday learning cards can also be buried. Interday
learning cards are cards with a current learning step of one or more days. */
    fun deckConfigBuryTooltip(): String {
        return translate(11, 28, mapOf())
    }


    /** Checking for improvement... */
    fun deckConfigCheckingForImprovement(): String {
        return translate(11, 29, mapOf())
    }


    /** Clear Last Simulation */
    fun deckConfigClearLastSimulate(): String {
        return translate(11, 30, mapOf())
    }


    /** Clone Preset */
    fun deckConfigCloneGroup(): String {
        return translate(11, 31, mapOf())
    }


    /** {$num}% complete. */
    fun deckConfigComplete(`num`: TranslateArg): String {
        return translate(11, 32, mapOf("num" to asTranslateArg(`num`)))
    }


    /** Compute */
    fun deckConfigComputeButton(): String {
        return translate(11, 33, mapOf())
    }


    /** Minimum recommended retention */
    fun deckConfigComputeMinimumRecommendedRetention(): String {
        return translate(11, 34, mapOf())
    }


    /** Compute minimum recommended retention */
    fun deckConfigComputeOptimalRetention(): String {
        return translate(11, 35, mapOf())
    }


    /** This tool assumes you're starting with 0 cards, and will attempt to calculate the amount of material you'll
be able to retain in the given time frame. The estimated retention will greatly depend on your inputs, and
if it significantly differs from 0.9, it's a sign that the time you've allocated each day is either too low
or too high for the amount of cards you're trying to learn. This number can be useful as a reference, but it
is not recommended to copy it into the desired retention field. */
    fun deckConfigComputeOptimalRetentionTooltip(): String {
        return translate(11, 36, mapOf())
    }


    /** This tool assumes that you’re starting with 0 learned cards, and will attempt to find the desired retention
value that will lead to the most material learnt, in the least amount of time. This number can be used as a
reference when deciding what to set your desired retention to. You may wish to choose a higher desired retention,
if you’re willing to trade more study time for a greater recall rate. Setting your desired retention lower than
the minimum is not recommended, as it will lead to more work without benefit. */
    fun deckConfigComputeOptimalRetentionTooltip2(): String {
        return translate(11, 37, mapOf())
    }


    /** This tool assumes that you’re starting with 0 learned cards, and will attempt to find the desired retention value 
that will lead to the most material learnt, in the least amount of time. To accurately simulate your learning process, 
this feature requires a minimum of 400+ reviews. The calculated number can serve as a reference when deciding what to 
set your desired retention to. You may wish to choose a higher desired retention, if you’re willing to trade more study 
time for a greater recall rate. Setting your desired retention lower than the minimum is not recommended, as it will 
lead to a higher workload, because of the high forgetting rate. */
    fun deckConfigComputeOptimalRetentionTooltip3(): String {
        return translate(11, 38, mapOf())
    }


    /** This tool will attempt to find the desired retention value 
that will lead to the most material learnt, in the least amount of time. The calculated number can serve as a reference
when deciding what to set your desired retention to. You may wish to choose a higher desired retention if you’re 
willing to invest more study time to achieve it. Setting your desired retention lower than the minimum
is not recommended, as it will lead to a higher workload, because of the high forgetting rate. */
    fun deckConfigComputeOptimalRetentionTooltip4(): String {
        return translate(11, 39, mapOf())
    }


    /** Optimize FSRS parameters */
    fun deckConfigComputeOptimalWeights(): String {
        return translate(11, 40, mapOf())
    }


    /** Once you've done 1000+ reviews in Anki, you can use the Optimize button to analyze your review history,
and automatically generate parameters that are optimal for your memory and the content you're studying.
If you have decks that vary wildly in difficulty, it is recommended to assign them separate presets, as
the parameters for easy decks and hard decks will be different. There is no need to optimize your parameters
frequently - once every few months is sufficient.

By default, parameters will be calculated from the review history of all decks using the current preset. You can
optionally adjust the search before calculating the parameters, if you'd like to alter which cards are used for
optimizing the parameters. */
    fun deckConfigComputeOptimalWeightsTooltip(): String {
        return translate(11, 41, mapOf())
    }


    /** When you click the Optimize button, FSRS will analyze your review history, and generate parameters that are 
optimal for your memory and the content you're studying. If your decks vary wildly in subjective difficulty, it 
is recommended to assign them separate presets, as the parameters for easy decks and hard decks will be different. 
You don't need to optimize your parameters frequently - once every few months is sufficient.

By default, parameters will be calculated from the review history of all decks using the current preset. You can
optionally adjust the search before calculating the parameters, if you'd like to alter which cards are used for
optimizing the parameters. */
    fun deckConfigComputeOptimalWeightsTooltip2(): String {
        return translate(11, 42, mapOf())
    }


    /** Remove {$name}? */
    fun deckConfigConfirmRemoveName(`name`: String): String {
        return translate(11, 43, mapOf("name" to asTranslateArg(`name`)))
    }


    /** Custom scheduling */
    fun deckConfigCustomScheduling(): String {
        return translate(11, 44, mapOf())
    }


    /** Affects the entire collection. Use at your own risk! */
    fun deckConfigCustomSchedulingTooltip(): String {
        return translate(11, 45, mapOf())
    }


    /** A parent deck has a limit of {$cards} cards, which will override this limit. */
    fun deckConfigDailyLimitWillBeCapped(`cards`: Int): String {
        return translate(11, 46, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** Daily Limits */
    fun deckConfigDailyLimits(): String {
        return translate(11, 47, mapOf())
    }


    /** Days to simulate */
    fun deckConfigDaysToSimulate(): String {
        return translate(11, 48, mapOf())
    }


    /** This deck */
    fun deckConfigDeckOnly(): String {
        return translate(11, 49, mapOf())
    }


    /** Default */
    fun deckConfigDefaultName(): String {
        return translate(11, 50, mapOf())
    }


    /** Anki 2.1.41+ handling */
    fun deckConfigDescriptionNewHandling(): String {
        return translate(11, 51, mapOf())
    }


    /** Treats input as markdown, and cleans HTML input. When enabled, the
description will also be shown on the congratulations screen.
Markdown will appear as text on Anki 2.1.40 and below. */
    fun deckConfigDescriptionNewHandlingHint(): String {
        return translate(11, 52, mapOf())
    }


    /** Interpret as Markdown */
    fun deckConfigDescriptionNewHandling2(): String {
        return translate(11, 53, mapOf())
    }


    /** Desired retention */
    fun deckConfigDesiredRetention(): String {
        return translate(11, 54, mapOf())
    }


    /** Your desired retention is below optimal. Increasing it is recommended. */
    fun deckConfigDesiredRetentionBelowOptimal(): String {
        return translate(11, 55, mapOf())
    }


    /** Your desired retention is very high, which can lead to very short intervals. */
    fun deckConfigDesiredRetentionTooHigh(): String {
        return translate(11, 56, mapOf())
    }


    /** Your desired retention is very low, which can lead to very long intervals. */
    fun deckConfigDesiredRetentionTooLow(): String {
        return translate(11, 57, mapOf())
    }


    /** By default, Anki schedules cards so that you have a 90% chance of remembering them when
they come up for review again. If you increase this value, Anki will show cards more frequently
to increase the chances of you remembering them. If you decrease the value, Anki will show cards
less frequently, and you will forget more of them. Be conservative when adjusting this - higher
values will greatly increase your workload, and lower values can be demoralizing when you forget
a lot of material. */
    fun deckConfigDesiredRetentionTooltip(): String {
        return translate(11, 58, mapOf())
    }


    /** The workload values provided by the info box are a rough approximation. For a greater level of accuracy, use the simulator. */
    fun deckConfigDesiredRetentionTooltip2(): String {
        return translate(11, 59, mapOf())
    }


    /** Don't play audio automatically */
    fun deckConfigDisableAutoplay(): String {
        return translate(11, 60, mapOf())
    }


    /** When enabled, Anki will not play audio automatically.
It can be played manually by clicking/tapping on an audio icon, or by using the Replay action. */
    fun deckConfigDisableAutoplayTooltip(): String {
        return translate(11, 61, mapOf())
    }


    /** Anki will use the display order from the deck you 
select to study, and not any subdecks it may have. */
    fun deckConfigDisplayOrderWillUseCurrentDeck(): String {
        return translate(11, 62, mapOf())
    }


    /** Do not bury siblings */
    fun deckConfigDoNotBury(): String {
        return translate(11, 63, mapOf())
    }


    /** An extra multiplier that is applied to a review card's interval when you rate
it `Easy`. */
    fun deckConfigEasyBonusTooltip(): String {
        return translate(11, 64, mapOf())
    }


    /** Existing reviews will not be rescheduled unless '' is enabled in the FSRS options. */
    fun deckConfigEasyDaysChange(): String {
        return translate(11, 65, mapOf())
    }


    /** Fri */
    fun deckConfigEasyDaysFriday(): String {
        return translate(11, 66, mapOf())
    }


    /** Minimum */
    fun deckConfigEasyDaysMinimum(): String {
        return translate(11, 67, mapOf())
    }


    /** Mon */
    fun deckConfigEasyDaysMonday(): String {
        return translate(11, 68, mapOf())
    }


    /** At least one day should be set to ''. */
    fun deckConfigEasyDaysNoNormalDays(): String {
        return translate(11, 69, mapOf())
    }


    /** Normal */
    fun deckConfigEasyDaysNormal(): String {
        return translate(11, 70, mapOf())
    }


    /** Reduced */
    fun deckConfigEasyDaysReduced(): String {
        return translate(11, 71, mapOf())
    }


    /** Sat */
    fun deckConfigEasyDaysSaturday(): String {
        return translate(11, 72, mapOf())
    }


    /** Sun */
    fun deckConfigEasyDaysSunday(): String {
        return translate(11, 73, mapOf())
    }


    /** Thu */
    fun deckConfigEasyDaysThursday(): String {
        return translate(11, 74, mapOf())
    }


    /** Easy Days */
    fun deckConfigEasyDaysTitle(): String {
        return translate(11, 75, mapOf())
    }


    /** Tue */
    fun deckConfigEasyDaysTuesday(): String {
        return translate(11, 76, mapOf())
    }


    /** Wed */
    fun deckConfigEasyDaysWednesday(): String {
        return translate(11, 77, mapOf())
    }


    /** The number of days to wait before showing a card again, after the `Easy` button
is used to immediately remove a card from learning. */
    fun deckConfigEasyIntervalTooltip(): String {
        return translate(11, 78, mapOf())
    }


    /** Evaluate */
    fun deckConfigEvaluateButton(): String {
        return translate(11, 79, mapOf())
    }


    /** Health Check:
Your memory is difficult for FSRS to predict. Recommendations:

- Suspend or reformulate any cards you constantly forget.
- Use the answer buttons consistently. Keep in mind that "Hard" is a passing grade, not a failing grade.
- Understand before you memorize.

If you follow these suggestions, performance will usually improve over the next few months. */
    fun deckConfigFsrsBadFitWarning(): String {
        return translate(11, 80, mapOf())
    }


    /** This will save any other changes you have made. Are you sure? */
    fun deckConfigFsrsConfirmSaveAndOptimize(): String {
        return translate(11, 81, mapOf())
    }


    /** Help Me Decide (Experimental) */
    fun deckConfigFsrsDesiredRetentionHelpMeDecideExperimental(): String {
        return translate(11, 82, mapOf())
    }


    /** Health Check:
FSRS can adapt to your memory well. */
    fun deckConfigFsrsGoodFit(): String {
        return translate(11, 83, mapOf())
    }


    /** FSRS must be enabled first. */
    fun deckConfigFsrsMustBeEnabled(): String {
        return translate(11, 84, mapOf())
    }


    /** Please ensure all of your Anki clients are Anki(Mobile) 23.10+ or AnkiDroid 2.17+. FSRS will
not work correctly if one of your clients is older. */
    fun deckConfigFsrsOnAllClients(): String {
        return translate(11, 85, mapOf())
    }


    /** No reviews found. Make sure this preset is assigned to all decks (including subdecks) that you want to optimize, and try again. */
    fun deckConfigFsrsParamsNoReviews(): String {
        return translate(11, 86, mapOf())
    }


    /** The FSRS parameters are currently optimal. This is expected once parameters are well-fitted to your review history. You can try optimizing again after doing more reviews. */
    fun deckConfigFsrsParamsOptimal(): String {
        return translate(11, 87, mapOf())
    }


    /** FSRS Desired Retention Simulator (Experimental) */
    fun deckConfigFsrsSimulateDesiredRetentionExperimental(): String {
        return translate(11, 88, mapOf())
    }


    /** After optimizing, please save your deck preset before running the simulator. */
    fun deckConfigFsrsSimulateSavePreset(): String {
        return translate(11, 89, mapOf())
    }


    /** FSRS Simulator (Experimental) */
    fun deckConfigFsrsSimulatorExperimental(): String {
        return translate(11, 90, mapOf())
    }


    /** Reviews */
    fun deckConfigFsrsSimulatorRadioCount(): String {
        return translate(11, 91, mapOf())
    }


    /** Efficiency */
    fun deckConfigFsrsSimulatorRadioEfficiency(): String {
        return translate(11, 92, mapOf())
    }


    /** Memorized */
    fun deckConfigFsrsSimulatorRadioMemorized(): String {
        return translate(11, 93, mapOf())
    }


    /** Time / Memorized Ratio */
    fun deckConfigFsrsSimulatorRadioRatio(): String {
        return translate(11, 94, mapOf())
    }


    /** {$time} per memorized card */
    fun deckConfigFsrsSimulatorRatioTooltip(`time`: String): String {
        return translate(11, 95, mapOf("time" to asTranslateArg(`time`)))
    }


    /** {$time} memorized cards per hour */
    fun deckConfigFsrsSimulatorRatioTooltip2(`time`: String): String {
        return translate(11, 96, mapOf("time" to asTranslateArg(`time`)))
    }


    /** Review Count/Day */
    fun deckConfigFsrsSimulatorYAxisTitleCount(): String {
        return translate(11, 97, mapOf())
    }


    /** Memorized Total */
    fun deckConfigFsrsSimulatorYAxisTitleMemorized(): String {
        return translate(11, 98, mapOf())
    }


    /** Review Time/Day */
    fun deckConfigFsrsSimulatorYAxisTitleTime(): String {
        return translate(11, 99, mapOf())
    }


    /** Affects the entire collection.

The Free Spaced Repetition Scheduler (FSRS) is an alternative to Anki's legacy SuperMemo 2 (SM-2) algorithm.
By more accurately determining how likely you are to forget a card, it can help you remember
more material in the same amount of time. This setting is shared by all presets. */
    fun deckConfigFsrsTooltip(): String {
        return translate(11, 100, mapOf())
    }


    /** Get Params */
    fun deckConfigGetParams(): String {
        return translate(11, 101, mapOf())
    }


    /** The easy interval should be at least as long as the graduating interval. */
    fun deckConfigGoodAboveEasy(): String {
        return translate(11, 102, mapOf())
    }


    /** The number of days to wait before showing a card again, after the `Good` button
is pressed on the final learning step. */
    fun deckConfigGraduatingIntervalTooltip(): String {
        return translate(11, 103, mapOf())
    }


    /** The multiplier applied to a review interval when answering `Hard`. */
    fun deckConfigHardIntervalTooltip(): String {
        return translate(11, 104, mapOf())
    }


    /** Check health when optimizing */
    fun deckConfigHealthCheck(): String {
        return translate(11, 105, mapOf())
    }


    /** This will show a warning if FSRS struggles to adapt to your memory. */
    fun deckConfigHealthCheckTooltip1(): String {
        return translate(11, 106, mapOf())
    }


    /** Health check is performed only when using Optimize Current Preset. */
    fun deckConfigHealthCheckTooltip2(): String {
        return translate(11, 107, mapOf())
    }


    /** Historical retention */
    fun deckConfigHistoricalRetention(): String {
        return translate(11, 108, mapOf())
    }


    /** When some of your review history is missing, FSRS needs to fill in the gaps. By default, it will
assume that when you did those old reviews, you remembered 90% of the material. If your old retention
was appreciably higher or lower than 90%, adjusting this option will allow FSRS to better approximate
the missing reviews.

Your review history may be incomplete for two reasons:
1. Because you're using the 'ignore cards reviewed before' option.
2. Because you previously deleted review logs to free up space, or imported material from a different
SRS program.

The latter is quite rare, so unless you're using the former option, you probably don't need to adjust
this option. */
    fun deckConfigHistoricalRetentionTooltip(): String {
        return translate(11, 109, mapOf())
    }


    /** Ignore cards reviewed before */
    fun deckConfigIgnoreBefore(): String {
        return translate(11, 110, mapOf())
    }


    /** (Approximately) {$included}/{$totalCards} cards will be used to optimize the FSRS parameters. */
    fun deckConfigIgnoreBeforeInfo(`included`: String, `totalCards`: String): String {
        return translate(11, 111, mapOf("included" to asTranslateArg(`included`), "totalCards" to asTranslateArg(`totalCards`)))
    }


    /** If set, reviews before the provided date will be ignored when optimizing & evaluating FSRS parameters.
This can be useful if you imported someone else's scheduling data, or have changed the way you use the answer buttons. */
    fun deckConfigIgnoreBeforeTooltip(): String {
        return translate(11, 112, mapOf())
    }


    /** If set, cards reviewed before the provided date will be ignored when optimizing FSRS parameters.
This can be useful if you imported someone else's scheduling data, or have changed the way you use the answer buttons. */
    fun deckConfigIgnoreBeforeTooltip2(): String {
        return translate(11, 113, mapOf())
    }


    /** Interday learning/review order */
    fun deckConfigInterdayStepPriority(): String {
        return translate(11, 114, mapOf())
    }


    /** When to show (re)learning cards that cross a day boundary.

The review limit is always applied first to interday learning cards, and
then review cards. This option will control the order the gathered cards are shown in,
but interday learning cards will always be gathered first. */
    fun deckConfigInterdayStepPriorityTooltip(): String {
        return translate(11, 115, mapOf())
    }


    /** This multiplier is applied to all reviews, and minor adjustments can be used
to make Anki more conservative or aggressive in its scheduling. Please see
the manual before changing this option. */
    fun deckConfigIntervalModifierTooltip(): String {
        return translate(11, 116, mapOf())
    }


    /** The provided FSRS parameters are invalid. Leave them blank to use the default values. */
    fun deckConfigInvalidParameters(): String {
        return translate(11, 117, mapOf())
    }


    /** Parameters must be either left blank to use the defaults, or must be 17 comma-separated numbers. */
    fun deckConfigInvalidWeights(): String {
        return translate(11, 118, mapOf())
    }


    /** Iteration: {$count}... */
    fun deckConfigIterations(`count`: Int): String {
        return translate(11, 119, mapOf("count" to asTranslateArg(`count`)))
    }


    /** The graduating interval should be at least as long as your final learning step. */
    fun deckConfigLearningStepAboveGraduatingInterval(): String {
        return translate(11, 120, mapOf())
    }


    /** Learning steps */
    fun deckConfigLearningSteps(): String {
        return translate(11, 121, mapOf())
    }


    /** One or more delays, separated by spaces. The first delay will be used
when you press the `Again` button on a new card, and is 1 minute by default.
The `Good` button will advance to the next step, which is 10 minutes by default.
Once all steps have been passed, the card will become a review card, and
will appear on a different day.  */
    fun deckConfigLearningStepsTooltip(): String {
        return translate(11, 122, mapOf())
    }


    /** `Tag Only`: Add a 'leech' tag to the note, and display a pop-up.

`Suspend Card`: In addition to tagging the note, hide the card until it is
manually unsuspended. */
    fun deckConfigLeechActionTooltip(): String {
        return translate(11, 123, mapOf())
    }


    /** The number of times `Again` needs to be pressed on a review card before it is
marked as a leech. Leeches are cards that consume a lot of your time, and
when a card is marked as a leech, it's a good idea to rewrite it, delete it, or
think of a mnemonic to help you remember it. */
    fun deckConfigLeechThresholdTooltip(): String {
        return translate(11, 124, mapOf())
    }


    /** When studying a deck that has subdecks inside it, the limits set on each
subdeck control the maximum number of cards gathered from that particular deck.
The selected deck's limits control the total cards that will be shown. */
    fun deckConfigLimitDeckV3(): String {
        return translate(11, 125, mapOf())
    }


    /** The review limit also affects interday learning cards. When applying the limit,
interday learning cards are gathered first, then review cards. */
    fun deckConfigLimitInterdayBoundByReviews(): String {
        return translate(11, 126, mapOf())
    }


    /** The review limit affects the new limit. For example, if your review limit is
set to 200, and you have 190 reviews waiting, a maximum of 10 new cards will
be introduced. If your review limit has been reached, no new cards will be
shown. */
    fun deckConfigLimitNewBoundByReviews(): String {
        return translate(11, 127, mapOf())
    }


    /** The parameters should only be modified using the optimize button. Manually editing them is heavily advised against. */
    fun deckConfigManualParameterEditWarning(): String {
        return translate(11, 128, mapOf())
    }


    /** Maximum answer seconds */
    fun deckConfigMaximumAnswerSecs(): String {
        return translate(11, 129, mapOf())
    }


    /** Anki can schedule your reviews more efficiently when you keep each question short. */
    fun deckConfigMaximumAnswerSecsAboveRecommended(): String {
        return translate(11, 130, mapOf())
    }


    /** The maximum number of seconds to record for a single review. If an answer
exceeds this time (because you stepped away from the screen for example),
the time taken will be recorded as the limit you have set. */
    fun deckConfigMaximumAnswerSecsTooltip(): String {
        return translate(11, 131, mapOf())
    }


    /** The maximum number of days a review card will wait. When reviews have
reached the limit, `Hard`, `Good` and `Easy` will all give the same delay.
The shorter you set this, the greater your workload will be. */
    fun deckConfigMaximumIntervalTooltip(): String {
        return translate(11, 132, mapOf())
    }


    /** The minimum interval given to a review card after answering `Again`. */
    fun deckConfigMinimumIntervalTooltip(): String {
        return translate(11, 133, mapOf())
    }


    /** Only {$count} reviews were found. You must have at least 400 reviews for this operation. */
    fun deckConfigMustHave400Reviews(`count`: Int): String {
        return translate(11, 134, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Name */
    fun deckConfigNamePrompt(): String {
        return translate(11, 135, mapOf())
    }


    /** New card sort order */
    fun deckConfigNewCardSortOrder(): String {
        return translate(11, 136, mapOf())
    }


    /** `Card type, then order gathered`: Shows cards in order of card type number.
Cards of each card type number are shown in the order they were gathered. 
If you have sibling burying disabled, this will ensure all front→back cards are seen before any back→front cards.
This is useful to have all cards of the same note shown in the same session, but not
too close to one another.

`Order gathered`: Shows cards exactly as they were gathered. If sibling burying is disabled,
this will typically result in all cards of a note being seen one after the other.

`Card type, then random`: Shows cards in order of card type number. Cards of each card
type number are shown in a random order. This order is useful if you don't want sibling cards
to appear too close to each other, but still want the cards to appear in a random order.

`Random note, then card type`: Picks notes at random, then shows all of its cards
in order.

`Random`: Shows cards in a random order. */
    fun deckConfigNewCardSortOrderTooltip2(): String {
        return translate(11, 137, mapOf())
    }


    /** New cards ignore review limit */
    fun deckConfigNewCardsIgnoreReviewLimit(): String {
        return translate(11, 138, mapOf())
    }


    /** By default, the review limit also applies to new cards, and no new cards will be
shown when the review limit has been reached. If this option is enabled, new cards
will be shown regardless of the review limit. */
    fun deckConfigNewCardsIgnoreReviewLimitTooltip(): String {
        return translate(11, 139, mapOf())
    }


    /** New card gather order */
    fun deckConfigNewGatherPriority(): String {
        return translate(11, 140, mapOf())
    }


    /** Deck */
    fun deckConfigNewGatherPriorityDeck(): String {
        return translate(11, 141, mapOf())
    }


    /** Deck, then random notes */
    fun deckConfigNewGatherPriorityDeckThenRandomNotes(): String {
        return translate(11, 142, mapOf())
    }


    /** Descending position */
    fun deckConfigNewGatherPriorityPositionHighestFirst(): String {
        return translate(11, 143, mapOf())
    }


    /** Ascending position */
    fun deckConfigNewGatherPriorityPositionLowestFirst(): String {
        return translate(11, 144, mapOf())
    }


    /** Random cards */
    fun deckConfigNewGatherPriorityRandomCards(): String {
        return translate(11, 145, mapOf())
    }


    /** Random notes */
    fun deckConfigNewGatherPriorityRandomNotes(): String {
        return translate(11, 146, mapOf())
    }


    /** `Deck`: Gathers cards from each subdeck in order, starting from the top. Cards from each subdeck are
gathered in ascending position. If the daily limit of the selected deck is reached, gathering
can stop before all subdecks have been checked. This order is fastest in large collections, and
allows you to prioritize subdecks that are closer to the top.

`Ascending position`: Gathers cards by ascending position (due #), which is typically
the oldest-added first.

`Descending position`: Gathers cards by descending position (due #), which is typically
the latest-added first.

`Random notes`: Picks notes at random, then gathers all of its cards.

`Random cards`: Gathers cards in a random order. */
    fun deckConfigNewGatherPriorityTooltip2(): String {
        return translate(11, 147, mapOf())
    }


    /** Insertion order */
    fun deckConfigNewInsertionOrder(): String {
        return translate(11, 148, mapOf())
    }


    /** Random */
    fun deckConfigNewInsertionOrderRandom(): String {
        return translate(11, 149, mapOf())
    }


    /** With the v3 scheduler, it is better to leave this set to sequential, and
adjust the new card gather order instead. */
    fun deckConfigNewInsertionOrderRandomWithV3(): String {
        return translate(11, 150, mapOf())
    }


    /** Sequential (oldest cards first) */
    fun deckConfigNewInsertionOrderSequential(): String {
        return translate(11, 151, mapOf())
    }


    /** Controls the position (due #) new cards are assigned when you add new cards.
Cards with a lower due number will be shown first when studying. Changing
this option will automatically update the existing position of new cards. */
    fun deckConfigNewInsertionOrderTooltip(): String {
        return translate(11, 152, mapOf())
    }


    /** The multiplier applied to a review interval when answering `Again`. */
    fun deckConfigNewIntervalTooltip(): String {
        return translate(11, 153, mapOf())
    }


    /** The maximum number of new cards to introduce in a day, if new cards are available.
Because new material will increase your short-term review workload, this should typically
be at least 10x smaller than your review limit. */
    fun deckConfigNewLimitTooltip(): String {
        return translate(11, 154, mapOf())
    }


    /** New/review order */
    fun deckConfigNewReviewPriority(): String {
        return translate(11, 155, mapOf())
    }


    /** When to show new cards in relation to review cards. */
    fun deckConfigNewReviewPriorityTooltip(): String {
        return translate(11, 156, mapOf())
    }


    /** Insufficient review history to perform this operation. */
    fun deckConfigNotEnoughHistory(): String {
        return translate(11, 157, mapOf())
    }


    /** You can optimize all presets at once by using the dropdown button next to "Save". */
    fun deckConfigOptimizeAllTip(): String {
        return translate(11, 158, mapOf())
    }


    /** Optimize Current Preset */
    fun deckConfigOptimizeButton(): String {
        return translate(11, 159, mapOf())
    }


    /** Optimizing preset {$current_count}/{$total_count}... */
    fun deckConfigOptimizingPreset(`currentCount`: Int, `totalCount`: Int): String {
        return translate(11, 160, mapOf("current_count" to asTranslateArg(`currentCount`), "total_count" to asTranslateArg(`totalCount`)))
    }


    /** Display Order */
    fun deckConfigOrderingTitle(): String {
        return translate(11, 161, mapOf())
    }


    /** {$pct}% */
    fun deckConfigPercentInput(`pct`: String): String {
        return translate(11, 162, mapOf("pct" to asTranslateArg(`pct`)))
    }


    /** {$pct}% of {$reviews} reviews */
    fun deckConfigPercentOfReviews(`reviews`: Int, `pct`: String): String {
        return translate(11, 163, mapOf("reviews" to asTranslateArg(`reviews`), "pct" to asTranslateArg(`pct`)))
    }


    /** Default parameters
(Press "" periodically to allow FSRS to better adjust to your memory) */
    fun deckConfigPlaceholderParameters(): String {
        return translate(11, 164, mapOf())
    }


    /** Please save your changes first. */
    fun deckConfigPleaseSaveYourChangesFirst(): String {
        return translate(11, 165, mapOf())
    }


    /** (Plotted on the X-axis) */
    fun deckConfigPlottedOnXAxis(): String {
        return translate(11, 166, mapOf())
    }


    /** Minimum recommended retention: {$num} */
    fun deckConfigPredictedMinimumRecommendedRetention(`num`: TranslateArg): String {
        return translate(11, 167, mapOf("num" to asTranslateArg(`num`)))
    }


    /** Minimum recommended retention: {$num} */
    fun deckConfigPredictedOptimalRetention(`num`: TranslateArg): String {
        return translate(11, 168, mapOf("num" to asTranslateArg(`num`)))
    }


    /** Question action */
    fun deckConfigQuestionAction(): String {
        return translate(11, 169, mapOf())
    }


    /** Show Answer */
    fun deckConfigQuestionActionShowAnswer(): String {
        return translate(11, 170, mapOf())
    }


    /** Show Reminder */
    fun deckConfigQuestionActionShowReminder(): String {
        return translate(11, 171, mapOf())
    }


    /** The action to perform after the question is shown, and time has elapsed. */
    fun deckConfigQuestionActionToolTip(): String {
        return translate(11, 172, mapOf())
    }


    /** Relearning steps */
    fun deckConfigRelearningSteps(): String {
        return translate(11, 173, mapOf())
    }


    /** The minimum lapse interval should be at least as long as your final relearning step. */
    fun deckConfigRelearningStepsAboveMinimumInterval(): String {
        return translate(11, 174, mapOf())
    }


    /** Zero or more delays, separated by spaces. By default, pressing the `Again`
button on a review card will show it again 10 minutes later. If no delays
are provided, the card will have its interval changed, without entering
relearning.  */
    fun deckConfigRelearningStepsTooltip(): String {
        return translate(11, 175, mapOf())
    }


    /** Remove Preset */
    fun deckConfigRemoveGroup(): String {
        return translate(11, 176, mapOf())
    }


    /** Rename Preset */
    fun deckConfigRenameGroup(): String {
        return translate(11, 177, mapOf())
    }


    /** Reschedule cards on change */
    fun deckConfigRescheduleCardsOnChange(): String {
        return translate(11, 178, mapOf())
    }


    /** Affects the entire collection, and is not saved.

This option controls whether the due dates of cards will be changed when you enable FSRS, or optimize
the parameters. The default is not to reschedule cards: future reviews will use the new scheduling, but
there will be no immediate change to your workload. If rescheduling is enabled, the due dates of cards
will be changed. */
    fun deckConfigRescheduleCardsOnChangeTooltip(): String {
        return translate(11, 179, mapOf())
    }


    /** Depending on your desired retention, this can result in a large number of cards becoming
due, so is not recommended when first switching from SM-2.

Use this option sparingly, as it will add a review entry to each of your cards, and
increase the size of your collection. */
    fun deckConfigRescheduleCardsWarning(): String {
        return translate(11, 180, mapOf())
    }


    /** Restore this setting to its default value? */
    fun deckConfigRevertButtonTooltip(): String {
        return translate(11, 181, mapOf())
    }


    /** The maximum number of review cards to show in a day,
if cards are ready for review. */
    fun deckConfigReviewLimitTooltip(): String {
        return translate(11, 182, mapOf())
    }


    /** Mix with reviews */
    fun deckConfigReviewMixMixWithReviews(): String {
        return translate(11, 183, mapOf())
    }


    /** Show after reviews */
    fun deckConfigReviewMixShowAfterReviews(): String {
        return translate(11, 184, mapOf())
    }


    /** Show before reviews */
    fun deckConfigReviewMixShowBeforeReviews(): String {
        return translate(11, 185, mapOf())
    }


    /** Review sort order */
    fun deckConfigReviewSortOrder(): String {
        return translate(11, 186, mapOf())
    }


    /** The default order prioritizes cards that have been waiting longest, so that
if you have a backlog of reviews, the longest-waiting ones will appear
first. If you have a large backlog that will take more than a few days to
clear, or wish to see cards in subdeck order, you may find the alternate
sort orders preferable. */
    fun deckConfigReviewSortOrderTooltip(): String {
        return translate(11, 187, mapOf())
    }


    /** If adding {$cards} new cards each day, your review limit should be at least {$expected}. */
    fun deckConfigReviewsTooLow(`cards`: Int, `expected`: TranslateArg): String {
        return translate(11, 188, mapOf("cards" to asTranslateArg(`cards`), "expected" to asTranslateArg(`expected`)))
    }


    /** Optimize All Presets */
    fun deckConfigSaveAndOptimize(): String {
        return translate(11, 189, mapOf())
    }


    /** Save */
    fun deckConfigSaveButton(): String {
        return translate(11, 190, mapOf())
    }


    /** Save Changes to Preset */
    fun deckConfigSaveOptionsToPreset(): String {
        return translate(11, 191, mapOf())
    }


    /** Overwrite the options in your current preset with the options that are currently set in the simulator? */
    fun deckConfigSaveOptionsToPresetConfirm(): String {
        return translate(11, 192, mapOf())
    }


    /** Save to All Subdecks */
    fun deckConfigSaveToAllSubdecks(): String {
        return translate(11, 193, mapOf())
    }


    /** Seconds to show answer for */
    fun deckConfigSecondsToShowAnswer(): String {
        return translate(11, 194, mapOf())
    }


    /** When auto advance is activated, the number of seconds to wait before applying the answer action. Set to 0 to disable. */
    fun deckConfigSecondsToShowAnswerTooltip2(): String {
        return translate(11, 195, mapOf())
    }


    /** Seconds to show question for */
    fun deckConfigSecondsToShowQuestion(): String {
        return translate(11, 196, mapOf())
    }


    /** When auto advance is activated, the number of seconds to wait before revealing the answer. Set to 0 to disable. */
    fun deckConfigSecondsToShowQuestionTooltip(): String {
        return translate(11, 197, mapOf())
    }


    /** When auto advance is activated, the number of seconds to wait before revealing the answer. Set to 0 to disable. */
    fun deckConfigSecondsToShowQuestionTooltip2(): String {
        return translate(11, 198, mapOf())
    }


    /** When auto advance is activated, the number of seconds to wait before applying the question action. Set to 0 to disable. */
    fun deckConfigSecondsToShowQuestionTooltip3(): String {
        return translate(11, 199, mapOf())
    }


    /** Preset */
    fun deckConfigSharedPreset(): String {
        return translate(11, 200, mapOf())
    }


    /** On the Study screen, show a timer that counts the time you're
taking to study each card. */
    fun deckConfigShowAnswerTimerTooltip(): String {
        return translate(11, 201, mapOf())
    }


    /** Show Reminder */
    fun deckConfigShowReminder(): String {
        return translate(11, 202, mapOf())
    }


    /** Simulate */
    fun deckConfigSimulate(): String {
        return translate(11, 203, mapOf())
    }


    /** Skip question when replaying answer */
    fun deckConfigSkipQuestionWhenReplaying(): String {
        return translate(11, 204, mapOf())
    }


    /** {$text} (slow) */
    fun deckConfigSlowSuffix(`text`: String): String {
        return translate(11, 205, mapOf("text" to asTranslateArg(`text`)))
    }


    /** Smaller numbers indicate a better fit to your review history. */
    fun deckConfigSmallerIsBetter(): String {
        return translate(11, 206, mapOf())
    }


    /** Smooth graph */
    fun deckConfigSmoothGraph(): String {
        return translate(11, 207, mapOf())
    }


    /** Easy cards first */
    fun deckConfigSortOrderAscendingDifficulty(): String {
        return translate(11, 208, mapOf())
    }


    /** Ascending ease */
    fun deckConfigSortOrderAscendingEase(): String {
        return translate(11, 209, mapOf())
    }


    /** Ascending intervals */
    fun deckConfigSortOrderAscendingIntervals(): String {
        return translate(11, 210, mapOf())
    }


    /** Card type, then random */
    fun deckConfigSortOrderCardTemplateThenRandom(): String {
        return translate(11, 211, mapOf())
    }


    /** Deck, then due date */
    fun deckConfigSortOrderDeckThenDueDate(): String {
        return translate(11, 212, mapOf())
    }


    /** Difficult cards first */
    fun deckConfigSortOrderDescendingDifficulty(): String {
        return translate(11, 213, mapOf())
    }


    /** Descending ease */
    fun deckConfigSortOrderDescendingEase(): String {
        return translate(11, 214, mapOf())
    }


    /** Descending intervals */
    fun deckConfigSortOrderDescendingIntervals(): String {
        return translate(11, 215, mapOf())
    }


    /** Due date, then deck */
    fun deckConfigSortOrderDueDateThenDeck(): String {
        return translate(11, 216, mapOf())
    }


    /** Due date, then random */
    fun deckConfigSortOrderDueDateThenRandom(): String {
        return translate(11, 217, mapOf())
    }


    /** Order gathered */
    fun deckConfigSortOrderGather(): String {
        return translate(11, 218, mapOf())
    }


    /** Random */
    fun deckConfigSortOrderRandom(): String {
        return translate(11, 219, mapOf())
    }


    /** Random note, then card type */
    fun deckConfigSortOrderRandomNoteThenTemplate(): String {
        return translate(11, 220, mapOf())
    }


    /** Ascending retrievability */
    fun deckConfigSortOrderRetrievabilityAscending(): String {
        return translate(11, 221, mapOf())
    }


    /** Descending retrievability */
    fun deckConfigSortOrderRetrievabilityDescending(): String {
        return translate(11, 222, mapOf())
    }


    /** Card type, then order gathered */
    fun deckConfigSortOrderTemplateThenGather(): String {
        return translate(11, 223, mapOf())
    }


    /** The ease multiplier new cards start with. By default, the `Good` button on a
newly-learned card will delay the next review by 2.5x the previous delay. */
    fun deckConfigStartingEaseTooltip(): String {
        return translate(11, 224, mapOf())
    }


    /** When FSRS is enabled, steps of 1 day or more are not recommended. */
    fun deckConfigStepsTooLargeForFsrs(): String {
        return translate(11, 225, mapOf())
    }


    /** Stop on-screen timer on answer */
    fun deckConfigStopTimerOnAnswer(): String {
        return translate(11, 226, mapOf())
    }


    /** Whether to stop the on-screen timer when the answer is revealed.
This doesn't affect statistics. */
    fun deckConfigStopTimerOnAnswerTooltip(): String {
        return translate(11, 227, mapOf())
    }


    /** Suspend leeches */
    fun deckConfigSuspendLeeches(): String {
        return translate(11, 228, mapOf())
    }


    /** - `Preset`: The limit applies to all decks using this preset.
- `This deck`: The limit is specific to this deck.
- `Today only`: Make a temporary change to this deck's limit. */
    fun deckConfigTabDescription(): String {
        return translate(11, 229, mapOf())
    }


    /** It's been a while - using the Optimize All Presets button is recommended. */
    fun deckConfigTimeToOptimize(): String {
        return translate(11, 230, mapOf())
    }


    /** Timers */
    fun deckConfigTimerTitle(): String {
        return translate(11, 231, mapOf())
    }


    /** Deck Options */
    fun deckConfigTitle(): String {
        return translate(11, 232, mapOf())
    }


    /** Today only */
    fun deckConfigTodayOnly(): String {
        return translate(11, 233, mapOf())
    }


    /** A maximum interval less than 6 months is not recommended. */
    fun deckConfigTooShortMaximumInterval(): String {
        return translate(11, 234, mapOf())
    }


    /** Unable to determine a minimum recommended retention. */
    fun deckConfigUnableToDetermineDesiredRetention(): String {
        return translate(11, 235, mapOf())
    }


    /** Updating cards: {$current_cards_count}/{$total_cards_count}... */
    fun deckConfigUpdatingCards(`currentCardsCount`: Int, `totalCardsCount`: Int): String {
        return translate(11, 236, mapOf("current_cards_count" to asTranslateArg(`currentCardsCount`), "total_cards_count" to asTranslateArg(`totalCardsCount`)))
    }


    /** used by {$decks} decks */
    fun deckConfigUsedByDecks(`decks`: Int): String {
        return translate(11, 237, mapOf("decks" to asTranslateArg(`decks`)))
    }


    /** Wait for audio */
    fun deckConfigWaitForAudio(): String {
        return translate(11, 238, mapOf())
    }


    /** Wait for audio to finish before automatically revealing answer or next question. */
    fun deckConfigWaitForAudioTooltip(): String {
        return translate(11, 239, mapOf())
    }


    /** Wait for audio to finish before automatically applying the question action or answer action. */
    fun deckConfigWaitForAudioTooltip2(): String {
        return translate(11, 240, mapOf())
    }


    /** FSRS parameters */
    fun deckConfigWeights(): String {
        return translate(11, 241, mapOf())
    }


    /** FSRS parameters affect how cards are scheduled. Anki will start with default parameters. Once
you've accumulated 1000+ reviews, you can use the option below to optimize the parameters to best
match your performance in decks using this preset. */
    fun deckConfigWeightsTooltip(): String {
        return translate(11, 242, mapOf())
    }


    /** FSRS parameters affect how cards are scheduled. Anki will start with default parameters. You can use 
the option below to optimize the parameters to best match your performance in decks using this preset. */
    fun deckConfigWeightsTooltip2(): String {
        return translate(11, 243, mapOf())
    }


    /** Which deck would you like to display options for? */
    fun deckConfigWhichDeck(): String {
        return translate(11, 244, mapOf())
    }


    /** The requested change will require a one-way sync. If you have made changes
on another device, and not synced them to this device yet, please do so before
you proceed. */
    fun deckConfigWillRequireFullSync(): String {
        return translate(11, 245, mapOf())
    }


    /** Approximate workload: {$factor}x
(compared to {$previousDR}% desired retention) */
    fun deckConfigWorkloadFactorChange(`factor`: String, `previousDr`: String): String {
        return translate(11, 246, mapOf("factor" to asTranslateArg(`factor`), "previousDR" to asTranslateArg(`previousDr`)))
    }


    /** The higher your desired retention, the more frequently cards will be shown to you. */
    fun deckConfigWorkloadFactorUnchanged(): String {
        return translate(11, 247, mapOf())
    }


    /** Add New Deck (Ctrl+N) */
    fun decksAddNewDeckCtrlandn(): String {
        return translate(12, 0, mapOf())
    }


    /** Build */
    fun decksBuild(): String {
        return translate(12, 1, mapOf())
    }


    /** cards selected by */
    fun decksCardsSelectedBy(): String {
        return translate(12, 2, mapOf())
    }


    /** Choose Deck */
    fun decksChooseDeck(): String {
        return translate(12, 3, mapOf())
    }


    /** Create Deck */
    fun decksCreateDeck(): String {
        return translate(12, 4, mapOf())
    }


    /** Custom steps (in minutes) */
    fun decksCustomStepsInMinutes(): String {
        return translate(12, 5, mapOf())
    }


    /** Deck */
    fun decksDeck(): String {
        return translate(12, 6, mapOf())
    }


    /** Decreasing intervals */
    fun decksDecreasingIntervals(): String {
        return translate(12, 7, mapOf())
    }


    /** Delay for {$button} */
    fun decksDelayForButton(`button`: String): String {
        return translate(12, 8, mapOf("button" to asTranslateArg(`button`)))
    }


    /** Delete Deck */
    fun decksDeleteDeck(): String {
        return translate(12, 9, mapOf())
    }


    /** Enable second filter */
    fun decksEnableSecondFilter(): String {
        return translate(12, 10, mapOf())
    }


    /** Filter: */
    fun decksFilter(): String {
        return translate(12, 11, mapOf())
    }


    /** Filter 2 */
    fun decksFilter2(): String {
        return translate(12, 12, mapOf())
    }


    /** No cards matched the provided search. Some cards may have been excluded because they are in a different filtered deck, or suspended. */
    fun decksFilteredDeckSearchEmpty(): String {
        return translate(12, 13, mapOf())
    }


    /** Get Shared */
    fun decksGetShared(): String {
        return translate(12, 14, mapOf())
    }


    /** Import File */
    fun decksImportFile(): String {
        return translate(12, 15, mapOf())
    }


    /** Increasing intervals */
    fun decksIncreasingIntervals(): String {
        return translate(12, 16, mapOf())
    }


    /** Latest added first */
    fun decksLatestAddedFirst(): String {
        return translate(12, 17, mapOf())
    }


    /** Learn */
    fun decksLearnHeader(): String {
        return translate(12, 18, mapOf())
    }


    /** Limit to */
    fun decksLimitTo(): String {
        return translate(12, 19, mapOf())
    }


    /** minutes */
    fun decksMinutes(): String {
        return translate(12, 20, mapOf())
    }


    /** Most lapses */
    fun decksMostLapses(): String {
        return translate(12, 21, mapOf())
    }


    /** New deck name: */
    fun decksNewDeckName(): String {
        return translate(12, 22, mapOf())
    }


    /** [no deck] */
    fun decksNoDeck(): String {
        return translate(12, 23, mapOf())
    }


    /** Oldest seen first */
    fun decksOldestSeenFirst(): String {
        return translate(12, 24, mapOf())
    }


    /** Order added */
    fun decksOrderAdded(): String {
        return translate(12, 25, mapOf())
    }


    /** Order due */
    fun decksOrderDue(): String {
        return translate(12, 26, mapOf())
    }


    /** Please select something. */
    fun decksPleaseSelectSomething(): String {
        return translate(12, 27, mapOf())
    }


    /** Random */
    fun decksRandom(): String {
        return translate(12, 28, mapOf())
    }


    /** Relative overdueness */
    fun decksRelativeOverdueness(): String {
        return translate(12, 29, mapOf())
    }


    /** Delay Repeat failed cards after */
    fun decksRepeatFailedCardsAfter(): String {
        return translate(12, 30, mapOf())
    }


    /** Reschedule cards based on my answers in this deck */
    fun decksRescheduleCardsBasedOnMyAnswers(): String {
        return translate(12, 31, mapOf())
    }


    /** Due */
    fun decksReviewHeader(): String {
        return translate(12, 32, mapOf())
    }


    /** Study */
    fun decksStudy(): String {
        return translate(12, 33, mapOf())
    }


    /** Study Deck */
    fun decksStudyDeck(): String {
        return translate(12, 34, mapOf())
    }


    /** Target Deck (Ctrl+D) */
    fun decksTargetDeckCtrlandd(): String {
        return translate(12, 35, mapOf())
    }


    /** Show any excluded cards */
    fun decksUnmovableCards(): String {
        return translate(12, 36, mapOf())
    }


    /** (0 = return card to original deck) */
    fun decksZeroMinutesHint(): String {
        return translate(12, 37, mapOf())
    }


    /** Create/update this deck even if empty */
    fun decksCreateEvenIfEmpty(): String {
        return translate(12, 38, mapOf())
    }


    /** Toggle actual size */
    fun editingActualSize(): String {
        return translate(13, 0, mapOf())
    }


    /** Add Media */
    fun editingAddMedia(): String {
        return translate(13, 1, mapOf())
    }


    /** Align left */
    fun editingAlignLeft(): String {
        return translate(13, 2, mapOf())
    }


    /** Align right */
    fun editingAlignRight(): String {
        return translate(13, 3, mapOf())
    }


    /** Alignment */
    fun editingAlignment(): String {
        return translate(13, 4, mapOf())
    }


    /** An error occurred while opening {$val} */
    fun editingAnErrorOccurredWhileOpening(`val`: TranslateArg): String {
        return translate(13, 5, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Attach pictures/audio/video */
    fun editingAttachPicturesaudiovideo(): String {
        return translate(13, 6, mapOf())
    }


    /** Bold text */
    fun editingBoldText(): String {
        return translate(13, 7, mapOf())
    }


    /** Cards */
    fun editingCards(): String {
        return translate(13, 8, mapOf())
    }


    /** Center */
    fun editingCenter(): String {
        return translate(13, 9, mapOf())
    }


    /** Change color */
    fun editingChangeColor(): String {
        return translate(13, 10, mapOf())
    }


    /** Auto-close HTML tags */
    fun editingCloseHtmlTags(): String {
        return translate(13, 11, mapOf())
    }


    /** Cloze deletion (new card) */
    fun editingClozeDeletion(): String {
        return translate(13, 12, mapOf())
    }


    /** Cloze deletion (same card) */
    fun editingClozeDeletionRepeat(): String {
        return translate(13, 13, mapOf())
    }


    /** Collapse */
    fun editingCollapse(): String {
        return translate(13, 14, mapOf())
    }


    /** Collapse field */
    fun editingCollapseField(): String {
        return translate(13, 15, mapOf())
    }


    /** Copy image */
    fun editingCopyImage(): String {
        return translate(13, 16, mapOf())
    }


    /** Couldn't record audio. Have you installed 'lame'? */
    fun editingCouldntRecordAudioHaveYouInstalled(): String {
        return translate(13, 17, mapOf())
    }


    /** Customize Card Templates */
    fun editingCustomizeCardTemplates(): String {
        return translate(13, 18, mapOf())
    }


    /** Customize Fields */
    fun editingCustomizeFields(): String {
        return translate(13, 19, mapOf())
    }


    /** Cut */
    fun editingCut(): String {
        return translate(13, 20, mapOf())
    }


    /** double-click image */
    fun editingDoubleClickImage(): String {
        return translate(13, 21, mapOf())
    }


    /** double-click to collapse */
    fun editingDoubleClickToCollapse(): String {
        return translate(13, 22, mapOf())
    }


    /** double-click to expand */
    fun editingDoubleClickToExpand(): String {
        return translate(13, 23, mapOf())
    }


    /** Edit Current */
    fun editingEditCurrent(): String {
        return translate(13, 24, mapOf())
    }


    /** Edit HTML */
    fun editingEditHtml(): String {
        return translate(13, 25, mapOf())
    }


    /** Equations */
    fun editingEquations(): String {
        return translate(13, 26, mapOf())
    }


    /** Expand */
    fun editingExpand(): String {
        return translate(13, 27, mapOf())
    }


    /** Expand field */
    fun editingExpandField(): String {
        return translate(13, 28, mapOf())
    }


    /** Fields */
    fun editingFields(): String {
        return translate(13, 29, mapOf())
    }


    /** Float left */
    fun editingFloatLeft(): String {
        return translate(13, 30, mapOf())
    }


    /** No float */
    fun editingFloatNone(): String {
        return translate(13, 31, mapOf())
    }


    /** Float right */
    fun editingFloatRight(): String {
        return translate(13, 32, mapOf())
    }


    /** From Clipboard */
    fun editingFromClipboard(): String {
        return translate(13, 33, mapOf())
    }


    /** HTML Editor */
    fun editingHtmlEditor(): String {
        return translate(13, 34, mapOf())
    }


    /** Align Bottom */
    fun editingImageOcclusionAlignBottom(): String {
        return translate(13, 35, mapOf())
    }


    /** Align Horizontal Centers */
    fun editingImageOcclusionAlignHCenter(): String {
        return translate(13, 36, mapOf())
    }


    /** Align Left */
    fun editingImageOcclusionAlignLeft(): String {
        return translate(13, 37, mapOf())
    }


    /** Align Right */
    fun editingImageOcclusionAlignRight(): String {
        return translate(13, 38, mapOf())
    }


    /** Align Top */
    fun editingImageOcclusionAlignTop(): String {
        return translate(13, 39, mapOf())
    }


    /** Align Vertical Centers */
    fun editingImageOcclusionAlignVCenter(): String {
        return translate(13, 40, mapOf())
    }


    /** Alignment */
    fun editingImageOcclusionAlignment(): String {
        return translate(13, 41, mapOf())
    }


    /** Are you sure you want to reset this image occlusion? */
    fun editingImageOcclusionConfirmReset(): String {
        return translate(13, 42, mapOf())
    }


    /** Delete */
    fun editingImageOcclusionDelete(): String {
        return translate(13, 43, mapOf())
    }


    /** Duplicate */
    fun editingImageOcclusionDuplicate(): String {
        return translate(13, 44, mapOf())
    }


    /** Ellipse */
    fun editingImageOcclusionEllipseTool(): String {
        return translate(13, 45, mapOf())
    }


    /** Fill with colour */
    fun editingImageOcclusionFillTool(): String {
        return translate(13, 46, mapOf())
    }


    /** Group Selection */
    fun editingImageOcclusionGroup(): String {
        return translate(13, 47, mapOf())
    }


    /** Image Occlusion Mode */
    fun editingImageOcclusionMode(): String {
        return translate(13, 48, mapOf())
    }


    /** Polygon */
    fun editingImageOcclusionPolygonTool(): String {
        return translate(13, 49, mapOf())
    }


    /** Rectangle */
    fun editingImageOcclusionRectangleTool(): String {
        return translate(13, 50, mapOf())
    }


    /** Reset Image Occlusion */
    fun editingImageOcclusionReset(): String {
        return translate(13, 51, mapOf())
    }


    /** Select All */
    fun editingImageOcclusionSelectAll(): String {
        return translate(13, 52, mapOf())
    }


    /** Select */
    fun editingImageOcclusionSelectTool(): String {
        return translate(13, 53, mapOf())
    }


    /** Text */
    fun editingImageOcclusionTextTool(): String {
        return translate(13, 54, mapOf())
    }


    /** Toggle Mask Editor */
    fun editingImageOcclusionToggleMaskEditor(): String {
        return translate(13, 55, mapOf())
    }


    /** Toggle Translucency */
    fun editingImageOcclusionToggleTranslucent(): String {
        return translate(13, 56, mapOf())
    }


    /** Ungroup Selection */
    fun editingImageOcclusionUngroup(): String {
        return translate(13, 57, mapOf())
    }


    /** Zoom In */
    fun editingImageOcclusionZoomIn(): String {
        return translate(13, 58, mapOf())
    }


    /** Zoom Out */
    fun editingImageOcclusionZoomOut(): String {
        return translate(13, 59, mapOf())
    }


    /** Reset Zoom */
    fun editingImageOcclusionZoomReset(): String {
        return translate(13, 60, mapOf())
    }


    /** Zoom */
    fun editingImageOcclusionZoomTool(): String {
        return translate(13, 61, mapOf())
    }


    /** Increase indent */
    fun editingIndent(): String {
        return translate(13, 62, mapOf())
    }


    /** Italic text */
    fun editingItalicText(): String {
        return translate(13, 63, mapOf())
    }


    /** Jump to tags with Ctrl+Shift+T */
    fun editingJumpToTagsWithCtrlandshiftandt(): String {
        return translate(13, 64, mapOf())
    }


    /** Justify */
    fun editingJustify(): String {
        return translate(13, 65, mapOf())
    }


    /** LaTeX */
    fun editingLatex(): String {
        return translate(13, 66, mapOf())
    }


    /** LaTeX equation */
    fun editingLatexEquation(): String {
        return translate(13, 67, mapOf())
    }


    /** LaTeX math env. */
    fun editingLatexMathEnv(): String {
        return translate(13, 68, mapOf())
    }


    /** MathJax block */
    fun editingMathjaxBlock(): String {
        return translate(13, 69, mapOf())
    }


    /** MathJax chemistry */
    fun editingMathjaxChemistry(): String {
        return translate(13, 70, mapOf())
    }


    /** MathJax inline */
    fun editingMathjaxInline(): String {
        return translate(13, 71, mapOf())
    }


    /** Press {$accept} to accept, {$newline} for new line. */
    fun editingMathjaxPlaceholder(`accept`: String, `newline`: String): String {
        return translate(13, 72, mapOf("accept" to asTranslateArg(`accept`), "newline" to asTranslateArg(`newline`)))
    }


    /** MathJax Preview */
    fun editingMathjaxPreview(): String {
        return translate(13, 73, mapOf())
    }


    /** Media */
    fun editingMedia(): String {
        return translate(13, 74, mapOf())
    }


    /** No image found on clipboard. */
    fun editingNoImageFoundOnClipboard(): String {
        return translate(13, 75, mapOf())
    }


    /** Open image */
    fun editingOpenImage(): String {
        return translate(13, 76, mapOf())
    }


    /** Ordered list */
    fun editingOrderedList(): String {
        return translate(13, 77, mapOf())
    }


    /** Decrease indent */
    fun editingOutdent(): String {
        return translate(13, 78, mapOf())
    }


    /** Paste */
    fun editingPaste(): String {
        return translate(13, 79, mapOf())
    }


    /** Record audio */
    fun editingRecordAudio(): String {
        return translate(13, 80, mapOf())
    }


    /** Remove formatting */
    fun editingRemoveFormatting(): String {
        return translate(13, 81, mapOf())
    }


    /** Restore original size */
    fun editingRestoreOriginalSize(): String {
        return translate(13, 82, mapOf())
    }


    /** Select formatting to remove */
    fun editingSelectRemoveFormatting(): String {
        return translate(13, 83, mapOf())
    }


    /** Show Duplicates */
    fun editingShowDuplicates(): String {
        return translate(13, 84, mapOf())
    }


    /** Show in folder */
    fun editingShowInFolder(): String {
        return translate(13, 85, mapOf())
    }


    /** Shrink Images */
    fun editingShrinkImages(): String {
        return translate(13, 86, mapOf())
    }


    /** Subscript */
    fun editingSubscript(): String {
        return translate(13, 87, mapOf())
    }


    /** Superscript */
    fun editingSuperscript(): String {
        return translate(13, 88, mapOf())
    }


    /** {$count} tags */
    fun editingTagCount(`count`: Int): String {
        return translate(13, 89, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Tags */
    fun editingTags(): String {
        return translate(13, 90, mapOf())
    }


    /** Add tag */
    fun editingTagsAdd(): String {
        return translate(13, 91, mapOf())
    }


    /** Copy tags */
    fun editingTagsCopy(): String {
        return translate(13, 92, mapOf())
    }


    /** Remove tags */
    fun editingTagsRemove(): String {
        return translate(13, 93, mapOf())
    }


    /** Select all tags */
    fun editingTagsSelectAll(): String {
        return translate(13, 94, mapOf())
    }


    /** Text color */
    fun editingTextColor(): String {
        return translate(13, 95, mapOf())
    }


    /** Text highlight color */
    fun editingTextHighlightColor(): String {
        return translate(13, 96, mapOf())
    }


    /** To make a cloze deletion on an existing note, you need to change it to a cloze type first, via 'Notes>Change Note Type' */
    fun editingToMakeAClozeDeletionOn(): String {
        return translate(13, 97, mapOf())
    }


    /** Toggle HTML Editor */
    fun editingToggleHtmlEditor(): String {
        return translate(13, 98, mapOf())
    }


    /** Toggle sticky */
    fun editingToggleSticky(): String {
        return translate(13, 99, mapOf())
    }


    /** Toggle Visual Editor */
    fun editingToggleVisualEditor(): String {
        return translate(13, 100, mapOf())
    }


    /** Underline text */
    fun editingUnderlineText(): String {
        return translate(13, 101, mapOf())
    }


    /** Unordered list */
    fun editingUnorderedList(): String {
        return translate(13, 102, mapOf())
    }


    /** Warning, cloze deletions will not work until you switch the type at the top to Cloze. */
    fun editingWarningClozeDeletionsWillNotWork(): String {
        return translate(13, 103, mapOf())
    }


    /** {$empty_count} of {$existing_count} cards empty ({$template_names}). */
    fun emptyCardsCountLine(`emptyCount`: Int, `existingCount`: Int, `templateNames`: String): String {
        return translate(14, 0, mapOf("empty_count" to asTranslateArg(`emptyCount`), "existing_count" to asTranslateArg(`existingCount`), "template_names" to asTranslateArg(`templateNames`)))
    }


    /** Delete */
    fun emptyCardsDeleteButton(): String {
        return translate(14, 1, mapOf())
    }


    /** Delete Empty Cards */
    fun emptyCardsDeleteEmptyCards(): String {
        return translate(14, 2, mapOf())
    }


    /** Delete Empty Notes */
    fun emptyCardsDeleteEmptyNotes(): String {
        return translate(14, 3, mapOf())
    }


    /** Deleted {$cards} cards. */
    fun emptyCardsDeletedCount(`cards`: Int): String {
        return translate(14, 4, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** Deleting... */
    fun emptyCardsDeleting(): String {
        return translate(14, 5, mapOf())
    }


    /** Empty cards for {$notetype}: */
    fun emptyCardsForNoteType(`notetype`: String): String {
        return translate(14, 6, mapOf("notetype" to asTranslateArg(`notetype`)))
    }


    /** No empty cards. */
    fun emptyCardsNotFound(): String {
        return translate(14, 7, mapOf())
    }


    /** Keep notes with no valid cards */
    fun emptyCardsPreserveNotesCheckbox(): String {
        return translate(14, 8, mapOf())
    }


    /** Empty Cards */
    fun emptyCardsWindowTitle(): String {
        return translate(14, 9, mapOf())
    }


    /** A maximum of 100 tags can be selected. Listing the
tags you want instead of the ones you don't want is usually simpler, and there
is no need to select child tags if you have selected a parent tag. */
    fun errors100TagsMax(): String {
        return translate(15, 0, mapOf())
    }


    /** An error occurred while accessing the database.

Possible causes:

- Antivirus, firewall, backup, or synchronization software may be
interfering with Anki. Try disabling such software and see if the
problem goes away.
- Your disk may be full.
- The Documents/Anki folder may be on a network drive.
- Files in the Documents/Anki folder may not be writeable.
- Your hard disk may have errors.

It's a good idea to run Tools>Check Database to ensure your collection is not corrupt. */
    fun errorsAccessingDb(): String {
        return translate(15, 1, mapOf())
    }


    /** # Error

An error occurred. Please start Anki while holding down the shift key,
which will temporarily disable the add-ons you have installed.

If the issue only occurs when add-ons are enabled, please use the
Tools > Add-ons menu item to disable some add-ons and restart Anki,
repeating until you discover the add-on that is causing the problem.

When you've discovered the add-on that is causing the problem, please
report the issue to the add-on author.

Debug info: */
    fun errorsAddonsActivePopup(): String {
        return translate(15, 2, mapOf())
    }


    /** Error in directive '{$directive}': {$error} */
    fun errorsBadDirective(`directive`: String, `error`: String): String {
        return translate(15, 3, mapOf("directive" to asTranslateArg(`directive`), "error" to asTranslateArg(`error`)))
    }


    /** This collection requires a newer version of Anki to open. */
    fun errorsCollectionTooNew(): String {
        return translate(15, 4, mapOf())
    }


    /** Copied to clipboard */
    fun errorsCopiedToClipboard(): String {
        return translate(15, 5, mapOf())
    }


    /** Copy Debug Info */
    fun errorsCopyDebugInfoButton(): String {
        return translate(15, 6, mapOf())
    }


    /** This action can only be used on a filtered deck. */
    fun errorsFilteredDeckRequired(): String {
        return translate(15, 7, mapOf())
    }


    /** Filtered decks can not have child decks. */
    fun errorsFilteredParentDeck(): String {
        return translate(15, 8, mapOf())
    }


    /** Your database appears to be in an inconsistent state. Please use the Check Database action. */
    fun errorsInconsistentDbState(): String {
        return translate(15, 9, mapOf())
    }


    /** This deck contains timestamps in the future. Please contact the deck author and ask them to fix the issue. */
    fun errorsInvalidIds(): String {
        return translate(15, 10, mapOf())
    }


    /** Invalid input: {$details} */
    fun errorsInvalidInputDetails(`details`: String): String {
        return translate(15, 11, mapOf("details" to asTranslateArg(`details`)))
    }


    /** Invalid input. */
    fun errorsInvalidInputEmpty(): String {
        return translate(15, 12, mapOf())
    }


    /** The problem may be caused by an add-on. */
    fun errorsMayBeAddon(): String {
        return translate(15, 13, mapOf())
    }


    /** Please select notes from only one note type. */
    fun errorsMultipleNotetypesSelected(): String {
        return translate(15, 14, mapOf())
    }


    /** No updates available. */
    fun errorsNoUpdatesAvailable(): String {
        return translate(15, 15, mapOf())
    }


    /** '{$option}' not set */
    fun errorsOptionNotSet(`option`: String): String {
        return translate(15, 16, mapOf("option" to asTranslateArg(`option`)))
    }


    /** A number was invalid or out of range. */
    fun errorsParseNumberFail(): String {
        return translate(15, 17, mapOf())
    }


    /** Please use the Check Database action, then try again. */
    fun errorsPleaseCheckDatabase(): String {
        return translate(15, 18, mapOf())
    }


    /** Please use the Check Media action, then try again. */
    fun errorsPleaseCheckMedia(): String {
        return translate(15, 19, mapOf())
    }


    /** # Error

An error occurred. Please use **Tools > Check Database** to see if
that fixes the problem.

If problems persist, please report the problem on our .
Please copy and paste the information below into your report. */
    fun errorsStandardPopup(): String {
        return translate(15, 20, mapOf())
    }


    /** Anki encountered a problem. Please follow the troubleshooting steps. */
    fun errorsStandardPopup2(): String {
        return translate(15, 21, mapOf())
    }


    /** Troubleshooting */
    fun errorsTroubleshootingButton(): String {
        return translate(15, 22, mapOf())
    }


    /** Anki was unable to open your collection file. If problems persist after restarting your computer, please use the Open Backup button in the profile manager.

Debug info: */
    fun errorsUnableOpenCollection(): String {
        return translate(15, 23, mapOf())
    }


    /** Secure connection failed. Please ensure Windows updates are installed, then try again. */
    fun errorsWindowsSslUpdates(): String {
        return translate(15, 24, mapOf())
    }


    /** The TTS service failed. Please ensure Windows updates are installed, try restarting your computer, or try a different voice. */
    fun errorsWindowsTtsRuntimeError(): String {
        return translate(15, 25, mapOf())
    }


    /** All Decks */
    fun exportingAllDecks(): String {
        return translate(16, 0, mapOf())
    }


    /** Anki 2.0 Deck */
    fun exportingAnki20Deck(): String {
        return translate(16, 1, mapOf())
    }


    /** Anki Collection Package */
    fun exportingAnkiCollectionPackage(): String {
        return translate(16, 2, mapOf())
    }


    /** Anki Deck Package */
    fun exportingAnkiDeckPackage(): String {
        return translate(16, 3, mapOf())
    }


    /** {$count} cards exported. */
    fun exportingCardExported(`count`: Int): String {
        return translate(16, 4, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Cards in Plain Text */
    fun exportingCardsInPlainText(): String {
        return translate(16, 5, mapOf())
    }


    /** collection */
    fun exportingCollection(): String {
        return translate(16, 6, mapOf())
    }


    /** Collection exported. */
    fun exportingCollectionExported(): String {
        return translate(16, 7, mapOf())
    }


    /** Please update to the latest Anki version, then import the .colpkg/.apkg file again. */
    fun exportingColpkgTooNew(): String {
        return translate(16, 8, mapOf())
    }


    /** Couldn't save file: {$val} */
    fun exportingCouldntSaveFile(`val`: TranslateArg): String {
        return translate(16, 9, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Export... */
    fun exportingExport(): String {
        return translate(16, 10, mapOf())
    }


    /** <b>Export format</b>: */
    fun exportingExportFormat(): String {
        return translate(16, 11, mapOf())
    }


    /** Exported {$count} media files */
    fun exportingExportedMediaFile(`count`: Int): String {
        return translate(16, 12, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Exporting file... */
    fun exportingExportingFile(): String {
        return translate(16, 13, mapOf())
    }


    /** <b>Include</b>: */
    fun exportingInclude(): String {
        return translate(16, 14, mapOf())
    }


    /** Include deck name */
    fun exportingIncludeDeck(): String {
        return translate(16, 15, mapOf())
    }


    /** Include deck presets */
    fun exportingIncludeDeckConfigs(): String {
        return translate(16, 16, mapOf())
    }


    /** Include unique identifier */
    fun exportingIncludeGuid(): String {
        return translate(16, 17, mapOf())
    }


    /** Include HTML and media references */
    fun exportingIncludeHtmlAndMediaReferences(): String {
        return translate(16, 18, mapOf())
    }


    /** Include media */
    fun exportingIncludeMedia(): String {
        return translate(16, 19, mapOf())
    }


    /** Include note type name */
    fun exportingIncludeNotetype(): String {
        return translate(16, 20, mapOf())
    }


    /** Include scheduling information */
    fun exportingIncludeSchedulingInformation(): String {
        return translate(16, 21, mapOf())
    }


    /** Include tags */
    fun exportingIncludeTags(): String {
        return translate(16, 22, mapOf())
    }


    /** {$count} notes exported. */
    fun exportingNoteExported(`count`: Int): String {
        return translate(16, 23, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Notes in Plain Text */
    fun exportingNotesInPlainText(): String {
        return translate(16, 24, mapOf())
    }


    /** Processed {$count} media files... */
    fun exportingProcessedMediaFiles(`count`: Int): String {
        return translate(16, 25, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Selected Notes */
    fun exportingSelectedNotes(): String {
        return translate(16, 26, mapOf())
    }


    /** Support older Anki versions (slower/larger files) */
    fun exportingSupportOlderAnkiVersions(): String {
        return translate(16, 27, mapOf())
    }


    /** Add Field */
    fun fieldsAddField(): String {
        return translate(17, 0, mapOf())
    }


    /** Collapse by default */
    fun fieldsCollapseByDefault(): String {
        return translate(17, 1, mapOf())
    }


    /** Delete field from {$val}? */
    fun fieldsDeleteFieldFrom(`val`: TranslateArg): String {
        return translate(17, 2, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Description */
    fun fieldsDescription(): String {
        return translate(17, 3, mapOf())
    }


    /** Text to show inside the field when it's empty */
    fun fieldsDescriptionPlaceholder(): String {
        return translate(17, 4, mapOf())
    }


    /** Editing Font */
    fun fieldsEditingFont(): String {
        return translate(17, 5, mapOf())
    }


    /** Exclude from unqualified searches (slower) */
    fun fieldsExcludeFromSearch(): String {
        return translate(17, 6, mapOf())
    }


    /** Field: */
    fun fieldsField(): String {
        return translate(17, 7, mapOf())
    }


    /** This is a required field, and can not be deleted. */
    fun fieldsFieldIsRequired(): String {
        return translate(17, 8, mapOf())
    }


    /** Field name: */
    fun fieldsFieldName(): String {
        return translate(17, 9, mapOf())
    }


    /** Fields for {$val} */
    fun fieldsFieldsFor(`val`: TranslateArg): String {
        return translate(17, 10, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Font: */
    fun fieldsFont(): String {
        return translate(17, 11, mapOf())
    }


    /** Use HTML editor by default */
    fun fieldsHtmlByDefault(): String {
        return translate(17, 12, mapOf())
    }


    /** The field name should not start with #, ^ or /. */
    fun fieldsNameFirstLetterNotValid(): String {
        return translate(17, 13, mapOf())
    }


    /** The field name should not contain :, ",  or . */
    fun fieldsNameInvalidLetter(): String {
        return translate(17, 14, mapOf())
    }


    /** New position (1...{$val}): */
    fun fieldsNewPosition1(`val`: TranslateArg): String {
        return translate(17, 15, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Notes require at least one field. */
    fun fieldsNotesRequireAtLeastOneField(): String {
        return translate(17, 16, mapOf())
    }


    /** Reverse text direction (RTL) */
    fun fieldsReverseTextDirectionRtl(): String {
        return translate(17, 17, mapOf())
    }


    /** Size: */
    fun fieldsSize(): String {
        return translate(17, 18, mapOf())
    }


    /** Sort by this field in the browser */
    fun fieldsSortByThisFieldInThe(): String {
        return translate(17, 19, mapOf())
    }


    /** That field name is already used. */
    fun fieldsThatFieldNameIsAlreadyUsed(): String {
        return translate(17, 20, mapOf())
    }


    /** {$changed} of {$total} notes updated */
    fun findreplaceNotesUpdated(`total`: Int, `changed`: Int): String {
        return translate(18, 0, mapOf("total" to asTranslateArg(`total`), "changed" to asTranslateArg(`changed`)))
    }


    /** For more information, see {$link} in the manual. */
    fun helpForMoreInfo(`link`: String): String {
        return translate(19, 0, mapOf("link" to asTranslateArg(`link`)))
    }


    /** Whoops! There doesn't seem to be an explanation for this setting yet.

You can help us complete this help page on {$link}. */
    fun helpNoExplanation(`link`: String): String {
        return translate(19, 1, mapOf("link" to asTranslateArg(`link`)))
    }


    /** OK */
    fun helpOk(): String {
        return translate(19, 2, mapOf())
    }


    /** Open {$name} in the manual */
    fun helpOpenManualChapter(`name`: String): String {
        return translate(19, 3, mapOf("name" to asTranslateArg(`name`)))
    }


    /** Aborted: {$val} */
    fun importingAborted(`val`: TranslateArg): String {
        return translate(20, 0, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Added */
    fun importingAdded(): String {
        return translate(20, 1, mapOf())
    }


    /** Added duplicate with first field: {$val} */
    fun importingAddedDuplicateWithFirstField(`val`: TranslateArg): String {
        return translate(20, 2, mapOf("val" to asTranslateArg(`val`)))
    }


    /** New note added */
    fun importingAddedNewNote(): String {
        return translate(20, 3, mapOf())
    }


    /** All supported formats {$val} */
    fun importingAllSupportedFormats(`val`: TranslateArg): String {
        return translate(20, 4, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Allow HTML in fields */
    fun importingAllowHtmlInFields(): String {
        return translate(20, 5, mapOf())
    }


    /** Enable this if the file contains HTML formatting. E.g. if the file contains the string
'&lt;br&gt;', it will appear as a line break on your card. On the other hand, with this
option disabled, the literal characters '&lt;br&gt;' will be rendered. */
    fun importingAllowHtmlInFieldsHelp(): String {
        return translate(20, 6, mapOf())
    }


    /** Import any learning progress */
    fun importingAlsoImportProgress(): String {
        return translate(20, 7, mapOf())
    }


    /** .anki files are from a very old version of Anki. You can import them with add-on 175027074 or with Anki 2.0, available on the Anki website. */
    fun importingAnkiFilesAreFromAVery(): String {
        return translate(20, 8, mapOf())
    }


    /** .anki2 files are not directly importable - please import the .apkg or .zip file you have received instead. */
    fun importingAnki2FilesAreNotDirectlyImportable(): String {
        return translate(20, 9, mapOf())
    }


    /** Appeared twice in file: {$val} */
    fun importingAppearedTwiceInFile(`val`: TranslateArg): String {
        return translate(20, 10, mapOf("val" to asTranslateArg(`val`)))
    }


    /** By default, Anki will detect the character between fields, such as a tab, comma, and so on. If Anki is detecting the character incorrectly, you can enter it here. Use \t to represent tab. */
    fun importingByDefaultAnkiWillDetectThe(): String {
        return translate(20, 11, mapOf())
    }


    /** Cloze note types cannot be merged with regular note types.
You may still import the file with '' disabled. */
    fun importingCannotMergeNotetypesOfDifferentKinds(): String {
        return translate(20, 12, mapOf())
    }


    /** {$count} cards added. */
    fun importingCardsAdded(`count`: Int): String {
        return translate(20, 13, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Change */
    fun importingChange(): String {
        return translate(20, 14, mapOf())
    }


    /** Colon */
    fun importingColon(): String {
        return translate(20, 15, mapOf())
    }


    /** Comma */
    fun importingComma(): String {
        return translate(20, 16, mapOf())
    }


    /** {$count} notes were not imported, because their note type has changed. */
    fun importingConflictingNotesSkipped(`count`: Int): String {
        return translate(20, 17, mapOf("count" to asTranslateArg(`count`)))
    }


    /** {$count} notes were not imported, because their note type has changed, and '' was not enabled. */
    fun importingConflictingNotesSkipped2(`count`: Int): String {
        return translate(20, 18, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Imported cards will be placed in this deck. */
    fun importingDeckHelp(): String {
        return translate(20, 19, mapOf())
    }


    /** Details */
    fun importingDetails(): String {
        return translate(20, 20, mapOf())
    }


    /** Duplicate */
    fun importingDuplicate(): String {
        return translate(20, 21, mapOf())
    }


    /** Duplicate note added */
    fun importingDuplicateNoteAdded(): String {
        return translate(20, 22, mapOf())
    }


    /** Empty first field: {$val} */
    fun importingEmptyFirstField(`val`: TranslateArg): String {
        return translate(20, 23, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Note skipped, as an up-to-date copy is already in your collection */
    fun importingExistingNoteSkipped(): String {
        return translate(20, 24, mapOf())
    }


    /** Existing notes */
    fun importingExistingNotes(): String {
        return translate(20, 25, mapOf())
    }


    /** What to do if an imported note matches an existing one.

- ``: Update the existing note.
- ``: Do nothing.
- ``: Create a new note. */
    fun importingExistingNotesHelp(): String {
        return translate(20, 26, mapOf())
    }


    /** {$count} notes already present in your collection. */
    fun importingExistingNotesSkipped(`count`: Int): String {
        return translate(20, 27, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Extracting data... */
    fun importingExtracting(): String {
        return translate(20, 28, mapOf())
    }


    /** Import failed. Debugging info: */
    fun importingFailedDebugInfo(): String {
        return translate(20, 29, mapOf())
    }


    /** Failed to import media file: {$debugInfo} */
    fun importingFailedToImportMediaFile(`debugInfo`: String): String {
        return translate(20, 30, mapOf("debugInfo" to asTranslateArg(`debugInfo`)))
    }


    /** Field mapping */
    fun importingFieldMapping(): String {
        return translate(20, 31, mapOf())
    }


    /** Field <b>{$val}</b> of file is: */
    fun importingFieldOfFileIs(`val`: TranslateArg): String {
        return translate(20, 32, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Field separator */
    fun importingFieldSeparator(): String {
        return translate(20, 33, mapOf())
    }


    /** Field separator (guessed) */
    fun importingFieldSeparatorGuessed(): String {
        return translate(20, 34, mapOf())
    }


    /** The character separating fields in the text file. You can use the preview to check
if the fields are separated correctly.

Please note that if this character appears in any field itself, the field has to be
quoted accordingly to the CSV standard. Spreadsheet programs like LibreOffice will
do this automatically.

It cannot be changed if the text file forces use of a specific separator via a file header.
If a file header is not present, Anki will try to guess what the separator is. */
    fun importingFieldSeparatorHelp(): String {
        return translate(20, 35, mapOf())
    }


    /** Fields separated by: {$val} */
    fun importingFieldsSeparatedBy(`val`: TranslateArg): String {
        return translate(20, 36, mapOf("val" to asTranslateArg(`val`)))
    }


    /** File */
    fun importingFile(): String {
        return translate(20, 37, mapOf())
    }


    /** The file you selected is empty. */
    fun importingFileEmpty(): String {
        return translate(20, 38, mapOf())
    }


    /** File must contain at least one column that can be mapped to a note field. */
    fun importingFileMustContainFieldColumn(): String {
        return translate(20, 39, mapOf())
    }


    /** File version unknown, trying import anyway. */
    fun importingFileVersionUnknownTryingImportAnyway(): String {
        return translate(20, 40, mapOf())
    }


    /** First field matched: {$val} */
    fun importingFirstFieldMatched(`val`: TranslateArg): String {
        return translate(20, 41, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Gathering data... */
    fun importingGathering(): String {
        return translate(20, 42, mapOf())
    }


    /** Identical */
    fun importingIdentical(): String {
        return translate(20, 43, mapOf())
    }


    /** Ignore field */
    fun importingIgnoreField(): String {
        return translate(20, 44, mapOf())
    }


    /** Ignore lines where first field matches existing note */
    fun importingIgnoreLinesWhereFirstFieldMatches(): String {
        return translate(20, 45, mapOf())
    }


    /** <ignored> */
    fun importingIgnored(): String {
        return translate(20, 46, mapOf())
    }


    /** Import even if existing note has same first field */
    fun importingImportEvenIfExistingNoteHas(): String {
        return translate(20, 47, mapOf())
    }


    /** Import Log */
    fun importingImportLog(): String {
        return translate(20, 48, mapOf())
    }


    /** Import options */
    fun importingImportOptions(): String {
        return translate(20, 49, mapOf())
    }


    /** Importing collection... */
    fun importingImportingCollection(): String {
        return translate(20, 50, mapOf())
    }


    /** Importing complete. */
    fun importingImportingComplete(): String {
        return translate(20, 51, mapOf())
    }


    /** Importing file... */
    fun importingImportingFile(): String {
        return translate(20, 52, mapOf())
    }


    /** Include reviews */
    fun importingIncludeReviews(): String {
        return translate(20, 53, mapOf())
    }


    /** If enabled, any previous reviews that the deck sharer included will also be imported.
Otherwise, all cards will be imported as new cards, and any "leech" or "marked"
tags will be removed. */
    fun importingIncludeReviewsHelp(): String {
        return translate(20, 54, mapOf())
    }


    /** Invalid file. Please restore from backup. */
    fun importingInvalidFilePleaseRestoreFromBackup(): String {
        return translate(20, 55, mapOf())
    }


    /** Map to {$val} */
    fun importingMapTo(`val`: TranslateArg): String {
        return translate(20, 56, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Map to Tags */
    fun importingMapToTags(): String {
        return translate(20, 57, mapOf())
    }


    /** mapped to <b>{$val}</b> */
    fun importingMappedTo(`val`: TranslateArg): String {
        return translate(20, 58, mapOf("val" to asTranslateArg(`val`)))
    }


    /** mapped to <b>Tags</b> */
    fun importingMappedToTags(): String {
        return translate(20, 59, mapOf())
    }


    /** Match scope */
    fun importingMatchScope(): String {
        return translate(20, 60, mapOf())
    }


    /** Only existing notes with the same note type will be checked for duplicates. This can
additionally be restricted to notes with cards in the same deck. */
    fun importingMatchScopeHelp(): String {
        return translate(20, 61, mapOf())
    }


    /** Merge note types */
    fun importingMergeNotetypes(): String {
        return translate(20, 62, mapOf())
    }


    /** If checked, and you or the deck author altered the schema of a note type, Anki will
merge the two versions instead of keeping both.

Altering a note type's schema means adding, removing, or reordering fields or templates,
or changing the sort field.
As a counterexample, changing the front side of an existing template does *not* constitute
a schema change.

Warning: This will require a one-way sync, and may mark existing notes as modified. */
    fun importingMergeNotetypesHelp(): String {
        return translate(20, 63, mapOf())
    }


    /** Mnemosyne 2.0 Deck (*.db) */
    fun importingMnemosyne20DeckDb(): String {
        return translate(20, 64, mapOf())
    }


    /** Multi-character separators are not supported. Please enter one character only. */
    fun importingMulticharacterSeparatorsAreNotSupportedPlease(): String {
        return translate(20, 65, mapOf())
    }


    /** A new deck will be created: {$name} */
    fun importingNewDeckWillBeCreated(`name`: String): String {
        return translate(20, 66, mapOf("name" to asTranslateArg(`name`)))
    }


    /** No notes found in file. */
    fun importingNoNotesInFile(): String {
        return translate(20, 67, mapOf())
    }


    /** {$count} notes added */
    fun importingNoteAdded(`count`: Int): String {
        return translate(20, 68, mapOf("count" to asTranslateArg(`count`)))
    }


    /** {$count} notes imported. */
    fun importingNoteImported(`count`: Int): String {
        return translate(20, 69, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Note skipped, as its first field is empty */
    fun importingNoteSkippedDueToEmptyFirstField(): String {
        return translate(20, 70, mapOf())
    }


    /** Note skipped, as its deck was missing */
    fun importingNoteSkippedDueToMissingDeck(): String {
        return translate(20, 71, mapOf())
    }


    /** Note skipped, as its notetype was missing */
    fun importingNoteSkippedDueToMissingNotetype(): String {
        return translate(20, 72, mapOf())
    }


    /** Note not updated, as note type has been modified since you first imported the note */
    fun importingNoteSkippedUpdateDueToNotetype(): String {
        return translate(20, 73, mapOf())
    }


    /** Note not updated, as note type has been modified since you first imported the note, and '' was not enabled */
    fun importingNoteSkippedUpdateDueToNotetype2(): String {
        return translate(20, 74, mapOf())
    }


    /** {$count} notes unchanged */
    fun importingNoteUnchanged(`count`: Int): String {
        return translate(20, 75, mapOf("count" to asTranslateArg(`count`)))
    }


    /** {$count} notes updated */
    fun importingNoteUpdated(`count`: Int): String {
        return translate(20, 76, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Note updated, as file had newer version */
    fun importingNoteUpdatedAsFileHadNewer(): String {
        return translate(20, 77, mapOf())
    }


    /** {$count} new notes imported. */
    fun importingNotesAdded(`count`: Int): String {
        return translate(20, 78, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Notes added from file: {$val} */
    fun importingNotesAddedFromFile(`val`: TranslateArg): String {
        return translate(20, 79, mapOf("val" to asTranslateArg(`val`)))
    }


    /** {$count} notes could not be imported. */
    fun importingNotesFailed(`count`: Int): String {
        return translate(20, 80, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Notes found in file: {$val} */
    fun importingNotesFoundInFile(`val`: TranslateArg): String {
        return translate(20, 81, mapOf("val" to asTranslateArg(`val`)))
    }


    /** {$notes} notes found in file. Of those: */
    fun importingNotesFoundInFile2(`notes`: Int): String {
        return translate(20, 82, mapOf("notes" to asTranslateArg(`notes`)))
    }


    /** Notes skipped, as up-to-date copies are already in your collection: {$val} */
    fun importingNotesSkippedAsTheyreAlreadyIn(`val`: TranslateArg): String {
        return translate(20, 83, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Notes not updated, as note type has been modified since you first imported the notes: {$val} */
    fun importingNotesSkippedUpdateDueToNotetype(`val`: TranslateArg): String {
        return translate(20, 84, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Notes that could not be imported as note type has changed: {$val} */
    fun importingNotesThatCouldNotBeImported(`val`: TranslateArg): String {
        return translate(20, 85, mapOf("val" to asTranslateArg(`val`)))
    }


    /** {$count} notes were used to update existing ones. */
    fun importingNotesUpdated(`count`: Int): String {
        return translate(20, 86, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Notes updated, as file had newer version: {$val} */
    fun importingNotesUpdatedAsFileHadNewer(`val`: TranslateArg): String {
        return translate(20, 87, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Note type and deck */
    fun importingNotetypeAndDeck(): String {
        return translate(20, 88, mapOf())
    }


    /** Newly-imported notes will have this note type, and only existing notes with this
note type will be updated.

You can choose which fields in the file correspond to which note type fields with the
mapping tool. */
    fun importingNotetypeHelp(): String {
        return translate(20, 89, mapOf())
    }


    /** Overview */
    fun importingOverview(): String {
        return translate(20, 90, mapOf())
    }


    /** Packaged Anki Deck/Collection (*.apkg *.colpkg *.zip) */
    fun importingPackagedAnkiDeckcollectionApkgColpkgZip(): String {
        return translate(20, 91, mapOf())
    }


    /** Pauker 1.8 Lesson (*.pau.gz) */
    fun importingPauker18LessonPaugz(): String {
        return translate(20, 92, mapOf())
    }


    /** Pipe */
    fun importingPipe(): String {
        return translate(20, 93, mapOf())
    }


    /** Preserve */
    fun importingPreserve(): String {
        return translate(20, 94, mapOf())
    }


    /** Only the first {$count} columns are shown. If this doesn't seem right, try changing the field separator. */
    fun importingPreviewTruncated(`count`: Int): String {
        return translate(20, 95, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Processed {$count} cards... */
    fun importingProcessedCards(`count`: Int): String {
        return translate(20, 96, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Imported {$count} media files */
    fun importingProcessedMediaFile(`count`: Int): String {
        return translate(20, 97, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Processed {$count} notes... */
    fun importingProcessedNotes(`count`: Int): String {
        return translate(20, 98, mapOf("count" to asTranslateArg(`count`)))
    }


    /** '{$row}' had {$found} fields, expected {$expected} */
    fun importingRowsHadNum1dFieldsExpectedNum2d(`row`: String, `found`: TranslateArg, `expected`: TranslateArg): String {
        return translate(20, 99, mapOf("row" to asTranslateArg(`row`), "found" to asTranslateArg(`found`), "expected" to asTranslateArg(`expected`)))
    }


    /** Selected file was not in UTF-8 format. Please see the importing section of the manual. */
    fun importingSelectedFileWasNotInUtf8(): String {
        return translate(20, 100, mapOf())
    }


    /** Semicolon */
    fun importingSemicolon(): String {
        return translate(20, 101, mapOf())
    }


    /** Show */
    fun importingShow(): String {
        return translate(20, 102, mapOf())
    }


    /** Skipped */
    fun importingSkipped(): String {
        return translate(20, 103, mapOf())
    }


    /** Status */
    fun importingStatus(): String {
        return translate(20, 104, mapOf())
    }


    /** Supermemo XML export (*.xml) */
    fun importingSupermemoXmlExportXml(): String {
        return translate(20, 105, mapOf())
    }


    /** Tab */
    fun importingTab(): String {
        return translate(20, 106, mapOf())
    }


    /** Tag all notes */
    fun importingTagAllNotes(): String {
        return translate(20, 107, mapOf())
    }


    /** These tags will be added to both newly-imported and updated notes. */
    fun importingTagAllNotesHelp(): String {
        return translate(20, 108, mapOf())
    }


    /** Tag modified notes: */
    fun importingTagModifiedNotes(): String {
        return translate(20, 109, mapOf())
    }


    /** Tag updated notes */
    fun importingTagUpdatedNotes(): String {
        return translate(20, 110, mapOf())
    }


    /** These tags will be added to any updated notes. */
    fun importingTagUpdatedNotesHelp(): String {
        return translate(20, 111, mapOf())
    }


    /** Text separated by tabs or semicolons (*) */
    fun importingTextSeparatedByTabsOrSemicolons(): String {
        return translate(20, 112, mapOf())
    }


    /** The first field of the note type must be mapped. */
    fun importingTheFirstFieldOfTheNote(): String {
        return translate(20, 113, mapOf())
    }


    /** The provided file is not a valid .apkg file. */
    fun importingTheProvidedFileIsNotA(): String {
        return translate(20, 114, mapOf())
    }


    /** This file does not appear to be a valid .apkg file. If you're getting this error from a file downloaded from AnkiWeb, chances are that your download failed. Please try again, and if the problem persists, please try again with a different browser. */
    fun importingThisFileDoesNotAppearTo(): String {
        return translate(20, 115, mapOf())
    }


    /** This will delete your existing collection and replace it with the data in the file you're importing. Are you sure? */
    fun importingThisWillDeleteYourExistingCollection(): String {
        return translate(20, 116, mapOf())
    }


    /** Unable to import {$filename}: file type not supported */
    fun importingUnableToImportFilename(`filename`: String): String {
        return translate(20, 117, mapOf("filename" to asTranslateArg(`filename`)))
    }


    /** Unable to import from a read-only file. */
    fun importingUnableToImportFromAReadonly(): String {
        return translate(20, 118, mapOf())
    }


    /** Unknown file format. */
    fun importingUnknownFileFormat(): String {
        return translate(20, 119, mapOf())
    }


    /** Update */
    fun importingUpdate(): String {
        return translate(20, 120, mapOf())
    }


    /** Always */
    fun importingUpdateAlways(): String {
        return translate(20, 121, mapOf())
    }


    /** Update existing notes when first field matches */
    fun importingUpdateExistingNotesWhenFirstField(): String {
        return translate(20, 122, mapOf())
    }


    /** If newer */
    fun importingUpdateIfNewer(): String {
        return translate(20, 123, mapOf())
    }


    /** Never */
    fun importingUpdateNever(): String {
        return translate(20, 124, mapOf())
    }


    /** Update notes */
    fun importingUpdateNotes(): String {
        return translate(20, 125, mapOf())
    }


    /** When to update an existing note in your collection. By default, this is only done
if the matching imported note was more recently modified. */
    fun importingUpdateNotesHelp(): String {
        return translate(20, 126, mapOf())
    }


    /** Update note types */
    fun importingUpdateNotetypes(): String {
        return translate(20, 127, mapOf())
    }


    /** When to update an existing note type in your collection. By default, this is only done
if the matching imported note type was more recently modified. Changes to template text
and styling can always be imported, but for schema changes (e.g. the number or order of
fields has changed), the '' option will also need to be enabled. */
    fun importingUpdateNotetypesHelp(): String {
        return translate(20, 128, mapOf())
    }


    /** Updated */
    fun importingUpdated(): String {
        return translate(20, 129, mapOf())
    }


    /** Updates */
    fun importingUpdates(): String {
        return translate(20, 130, mapOf())
    }


    /** Import any deck presets */
    fun importingWithDeckConfigs(): String {
        return translate(20, 131, mapOf())
    }


    /** If enabled, any deck options that the deck sharer included will also be imported.
Otherwise, all decks will be assigned the default preset. */
    fun importingWithDeckConfigsHelp(): String {
        return translate(20, 132, mapOf())
    }


    /** Ctrl */
    fun keyboardCtrl(): String {
        return translate(21, 0, mapOf())
    }


    /** Shift */
    fun keyboardShift(): String {
        return translate(21, 1, mapOf())
    }


    /** Error executing {$val}. */
    fun mediaErrorExecuting(`val`: TranslateArg): String {
        return translate(22, 0, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Error running {$val} */
    fun mediaErrorRunning(`val`: TranslateArg): String {
        return translate(22, 1, mapOf("val" to asTranslateArg(`val`)))
    }


    /** For security reasons, '{$val}' is not allowed on cards. You can still use it by placing the command in a different package, and importing that package in the LaTeX header instead. */
    fun mediaForSecurityReasonsIsNot(`val`: TranslateArg): String {
        return translate(22, 2, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Generated file: {$val} */
    fun mediaGeneratedFile(`val`: TranslateArg): String {
        return translate(22, 3, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Have you installed latex and dvipng/dvisvgm? */
    fun mediaHaveYouInstalledLatexAndDvipngdvisvgm(): String {
        return translate(22, 4, mapOf())
    }


    /** Recording...<br>Time: {$secs} */
    fun mediaRecordingtime(`secs`: String): String {
        return translate(22, 5, mapOf("secs" to asTranslateArg(`secs`)))
    }


    /** Sound and video on cards will not function until mpv or mplayer is installed. */
    fun mediaSoundAndVideoOnCardsWill(): String {
        return translate(22, 6, mapOf())
    }


    /** Tag Missing */
    fun mediaCheckAddTag(): String {
        return translate(23, 0, mapOf())
    }


    /** All LaTeX rendered. */
    fun mediaCheckAllLatexRendered(): String {
        return translate(23, 1, mapOf())
    }


    /** Check Media */
    fun mediaCheckCheckMediaAction(): String {
        return translate(23, 2, mapOf())
    }


    /** Checked {$count}... */
    fun mediaCheckChecked(`count`: Int): String {
        return translate(23, 3, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Delete Unused */
    fun mediaCheckDeleteUnused(): String {
        return translate(23, 4, mapOf())
    }


    /** {$count} files moved to the trash. */
    fun mediaCheckDeleteUnusedComplete(`count`: Int): String {
        return translate(23, 5, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Delete unused media? */
    fun mediaCheckDeleteUnusedConfirm(): String {
        return translate(23, 6, mapOf())
    }


    /** Empty Trash */
    fun mediaCheckEmptyTrash(): String {
        return translate(23, 7, mapOf())
    }


    /** Extracted images: {$count} */
    fun mediaCheckExtractedCount(`count`: Int): String {
        return translate(23, 8, mapOf("count" to asTranslateArg(`count`)))
    }


    /** {$count} files remaining. */
    fun mediaCheckFilesRemaining(`count`: Int): String {
        return translate(23, 9, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Missing files: {$count} */
    fun mediaCheckMissingCount(`count`: Int): String {
        return translate(23, 10, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Missing: {$filename} */
    fun mediaCheckMissingFile(`filename`: String): String {
        return translate(23, 11, mapOf("filename" to asTranslateArg(`filename`)))
    }


    /** The following files are referenced by cards, but were not found in the media folder: */
    fun mediaCheckMissingHeader(): String {
        return translate(23, 12, mapOf())
    }


    /** missing-media */
    fun mediaCheckMissingMediaTag(): String {
        return translate(23, 13, mapOf())
    }


    /** {$notetype}: {$card_type} ({$side}) */
    fun mediaCheckNotetypeTemplate(`notetype`: String, `cardType`: String, `side`: String): String {
        return translate(23, 14, mapOf("notetype" to asTranslateArg(`notetype`), "card_type" to asTranslateArg(`cardType`), "side" to asTranslateArg(`side`)))
    }


    /** Over 100MB: {$count} */
    fun mediaCheckOversizeCount(`count`: Int): String {
        return translate(23, 15, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Over 100MB: {$filename} */
    fun mediaCheckOversizeFile(`filename`: String): String {
        return translate(23, 16, mapOf("filename" to asTranslateArg(`filename`)))
    }


    /** Files over 100MB can not be synced with AnkiWeb. */
    fun mediaCheckOversizeHeader(): String {
        return translate(23, 17, mapOf())
    }


    /** Renamed files: {$count} */
    fun mediaCheckRenamedCount(`count`: Int): String {
        return translate(23, 18, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Renamed: {$old} -> {$new} */
    fun mediaCheckRenamedFile(`old`: String, `new`: String): String {
        return translate(23, 19, mapOf("old" to asTranslateArg(`old`), "new" to asTranslateArg(`new`)))
    }


    /** Some files have been renamed for compatibility: */
    fun mediaCheckRenamedHeader(): String {
        return translate(23, 20, mapOf())
    }


    /** Render LaTeX */
    fun mediaCheckRenderLatex(): String {
        return translate(23, 21, mapOf())
    }


    /** Restore Deleted */
    fun mediaCheckRestoreTrash(): String {
        return translate(23, 22, mapOf())
    }


    /** Subfolders: {$count} */
    fun mediaCheckSubfolderCount(`count`: Int): String {
        return translate(23, 23, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Folder: {$filename} */
    fun mediaCheckSubfolderFile(`filename`: String): String {
        return translate(23, 24, mapOf("filename" to asTranslateArg(`filename`)))
    }


    /** Folders inside the media folder are not supported. */
    fun mediaCheckSubfolderHeader(): String {
        return translate(23, 25, mapOf())
    }


    /** Anki can not detect used files when you use  references in media/LaTeX tags. The media/LaTeX tags should be placed on individual notes instead.

Referencing templates: */
    fun mediaCheckTemplateReferencesFieldHeader(): String {
        return translate(23, 26, mapOf())
    }


    /** Trash folder: {$count} files, {$megs}MB */
    fun mediaCheckTrashCount(`count`: Int, `megs`: TranslateArg): String {
        return translate(23, 27, mapOf("count" to asTranslateArg(`count`), "megs" to asTranslateArg(`megs`)))
    }


    /** The trash folder is now empty. */
    fun mediaCheckTrashEmptied(): String {
        return translate(23, 28, mapOf())
    }


    /** Restored deleted files to the media folder. */
    fun mediaCheckTrashRestored(): String {
        return translate(23, 29, mapOf())
    }


    /** Unused files: {$count} */
    fun mediaCheckUnusedCount(`count`: Int): String {
        return translate(23, 30, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Unused: {$filename} */
    fun mediaCheckUnusedFile(`filename`: String): String {
        return translate(23, 31, mapOf("filename" to asTranslateArg(`filename`)))
    }


    /** The following files were found in the media folder, but do not appear to be used on any cards: */
    fun mediaCheckUnusedHeader(): String {
        return translate(23, 32, mapOf())
    }


    /** Check Media */
    fun mediaCheckWindowTitle(): String {
        return translate(23, 33, mapOf())
    }


    /** Error details: {$details} */
    fun networkDetails(`details`: String): String {
        return translate(24, 0, mapOf("details" to asTranslateArg(`details`)))
    }


    /** Please check your internet connection. */
    fun networkOffline(): String {
        return translate(24, 1, mapOf())
    }


    /** A network error occurred. */
    fun networkOther(): String {
        return translate(24, 2, mapOf())
    }


    /** Your proxy requires authentication. */
    fun networkProxyAuth(): String {
        return translate(24, 3, mapOf())
    }


    /** Connection timed out. Please try again. If you see frequent timeouts, please try a different network connection. */
    fun networkTimeout(): String {
        return translate(24, 4, mapOf())
    }


    /** No image to show. */
    fun notetypeErrorNoImageToShow(): String {
        return translate(25, 0, mapOf())
    }


    /** Add: {$val} */
    fun notetypesAdd(`val`: TranslateArg): String {
        return translate(25, 1, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Add Note Type */
    fun notetypesAddNoteType(): String {
        return translate(25, 2, mapOf())
    }


    /** Add Reverse */
    fun notetypesAddReverseField(): String {
        return translate(25, 3, mapOf())
    }


    /** Back Extra */
    fun notetypesBackExtraField(): String {
        return translate(25, 4, mapOf())
    }


    /** Back */
    fun notetypesBackField(): String {
        return translate(25, 5, mapOf())
    }


    /** Basic */
    fun notetypesBasicName(): String {
        return translate(25, 6, mapOf())
    }


    /** Basic (optional reversed card) */
    fun notetypesBasicOptionalReversedName(): String {
        return translate(25, 7, mapOf())
    }


    /** Basic (and reversed card) */
    fun notetypesBasicReversedName(): String {
        return translate(25, 8, mapOf())
    }


    /** Basic (type in the answer) */
    fun notetypesBasicTypeAnswerName(): String {
        return translate(25, 9, mapOf())
    }


    /** Card 1 */
    fun notetypesCard1Name(): String {
        return translate(25, 10, mapOf())
    }


    /** Card 2 */
    fun notetypesCard2Name(): String {
        return translate(25, 11, mapOf())
    }


    /** Cards */
    fun notetypesCards(): String {
        return translate(25, 12, mapOf())
    }


    /** Change Note Type (Ctrl+N) */
    fun notetypesChangeNoteTypeCtrlandn(): String {
        return translate(25, 13, mapOf())
    }


    /** Choose Note Type */
    fun notetypesChooseNoteType(): String {
        return translate(25, 14, mapOf())
    }


    /** Clone: {$val} */
    fun notetypesClone(`val`: TranslateArg): String {
        return translate(25, 15, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Cloze */
    fun notetypesClozeName(): String {
        return translate(25, 16, mapOf())
    }


    /** Comments */
    fun notetypesCommentsField(): String {
        return translate(25, 17, mapOf())
    }


    /** {$val} copy */
    fun notetypesCopy(`val`: TranslateArg): String {
        return translate(25, 18, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Create scalable images with dvisvgm */
    fun notetypesCreateScalableImagesWithDvisvgm(): String {
        return translate(25, 19, mapOf())
    }


    /** Delete this note type and all its cards? */
    fun notetypesDeleteThisNoteTypeAndAll(): String {
        return translate(25, 20, mapOf())
    }


    /** Delete this unused note type? */
    fun notetypesDeleteThisUnusedNoteType(): String {
        return translate(25, 21, mapOf())
    }


    /** An error occurred when generating an image occlusion note */
    fun notetypesErrorGeneratingCloze(): String {
        return translate(25, 22, mapOf())
    }


    /** An error occurred while fetching an image occlusion note */
    fun notetypesErrorGettingImagecloze(): String {
        return translate(25, 23, mapOf())
    }


    /** Error loading image occlusion. Is your Anki version up to date? */
    fun notetypesErrorLoadingImageOcclusion(): String {
        return translate(25, 24, mapOf())
    }


    /** Fields */
    fun notetypesFields(): String {
        return translate(25, 25, mapOf())
    }


    /** Footer */
    fun notetypesFooter(): String {
        return translate(25, 26, mapOf())
    }


    /** Front */
    fun notetypesFrontField(): String {
        return translate(25, 27, mapOf())
    }


    /** Header */
    fun notetypesHeader(): String {
        return translate(25, 28, mapOf())
    }


    /** Hide All, Guess One */
    fun notetypesHideAllGuessOne(): String {
        return translate(25, 29, mapOf())
    }


    /** Hide One, Guess One */
    fun notetypesHideOneGuessOne(): String {
        return translate(25, 30, mapOf())
    }


    /** Image */
    fun notetypesImage(): String {
        return translate(25, 31, mapOf())
    }


    /** Image Occlusion */
    fun notetypesImageOcclusionName(): String {
        return translate(25, 32, mapOf())
    }


    /** Paste Image from Clipboard */
    fun notetypesIoPasteImageFromClipboard(): String {
        return translate(25, 33, mapOf())
    }


    /** Select Image */
    fun notetypesIoSelectImage(): String {
        return translate(25, 34, mapOf())
    }


    /** You must make at least one occlusion. */
    fun notetypesNoOcclusionCreated(): String {
        return translate(25, 35, mapOf())
    }


    /** Unable to add. Either you have not added any occlusions, or the first field is empty. */
    fun notetypesNoOcclusionCreated2(): String {
        return translate(25, 36, mapOf())
    }


    /** Note Types */
    fun notetypesNoteTypes(): String {
        return translate(25, 37, mapOf())
    }


    /** Note Type */
    fun notetypesNotetype(): String {
        return translate(25, 38, mapOf())
    }


    /** Occlusion */
    fun notetypesOcclusion(): String {
        return translate(25, 39, mapOf())
    }


    /** Mask */
    fun notetypesOcclusionMask(): String {
        return translate(25, 40, mapOf())
    }


    /** Note */
    fun notetypesOcclusionNote(): String {
        return translate(25, 41, mapOf())
    }


    /** Options */
    fun notetypesOptions(): String {
        return translate(25, 42, mapOf())
    }


    /** Please add another note type first. */
    fun notetypesPleaseAddAnotherNoteTypeFirst(): String {
        return translate(25, 43, mapOf())
    }


    /** Text */
    fun notetypesTextField(): String {
        return translate(25, 44, mapOf())
    }


    /** Toggle Masks */
    fun notetypesToggleMasks(): String {
        return translate(25, 45, mapOf())
    }


    /** Type */
    fun notetypesType(): String {
        return translate(25, 46, mapOf())
    }


    /** AnkiWeb Account */
    fun preferencesAccount(): String {
        return translate(26, 0, mapOf())
    }


    /** Always */
    fun preferencesAlways(): String {
        return translate(26, 1, mapOf())
    }


    /** AnkiHub provides collaborative deck editing and additional study tools. A paid subscription is required to access certain features. */
    fun preferencesAnkihubIntro(): String {
        return translate(26, 2, mapOf())
    }


    /** Not currently logged in to AnkiHub. */
    fun preferencesAnkihubNotLoggedIn(): String {
        return translate(26, 3, mapOf())
    }


    /** AnkiWeb is a free service that lets you keep your flashcard data in sync across your devices, and provides a way to recover the data if your device breaks or is lost. */
    fun preferencesAnkiwebIntro(): String {
        return translate(26, 4, mapOf())
    }


    /** Answer keys */
    fun preferencesAnswerKeys(): String {
        return translate(26, 5, mapOf())
    }


    /** Appearance */
    fun preferencesAppearance(): String {
        return translate(26, 6, mapOf())
    }


    /** Automatically sync on profile open/close */
    fun preferencesAutomaticallySyncOnProfileOpenclose(): String {
        return translate(26, 7, mapOf())
    }


    /** Anki periodically backs up your collection. After backups are more than 2 days old,
Anki will start removing some of them to free up disk space. */
    fun preferencesBackupExplanation(): String {
        return translate(26, 8, mapOf())
    }


    /** Backups */
    fun preferencesBackups(): String {
        return translate(26, 9, mapOf())
    }


    /** Basic */
    fun preferencesBasic(): String {
        return translate(26, 10, mapOf())
    }


    /** Browsing */
    fun preferencesBrowsing(): String {
        return translate(26, 11, mapOf())
    }


    /** Change deck depending on note type */
    fun preferencesChangeDeckDependingOnNoteType(): String {
        return translate(26, 12, mapOf())
    }


    /** Changes will take effect when you restart Anki. */
    fun preferencesChangesWillTakeEffectWhenYou(): String {
        return translate(26, 13, mapOf())
    }


    /** Check for add-on updates */
    fun preferencesCheckForAddonUpdates(): String {
        return translate(26, 14, mapOf())
    }


    /** Check for program updates */
    fun preferencesCheckForUpdates(): String {
        return translate(26, 15, mapOf())
    }


    /** Self-hosted sync server */
    fun preferencesCustomSyncUrl(): String {
        return translate(26, 16, mapOf())
    }


    /** For advanced users - please see the manual */
    fun preferencesCustomSyncUrlDisclaimer(): String {
        return translate(26, 17, mapOf())
    }


    /** Daily backups to keep: */
    fun preferencesDailyBackups(): String {
        return translate(26, 18, mapOf())
    }


    /** Default deck */
    fun preferencesDefaultDeck(): String {
        return translate(26, 19, mapOf())
    }


    /** Default search text */
    fun preferencesDefaultSearchText(): String {
        return translate(26, 20, mapOf())
    }


    /** e.g. "deck:current" */
    fun preferencesDefaultSearchTextExample(): String {
        return translate(26, 21, mapOf())
    }


    /** Distractions */
    fun preferencesDistractions(): String {
        return translate(26, 22, mapOf())
    }


    /** Editing */
    fun preferencesEditing(): String {
        return translate(26, 23, mapOf())
    }


    /** Experiments */
    fun preferencesExperimentalFeaturesTab(): String {
        return translate(26, 24, mapOf())
    }


    /** Full screen only */
    fun preferencesFullScreenOnly(): String {
        return translate(26, 25, mapOf())
    }


    /** General */
    fun preferencesGeneral(): String {
        return translate(26, 26, mapOf())
    }


    /** Generate LaTeX images (security risk) */
    fun preferencesGenerateLatexImagesAutomatically(): String {
        return translate(26, 27, mapOf())
    }


    /** Hide bottom bar during review */
    fun preferencesHideBottomBarDuringReview(): String {
        return translate(26, 28, mapOf())
    }


    /** Hide top bar during review */
    fun preferencesHideTopBarDuringReview(): String {
        return translate(26, 29, mapOf())
    }


    /** hours past midnight */
    fun preferencesHoursPastMidnight(): String {
        return translate(26, 30, mapOf())
    }


    /** Ignore accents in search (slower) */
    fun preferencesIgnoreAccentsInSearch(): String {
        return translate(26, 31, mapOf())
    }


    /** Import/Export */
    fun preferencesImportExport(): String {
        return translate(26, 32, mapOf())
    }


    /** Interrupt current audio when answering */
    fun preferencesInterruptCurrentAudioWhenAnswering(): String {
        return translate(26, 33, mapOf())
    }


    /** Language */
    fun preferencesLanguage(): String {
        return translate(26, 34, mapOf())
    }


    /** LaTeX image generation is disabled in the preferences. */
    fun preferencesLatexGenerationDisabled(): String {
        return translate(26, 35, mapOf())
    }


    /** Learn ahead limit */
    fun preferencesLearnAheadLimit(): String {
        return translate(26, 36, mapOf())
    }


    /** Legacy timezone handling (buggy, but required for AnkiDroid <= 2.14) */
    fun preferencesLegacyTimezoneHandling(): String {
        return translate(26, 37, mapOf())
    }


    /** Log-in successful. Save preferences and sync now? */
    fun preferencesLoginSuccessfulSyncNow(): String {
        return translate(26, 38, mapOf())
    }


    /** Media */
    fun preferencesMedia(): String {
        return translate(26, 39, mapOf())
    }


    /** Media is not backed up. Please create a periodic backup of your Anki folder to be safe. */
    fun preferencesMediaIsNotBackedUp(): String {
        return translate(26, 40, mapOf())
    }


    /** Minimalist mode */
    fun preferencesMinimalistMode(): String {
        return translate(26, 41, mapOf())
    }


    /** Make the interface more compact/less fancy */
    fun preferencesMinimalistModeTooltip(): String {
        return translate(26, 42, mapOf())
    }


    /** mins */
    fun preferencesMins(): String {
        return translate(26, 43, mapOf())
    }


    /** Minutes between automatic backups: */
    fun preferencesMinutesBetweenBackups(): String {
        return translate(26, 44, mapOf())
    }


    /** Monthly backups to keep: */
    fun preferencesMonthlyBackups(): String {
        return translate(26, 45, mapOf())
    }


    /** Syncing */
    fun preferencesNetwork(): String {
        return translate(26, 46, mapOf())
    }


    /** Network timeout */
    fun preferencesNetworkTimeout(): String {
        return translate(26, 47, mapOf())
    }


    /** Next day starts at */
    fun preferencesNextDayStartsAt(): String {
        return translate(26, 48, mapOf())
    }


    /** Not currently logged in to AnkiWeb. */
    fun preferencesNotLoggedIn(): String {
        return translate(26, 49, mapOf())
    }


    /** Note */
    fun preferencesNote(): String {
        return translate(26, 50, mapOf())
    }


    /** On next sync, force changes in one direction */
    fun preferencesOnNextSyncForceChangesIn(): String {
        return translate(26, 51, mapOf())
    }


    /** Paste clipboard images as PNG */
    fun preferencesPasteClipboardImagesAsPng(): String {
        return translate(26, 52, mapOf())
    }


    /** Paste without shift key strips formatting */
    fun preferencesPasteWithoutShiftKeyStripsFormatting(): String {
        return translate(26, 53, mapOf())
    }


    /** Periodically sync media */
    fun preferencesPeriodicallySyncMedia(): String {
        return translate(26, 54, mapOf())
    }


    /** Please restart Anki to complete language change. */
    fun preferencesPleaseRestartAnkiToCompleteLanguage(): String {
        return translate(26, 55, mapOf())
    }


    /** Preferences */
    fun preferencesPreferences(): String {
        return translate(26, 56, mapOf())
    }


    /** Reduce motion */
    fun preferencesReduceMotion(): String {
        return translate(26, 57, mapOf())
    }


    /** Disable various animations and transitions of the user interface */
    fun preferencesReduceMotionTooltip(): String {
        return translate(26, 58, mapOf())
    }


    /** Reset Window Sizes */
    fun preferencesResetWindowSizes(): String {
        return translate(26, 59, mapOf())
    }


    /** Window sizes and locations have been reset. */
    fun preferencesResetWindowSizesComplete(): String {
        return translate(26, 60, mapOf())
    }


    /** Review */
    fun preferencesReview(): String {
        return translate(26, 61, mapOf())
    }


    /** Reviewer */
    fun preferencesReviewer(): String {
        return translate(26, 62, mapOf())
    }


    /** Scheduler */
    fun preferencesScheduler(): String {
        return translate(26, 63, mapOf())
    }


    /** Scheduling */
    fun preferencesScheduling(): String {
        return translate(26, 64, mapOf())
    }


    /** Enter an unused shortcut key, or leave empty to disable. */
    fun preferencesShortcutPlaceholder(): String {
        return translate(26, 65, mapOf())
    }


    /** Show learning cards with larger steps before reviews */
    fun preferencesShowLearningCardsWithLargerSteps(): String {
        return translate(26, 66, mapOf())
    }


    /** Show next review time above answer buttons */
    fun preferencesShowNextReviewTimeAboveAnswer(): String {
        return translate(26, 67, mapOf())
    }


    /** Show play buttons on cards with audio */
    fun preferencesShowPlayButtonsOnCardsWith(): String {
        return translate(26, 68, mapOf())
    }


    /** Show remaining card count */
    fun preferencesShowRemainingCardCount(): String {
        return translate(26, 69, mapOf())
    }


    /** Some settings will take effect after you restart Anki. */
    fun preferencesSomeSettingsWillTakeEffectAfter(): String {
        return translate(26, 70, mapOf())
    }


    /** Spacebar (or enter) also answers card */
    fun preferencesSpacebarRatesCard(): String {
        return translate(26, 71, mapOf())
    }


    /** Style */
    fun preferencesStyle(): String {
        return translate(26, 72, mapOf())
    }


    /** Synchronize audio and images too */
    fun preferencesSynchronizeAudioAndImagesToo(): String {
        return translate(26, 73, mapOf())
    }


    /** Synchronization */
    fun preferencesTabSynchronisation(): String {
        return translate(26, 74, mapOf())
    }


    /** Theme */
    fun preferencesTheme(): String {
        return translate(26, 75, mapOf())
    }


    /** Dark */
    fun preferencesThemeDark(): String {
        return translate(26, 76, mapOf())
    }


    /** Follow System */
    fun preferencesThemeFollowSystem(): String {
        return translate(26, 77, mapOf())
    }


    /** Light */
    fun preferencesThemeLight(): String {
        return translate(26, 78, mapOf())
    }


    /** Third-party services are unaffiliated with and not endorsed by Anki. Use of these services may require payment. */
    fun preferencesThirdPartyDescription(): String {
        return translate(26, 79, mapOf())
    }


    /** Third-Party Services */
    fun preferencesThirdPartyServices(): String {
        return translate(26, 80, mapOf())
    }


    /** Timebox time limit */
    fun preferencesTimeboxTimeLimit(): String {
        return translate(26, 81, mapOf())
    }


    /** Updates */
    fun preferencesUpdates(): String {
        return translate(26, 82, mapOf())
    }


    /** Allow Once */
    fun preferencesUrlSchemeAllowOnce(): String {
        return translate(26, 83, mapOf())
    }


    /** Always Allow */
    fun preferencesUrlSchemeAlwaysAllow(): String {
        return translate(26, 84, mapOf())
    }


    /** Allowed URL Schemes (space-separated): */
    fun preferencesUrlSchemePrompt(): String {
        return translate(26, 85, mapOf())
    }


    /** Blocked attempt to open `{$link}`, which may be a security issue.

If you trust the deck author and wish to proceed, you can add `{$scheme}` to your allowed URL Schemes. */
    fun preferencesUrlSchemeWarning(`link`: String, `scheme`: String): String {
        return translate(26, 86, mapOf("link" to asTranslateArg(`link`), "scheme" to asTranslateArg(`scheme`)))
    }


    /** URL Schemes */
    fun preferencesUrlSchemes(): String {
        return translate(26, 87, mapOf())
    }


    /** User Interface */
    fun preferencesUserInterface(): String {
        return translate(26, 88, mapOf())
    }


    /** User interface size */
    fun preferencesUserInterfaceSize(): String {
        return translate(26, 89, mapOf())
    }


    /** V3 scheduler */
    fun preferencesV3Scheduler(): String {
        return translate(26, 90, mapOf())
    }


    /** Video driver */
    fun preferencesVideoDriver(): String {
        return translate(26, 91, mapOf())
    }


    /** ANGLE (may work better than OpenGL) */
    fun preferencesVideoDriverAngle(): String {
        return translate(26, 92, mapOf())
    }


    /** default */
    fun preferencesVideoDriverDefault(): String {
        return translate(26, 93, mapOf())
    }


    /** OpenGL (recommended on Macs) */
    fun preferencesVideoDriverOpenglMac(): String {
        return translate(26, 94, mapOf())
    }


    /** OpenGL (faster, may cause issues) */
    fun preferencesVideoDriverOpenglOther(): String {
        return translate(26, 95, mapOf())
    }


    /** Software (not recommended) */
    fun preferencesVideoDriverSoftwareMac(): String {
        return translate(26, 96, mapOf())
    }


    /** Software (slower) */
    fun preferencesVideoDriverSoftwareOther(): String {
        return translate(26, 97, mapOf())
    }


    /** Weekly backups to keep: */
    fun preferencesWeeklyBackups(): String {
        return translate(26, 98, mapOf())
    }


    /** When adding, default to current deck */
    fun preferencesWhenAddingDefaultToCurrentDeck(): String {
        return translate(26, 99, mapOf())
    }


    /** You can restore backups via File > Switch Profile. */
    fun preferencesYouCanRestoreBackupsViaFileswitch(): String {
        return translate(26, 100, mapOf())
    }


    /** Anki could not read your profile data. Window sizes and your sync login details have been forgotten. */
    fun profilesAnkiCouldNotReadYourProfile(): String {
        return translate(27, 0, mapOf())
    }


    /** Anki could not rename your profile because it could not rename the profile folder on disk. Please ensure you have permission to write to Documents/Anki and no other programs are accessing your profile folders, then try again. */
    fun profilesAnkiCouldNotRenameYourProfile(): String {
        return translate(27, 1, mapOf())
    }


    /** Backup created. */
    fun profilesBackupCreated(): String {
        return translate(27, 2, mapOf())
    }


    /** Backup creation failed: {$reason} */
    fun profilesBackupCreationFailed(`reason`: String): String {
        return translate(27, 3, mapOf("reason" to asTranslateArg(`reason`)))
    }


    /** No changes since latest backup. */
    fun profilesBackupUnchanged(): String {
        return translate(27, 4, mapOf())
    }


    /** Are you sure you wish to display Anki's interface in {$lang}? */
    fun profilesConfirmLangChoice(`lang`: String): String {
        return translate(27, 5, mapOf("lang" to asTranslateArg(`lang`)))
    }


    /** Anki could not create its data folder. Please see the File Locations section of the manual, and ensure that location is not read-only. */
    fun profilesCouldNotCreateDataFolder(): String {
        return translate(27, 6, mapOf())
    }


    /** Creating Backup... */
    fun profilesCreatingBackup(): String {
        return translate(27, 7, mapOf())
    }


    /** Downgrade && Quit */
    fun profilesDowngradeAndQuit(): String {
        return translate(27, 8, mapOf())
    }


    /** Folder already exists. */
    fun profilesFolderAlreadyExists(): String {
        return translate(27, 9, mapOf())
    }


    /** This folder stores all of your Anki data in a single location,
to make backups easy. To tell Anki to use a different location,
please see:

{$link} */
    fun profilesFolderReadme(`link`: String): String {
        return translate(27, 10, mapOf("link" to asTranslateArg(`link`)))
    }


    /** Open */
    fun profilesOpen(): String {
        return translate(27, 11, mapOf())
    }


    /** Open Backup... */
    fun profilesOpenBackup(): String {
        return translate(27, 12, mapOf())
    }


    /** Please remove the folder {$val} and try again. */
    fun profilesPleaseRemoveTheFolderAnd(`val`: TranslateArg): String {
        return translate(27, 13, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Preferences Corrupt */
    fun profilesPrefsCorruptTitle(): String {
        return translate(27, 14, mapOf())
    }


    /** Anki's prefs21.db file was corrupt and has been recreated. If you were using multiple profiles, please add them back using the same names to recover your cards. */
    fun profilesPrefsFileIsCorrupt(): String {
        return translate(27, 15, mapOf())
    }


    /** Profile Corrupt */
    fun profilesProfileCorrupt(): String {
        return translate(27, 16, mapOf())
    }


    /** Requested profile does not exist. */
    fun profilesProfileDoesNotExist(): String {
        return translate(27, 17, mapOf())
    }


    /** Profiles */
    fun profilesProfiles(): String {
        return translate(27, 18, mapOf())
    }


    /** Quit */
    fun profilesQuit(): String {
        return translate(27, 19, mapOf())
    }


    /** User 1 */
    fun profilesUser1(): String {
        return translate(27, 20, mapOf())
    }


    /** &About */
    fun qtAccelAbout(): String {
        return translate(28, 0, mapOf())
    }


    /** About Anki... */
    fun qtAccelAboutMac(): String {
        return translate(28, 1, mapOf())
    }


    /** &Cards */
    fun qtAccelCards(): String {
        return translate(28, 2, mapOf())
    }


    /** &Check Database */
    fun qtAccelCheckDatabase(): String {
        return translate(28, 3, mapOf())
    }


    /** Check &Media */
    fun qtAccelCheckMedia(): String {
        return translate(28, 4, mapOf())
    }


    /** Create &Backup */
    fun qtAccelCreateBackup(): String {
        return translate(28, 5, mapOf())
    }


    /** &Edit */
    fun qtAccelEdit(): String {
        return translate(28, 6, mapOf())
    }


    /** E&xit */
    fun qtAccelExit(): String {
        return translate(28, 7, mapOf())
    }


    /** &Export... */
    fun qtAccelExport(): String {
        return translate(28, 8, mapOf())
    }


    /** &Export Notes... */
    fun qtAccelExportNotes(): String {
        return translate(28, 9, mapOf())
    }


    /** &File */
    fun qtAccelFile(): String {
        return translate(28, 10, mapOf())
    }


    /** Fil&ter */
    fun qtAccelFilter(): String {
        return translate(28, 11, mapOf())
    }


    /** &Find */
    fun qtAccelFind(): String {
        return translate(28, 12, mapOf())
    }


    /** Find and Re&place... */
    fun qtAccelFindAndReplace(): String {
        return translate(28, 13, mapOf())
    }


    /** Find &Duplicates... */
    fun qtAccelFindDuplicates(): String {
        return translate(28, 14, mapOf())
    }


    /** &Reset */
    fun qtAccelForget(): String {
        return translate(28, 15, mapOf())
    }


    /** Toggle &Full Screen */
    fun qtAccelFullScreen(): String {
        return translate(28, 16, mapOf())
    }


    /** &Go */
    fun qtAccelGo(): String {
        return translate(28, 17, mapOf())
    }


    /** &Guide */
    fun qtAccelGuide(): String {
        return translate(28, 18, mapOf())
    }


    /** &Help */
    fun qtAccelHelp(): String {
        return translate(28, 19, mapOf())
    }


    /** &Import... */
    fun qtAccelImport(): String {
        return translate(28, 20, mapOf())
    }


    /** &Info... */
    fun qtAccelInfo(): String {
        return translate(28, 21, mapOf())
    }


    /** &Invert Selection */
    fun qtAccelInvertSelection(): String {
        return translate(28, 22, mapOf())
    }


    /** &Layout */
    fun qtAccelLayout(): String {
        return translate(28, 23, mapOf())
    }


    /** &Auto */
    fun qtAccelLayoutAuto(): String {
        return translate(28, 24, mapOf())
    }


    /** &Horizontal */
    fun qtAccelLayoutHorizontal(): String {
        return translate(28, 25, mapOf())
    }


    /** &Vertical */
    fun qtAccelLayoutVertical(): String {
        return translate(28, 26, mapOf())
    }


    /** &Revert to Backup */
    fun qtAccelLoadBackup(): String {
        return translate(28, 27, mapOf())
    }


    /** &Next Card */
    fun qtAccelNextCard(): String {
        return translate(28, 28, mapOf())
    }


    /** N&ote */
    fun qtAccelNote(): String {
        return translate(28, 29, mapOf())
    }


    /** &Notes */
    fun qtAccelNotes(): String {
        return translate(28, 30, mapOf())
    }


    /** &Preferences */
    fun qtAccelPreferences(): String {
        return translate(28, 31, mapOf())
    }


    /** &Previous Card */
    fun qtAccelPreviousCard(): String {
        return translate(28, 32, mapOf())
    }


    /** &Redo */
    fun qtAccelRedo(): String {
        return translate(28, 33, mapOf())
    }


    /** &Reset Zoom */
    fun qtAccelResetZoom(): String {
        return translate(28, 34, mapOf())
    }


    /** Select &All */
    fun qtAccelSelectAll(): String {
        return translate(28, 35, mapOf())
    }


    /** Select &Notes */
    fun qtAccelSelectNotes(): String {
        return translate(28, 36, mapOf())
    }


    /** Set &Due Date... */
    fun qtAccelSetDueDate(): String {
        return translate(28, 37, mapOf())
    }


    /** &Support Anki */
    fun qtAccelSupportAnki(): String {
        return translate(28, 38, mapOf())
    }


    /** &Switch Profile */
    fun qtAccelSwitchProfile(): String {
        return translate(28, 39, mapOf())
    }


    /** Toggle Sidebar */
    fun qtAccelToggleSidebar(): String {
        return translate(28, 40, mapOf())
    }


    /** &Tools */
    fun qtAccelTools(): String {
        return translate(28, 41, mapOf())
    }


    /** &Undo */
    fun qtAccelUndo(): String {
        return translate(28, 42, mapOf())
    }


    /** &View */
    fun qtAccelView(): String {
        return translate(28, 43, mapOf())
    }


    /** Zoom Editor &In */
    fun qtAccelZoomEditorIn(): String {
        return translate(28, 44, mapOf())
    }


    /** Zoom Editor &Out */
    fun qtAccelZoomEditorOut(): String {
        return translate(28, 45, mapOf())
    }


    /** Zoom &In */
    fun qtAccelZoomIn(): String {
        return translate(28, 46, mapOf())
    }


    /** Zoom &Out */
    fun qtAccelZoomOut(): String {
        return translate(28, 47, mapOf())
    }


    /** Add-on will be installed when a profile is opened. */
    fun qtMiscAddonWillBeInstalledWhenA(): String {
        return translate(29, 0, mapOf())
    }


    /** Add-ons */
    fun qtMiscAddons(): String {
        return translate(29, 1, mapOf())
    }


    /** All cards, notes, and media for this profile will be deleted. Are you sure? */
    fun qtMiscAllCardsNotesAndMediaFor(): String {
        return translate(29, 2, mapOf())
    }


    /** All cards, notes, and media for the profile "{$name}" will be deleted. Are you sure? */
    fun qtMiscAllCardsNotesAndMediaFor2(`name`: String): String {
        return translate(29, 3, mapOf("name" to asTranslateArg(`name`)))
    }


    /** Anki Already Running */
    fun qtMiscAnkiIsRunning(): String {
        return translate(29, 4, mapOf())
    }


    /** <h1>Anki Updated</h1>Anki {$val} has been released.<br><br> */
    fun qtMiscAnkiUpdatedankiHasBeenReleased(`val`: TranslateArg): String {
        return translate(29, 5, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Backup successfully restored. Automatic syncing and backups have been disabled for now. To enable them again, close the profile or restart Anki. */
    fun qtMiscAutomaticSyncingAndBackupsHaveBeen(): String {
        return translate(29, 6, mapOf())
    }


    /** Back Side Only */
    fun qtMiscBackSideOnly(): String {
        return translate(29, 7, mapOf())
    }


    /** Backing Up... */
    fun qtMiscBackingUp(): String {
        return translate(29, 8, mapOf())
    }


    /** Browse */
    fun qtMiscBrowse(): String {
        return translate(29, 9, mapOf())
    }


    /** Change Note Type (Ctrl+N) */
    fun qtMiscChangeNoteTypeCtrlandn(): String {
        return translate(29, 10, mapOf())
    }


    /** Check the files in the media directory */
    fun qtMiscCheckTheFilesInTheMedia(): String {
        return translate(29, 11, mapOf())
    }


    /** Choose Deck */
    fun qtMiscChooseDeck(): String {
        return translate(29, 12, mapOf())
    }


    /** Choose Note Type */
    fun qtMiscChooseNoteType(): String {
        return translate(29, 13, mapOf())
    }


    /** Closing... */
    fun qtMiscClosing(): String {
        return translate(29, 14, mapOf())
    }


    /** Configure interface language and options */
    fun qtMiscConfigureInterfaceLanguageAndOptions(): String {
        return translate(29, 15, mapOf())
    }


    /** Copy to Clipboard */
    fun qtMiscCopyToClipboard(): String {
        return translate(29, 16, mapOf())
    }


    /** Create Filtered Deck... */
    fun qtMiscCreateFilteredDeck(): String {
        return translate(29, 17, mapOf())
    }


    /** Debug Console */
    fun qtMiscDebugConsole(): String {
        return translate(29, 18, mapOf())
    }


    /** Deck will be imported when a profile is opened. */
    fun qtMiscDeckWillBeImportedWhenA(): String {
        return translate(29, 19, mapOf())
    }


    /** Downloading update: {$count}MB/{$total}MB */
    fun qtMiscDownloadingUpdate(`count`: Int, `total`: Int): String {
        return translate(29, 20, mapOf("count" to asTranslateArg(`count`), "total" to asTranslateArg(`total`)))
    }


    /** Empty Cards... */
    fun qtMiscEmptyCards(): String {
        return translate(29, 21, mapOf())
    }


    /** Error */
    fun qtMiscError(): String {
        return translate(29, 22, mapOf())
    }


    /** Error during startup: {$val} */
    fun qtMiscErrorDuringStartup(`val`: TranslateArg): String {
        return translate(29, 23, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Error loading '{$mode}' graphics driver. Please start Anki again to try the next driver. {$context} */
    fun qtMiscErrorLoadingGraphicsDriver(`mode`: String, `context`: String): String {
        return translate(29, 24, mapOf("mode" to asTranslateArg(`mode`), "context" to asTranslateArg(`context`)))
    }


    /** If the existing instance of Anki is not responding, please close it using your task manager, or restart your computer. */
    fun qtMiscIfInstanceIsNotResponding(): String {
        return translate(29, 25, mapOf())
    }


    /** Ignore this update */
    fun qtMiscIgnoreThisUpdate(): String {
        return translate(29, 26, mapOf())
    }


    /** In order to ensure your collection works correctly when moved between devices, Anki requires your computer's internal clock to be set correctly. The internal clock can be wrong even if your system is showing the correct local time.<br><br>Please go to the time settings on your computer and check the following:<br><br>- AM/PM<br>- Clock drift<br>- Day, month and year<br>- Timezone<br>- Daylight savings<br><br>Difference to correct time: {$val}. */
    fun qtMiscInOrderToEnsureYourCollection(`val`: TranslateArg): String {
        return translate(29, 27, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Your video driver is incompatible. Please start Anki again, and Anki will switch to a slower, more compatible mode. */
    fun qtMiscIncompatibleVideoDriver(): String {
        return translate(29, 28, mapOf())
    }


    /** Invalid property found on card. Please use Tools>Check Database, and if the problem comes up again, please ask on the support site. */
    fun qtMiscInvalidPropertyFoundOnCardPlease(): String {
        return translate(29, 29, mapOf())
    }


    /** Responsive layout enabled */
    fun qtMiscLayoutAutoEnabled(): String {
        return translate(29, 30, mapOf())
    }


    /** Horizontal layout enabled */
    fun qtMiscLayoutHorizontalEnabled(): String {
        return translate(29, 31, mapOf())
    }


    /** Vertical layout enabled */
    fun qtMiscLayoutVerticalEnabled(): String {
        return translate(29, 32, mapOf())
    }


    /** Loading... */
    fun qtMiscLoading(): String {
        return translate(29, 33, mapOf())
    }


    /** Manage */
    fun qtMiscManage(): String {
        return translate(29, 34, mapOf())
    }


    /** Manage Note Types */
    fun qtMiscManageNoteTypes(): String {
        return translate(29, 35, mapOf())
    }


    /** Name exists. */
    fun qtMiscNameExists(): String {
        return translate(29, 36, mapOf())
    }


    /** No usable temporary folder found. Make sure C:\\temp exists or TEMP in your environment points to a valid, writable folder. */
    fun qtMiscNoTempFolder(): String {
        return translate(29, 37, mapOf())
    }


    /** <non-unicode text> */
    fun qtMiscNonUnicodeText(): String {
        return translate(29, 38, mapOf())
    }


    /** Optimizing... */
    fun qtMiscOptimizing(): String {
        return translate(29, 39, mapOf())
    }


    /** Please ensure a profile is open and Anki is not busy, then try again. */
    fun qtMiscPleaseEnsureAProfileIsOpen(): String {
        return translate(29, 40, mapOf())
    }


    /** (please select 1 card) */
    fun qtMiscPleaseSelect1Card(): String {
        return translate(29, 41, mapOf())
    }


    /** Please select a deck. */
    fun qtMiscPleaseSelectADeck(): String {
        return translate(29, 42, mapOf())
    }


    /** Please use File>Import to import this file. */
    fun qtMiscPleaseUseFileimportToImportThis(): String {
        return translate(29, 43, mapOf())
    }


    /** Processing... */
    fun qtMiscProcessing(): String {
        return translate(29, 44, mapOf())
    }


    /** Replace your collection with an earlier backup? */
    fun qtMiscReplaceYourCollectionWithAnEarlier(): String {
        return translate(29, 45, mapOf())
    }


    /** Replace your collection with an earlier backup from {$val}? */
    fun qtMiscReplaceYourCollectionWithAnEarlier2(`val`: TranslateArg): String {
        return translate(29, 46, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Revert to backup */
    fun qtMiscRevertToBackup(): String {
        return translate(29, 47, mapOf())
    }


    /** {$count} seconds */
    fun qtMiscSecond(`count`: Int): String {
        return translate(29, 48, mapOf("count" to asTranslateArg(`count`)))
    }


    /** "Segoe UI" */
    fun qtMiscSegoeUi(): String {
        return translate(29, 49, mapOf())
    }


    /** Shift key was held down. Skipping automatic syncing and add-on loading. */
    fun qtMiscShiftKeyWasHeldDownSkipping(): String {
        return translate(29, 50, mapOf())
    }


    /** Shortcut key: Left arrow */
    fun qtMiscShortcutKeyLeftArrow(): String {
        return translate(29, 51, mapOf())
    }


    /** Shortcut key: Right arrow or Enter */
    fun qtMiscShortcutKeyRightArrowOrEnter(): String {
        return translate(29, 52, mapOf())
    }


    /** Stats */
    fun qtMiscStats(): String {
        return translate(29, 53, mapOf())
    }


    /** Study Deck... */
    fun qtMiscStudyDeck(): String {
        return translate(29, 54, mapOf())
    }


    /** Sync */
    fun qtMiscSync(): String {
        return translate(29, 55, mapOf())
    }


    /** Target Deck (Ctrl+D) */
    fun qtMiscTargetDeckCtrlandd(): String {
        return translate(29, 56, mapOf())
    }


    /** The following character can not be used: {$val} */
    fun qtMiscTheFollowingCharacterCanNotBe(`val`: TranslateArg): String {
        return translate(29, 57, mapOf("val" to asTranslateArg(`val`)))
    }


    /** The requested change will require a full upload of the database when you next synchronize your collection. If you have reviews or other changes waiting on another device that haven't been synchronized here yet, they will be lost. Continue? */
    fun qtMiscTheRequestedChangeWillRequireA(): String {
        return translate(29, 58, mapOf())
    }


    /** There must be at least one profile. */
    fun qtMiscThereMustBeAtLeastOne(): String {
        return translate(29, 59, mapOf())
    }


    /** This file exists. Are you sure you want to overwrite it? */
    fun qtMiscThisFileExistsAreYouSure(): String {
        return translate(29, 60, mapOf())
    }


    /** Unable to access Anki media folder. The permissions on your system's temporary folder may be incorrect. */
    fun qtMiscUnableToAccessAnkiMediaFolder(): String {
        return translate(29, 61, mapOf())
    }


    /** Unable to record. Please ensure a microphone is connected, and Anki has permission to use the microphone.
If other programs are using your microphone, closing them may help.

Original error: {$error} */
    fun qtMiscUnableToRecord(`error`: String): String {
        return translate(29, 62, mapOf("error" to asTranslateArg(`error`)))
    }


    /** Unexpected response code: {$val} */
    fun qtMiscUnexpectedResponseCode(`val`: TranslateArg): String {
        return translate(29, 63, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Would you like to download it now? */
    fun qtMiscWouldYouLikeToDownloadIt(): String {
        return translate(29, 64, mapOf())
    }


    /** Your collection file appears to be corrupt. This can happen when the file is copied or moved while Anki is open, or when the collection is stored on a network or cloud drive. If problems persist after restarting your computer, please open an automatic backup from the profile screen. */
    fun qtMiscYourCollectionFileAppearsToBe(): String {
        return translate(29, 65, mapOf())
    }


    /** Your computer's storage may be full. Please delete some unneeded files, then try again. */
    fun qtMiscYourComputersStorageMayBeFull(): String {
        return translate(29, 66, mapOf())
    }


    /** Your firewall or antivirus program is preventing Anki from creating a connection to itself. Please add an exception for Anki. */
    fun qtMiscYourFirewallOrAntivirusProgramIs(): String {
        return translate(29, 67, mapOf())
    }


    /** Always include question side when replaying audio */
    fun schedulingAlwaysIncludeQuestionSideWhenReplaying(): String {
        return translate(30, 0, mapOf())
    }


    /** {$amount}d */
    fun schedulingAnswerButtonTimeDays(`amount`: Int): String {
        return translate(30, 1, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}h */
    fun schedulingAnswerButtonTimeHours(`amount`: Int): String {
        return translate(30, 2, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}m */
    fun schedulingAnswerButtonTimeMinutes(`amount`: Int): String {
        return translate(30, 3, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}mo */
    fun schedulingAnswerButtonTimeMonths(`amount`: Int): String {
        return translate(30, 4, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}s */
    fun schedulingAnswerButtonTimeSeconds(`amount`: Int): String {
        return translate(30, 5, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}y */
    fun schedulingAnswerButtonTimeYears(`amount`: Int): String {
        return translate(30, 6, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** At least one step is required. */
    fun schedulingAtLeastOneStepIsRequired(): String {
        return translate(30, 7, mapOf())
    }


    /** Automatically play audio */
    fun schedulingAutomaticallyPlayAudio(): String {
        return translate(30, 8, mapOf())
    }


    /** One or more cards were buried, and will be shown tomorrow. You can {$unburyThem} if you wish to see them immediately. */
    fun schedulingBuriedCardsFound(`unburyThem`: String): String {
        return translate(30, 9, mapOf("unburyThem" to asTranslateArg(`unburyThem`)))
    }


    /** Bury related new cards until the next day */
    fun schedulingBuryRelatedNewCardsUntilThe(): String {
        return translate(30, 10, mapOf())
    }


    /** Bury related reviews until the next day */
    fun schedulingBuryRelatedReviewsUntilTheNext(): String {
        return translate(30, 11, mapOf())
    }


    /** Congratulations! You have finished this deck for now. */
    fun schedulingCongratulationsFinished(): String {
        return translate(30, 12, mapOf())
    }


    /** custom study */
    fun schedulingCustomStudy(): String {
        return translate(30, 13, mapOf())
    }


    /** days */
    fun schedulingDays(): String {
        return translate(30, 14, mapOf())
    }


    /** {$count} decks updated. */
    fun schedulingDeckUpdated(`count`: Int): String {
        return translate(30, 15, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Description */
    fun schedulingDescription(): String {
        return translate(30, 16, mapOf())
    }


    /** Easy bonus */
    fun schedulingEasyBonus(): String {
        return translate(30, 17, mapOf())
    }


    /** Easy interval */
    fun schedulingEasyInterval(): String {
        return translate(30, 18, mapOf())
    }


    /** (end) */
    fun schedulingEnd(): String {
        return translate(30, 19, mapOf())
    }


    /** Reset {$cards} cards. */
    fun schedulingForgotCards(`cards`: Int): String {
        return translate(30, 20, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** General */
    fun schedulingGeneral(): String {
        return translate(30, 21, mapOf())
    }


    /** Graded {$cards} cards. */
    fun schedulingGradedCardsDone(`cards`: Int): String {
        return translate(30, 22, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** Graduating interval */
    fun schedulingGraduatingInterval(): String {
        return translate(30, 23, mapOf())
    }


    /** Hard interval */
    fun schedulingHardInterval(): String {
        return translate(30, 24, mapOf())
    }


    /** If you wish to study outside of the regular schedule, you can use the {$customStudy} feature. */
    fun schedulingHowToCustomStudy(`customStudy`: String): String {
        return translate(30, 25, mapOf("customStudy" to asTranslateArg(`customStudy`)))
    }


    /** Ignore answer times longer than */
    fun schedulingIgnoreAnswerTimesLongerThan(): String {
        return translate(30, 26, mapOf())
    }


    /** Interval modifier */
    fun schedulingIntervalModifier(): String {
        return translate(30, 27, mapOf())
    }


    /** Lapses */
    fun schedulingLapses(): String {
        return translate(30, 28, mapOf())
    }


    /** lapses */
    fun schedulingLapses2(): String {
        return translate(30, 29, mapOf())
    }


    /** There are {$remaining} learning cards due later today. */
    fun schedulingLearnRemaining(`remaining`: Int): String {
        return translate(30, 30, mapOf("remaining" to asTranslateArg(`remaining`)))
    }


    /** Learning */
    fun schedulingLearning(): String {
        return translate(30, 31, mapOf())
    }


    /** Leech action */
    fun schedulingLeechAction(): String {
        return translate(30, 32, mapOf())
    }


    /** Leech threshold */
    fun schedulingLeechThreshold(): String {
        return translate(30, 33, mapOf())
    }


    /** Maximum interval */
    fun schedulingMaximumInterval(): String {
        return translate(30, 34, mapOf())
    }


    /** Maximum reviews/day */
    fun schedulingMaximumReviewsday(): String {
        return translate(30, 35, mapOf())
    }


    /** Minimum interval */
    fun schedulingMinimumInterval(): String {
        return translate(30, 36, mapOf())
    }


    /** Mix new cards and reviews */
    fun schedulingMixNewCardsAndReviews(): String {
        return translate(30, 37, mapOf())
    }


    /** New Cards */
    fun schedulingNewCards(): String {
        return translate(30, 38, mapOf())
    }


    /** New cards/day */
    fun schedulingNewCardsday(): String {
        return translate(30, 39, mapOf())
    }


    /** New interval */
    fun schedulingNewInterval(): String {
        return translate(30, 40, mapOf())
    }


    /** New options group name: */
    fun schedulingNewOptionsGroupName(): String {
        return translate(30, 41, mapOf())
    }


    /** The next learning card will be ready in {$amount} hours. */
    fun schedulingNextLearnDue(`unit`: String, `amount`: Int): String {
        return translate(30, 42, mapOf("unit" to asTranslateArg(`unit`), "amount" to asTranslateArg(`amount`)))
    }


    /** Options group: */
    fun schedulingOptionsGroup(): String {
        return translate(30, 43, mapOf())
    }


    /** Order */
    fun schedulingOrder(): String {
        return translate(30, 44, mapOf())
    }


    /** (parent limit: {$val}) */
    fun schedulingParentLimit(`val`: TranslateArg): String {
        return translate(30, 45, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Reset repetition and lapse counts */
    fun schedulingResetCounts(): String {
        return translate(30, 46, mapOf())
    }


    /** Restore original position where possible */
    fun schedulingRestorePosition(): String {
        return translate(30, 47, mapOf())
    }


    /** Review */
    fun schedulingReview(): String {
        return translate(30, 48, mapOf())
    }


    /** Reviews */
    fun schedulingReviews(): String {
        return translate(30, 49, mapOf())
    }


    /** seconds */
    fun schedulingSeconds(): String {
        return translate(30, 50, mapOf())
    }


    /** Set all decks below {$val} to this option group? */
    fun schedulingSetAllDecksBelowTo(`val`: TranslateArg): String {
        return translate(30, 51, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Set due date of {$cards} cards. */
    fun schedulingSetDueDateDone(`cards`: Int): String {
        return translate(30, 52, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** Show cards in how many days? */
    fun schedulingSetDueDatePrompt(`cards`: Int): String {
        return translate(30, 53, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** 0 = today
1! = tomorrow + change interval to 1
3-7 = random choice of 3-7 days */
    fun schedulingSetDueDatePromptHint(): String {
        return translate(30, 54, mapOf())
    }


    /** Set for all subdecks */
    fun schedulingSetForAllSubdecks(): String {
        return translate(30, 55, mapOf())
    }


    /** Show on-screen timer */
    fun schedulingShowAnswerTimer(): String {
        return translate(30, 56, mapOf())
    }


    /** Show new cards after reviews */
    fun schedulingShowNewCardsAfterReviews(): String {
        return translate(30, 57, mapOf())
    }


    /** Show new cards before reviews */
    fun schedulingShowNewCardsBeforeReviews(): String {
        return translate(30, 58, mapOf())
    }


    /** Show new cards in order added */
    fun schedulingShowNewCardsInOrderAdded(): String {
        return translate(30, 59, mapOf())
    }


    /** Show new cards in random order */
    fun schedulingShowNewCardsInRandomOrder(): String {
        return translate(30, 60, mapOf())
    }


    /** Starting ease */
    fun schedulingStartingEase(): String {
        return translate(30, 61, mapOf())
    }


    /** Steps (in minutes) */
    fun schedulingStepsInMinutes(): String {
        return translate(30, 62, mapOf())
    }


    /** Steps must be numbers. */
    fun schedulingStepsMustBeNumbers(): String {
        return translate(30, 63, mapOf())
    }


    /** Tag Only */
    fun schedulingTagOnly(): String {
        return translate(30, 64, mapOf())
    }


    /** The default configuration can't be removed. */
    fun schedulingTheDefaultConfigurationCantBeRemoved(): String {
        return translate(30, 65, mapOf())
    }


    /** {$amount} days */
    fun schedulingTimeSpanDays(`amount`: Int): String {
        return translate(30, 66, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount} hours */
    fun schedulingTimeSpanHours(`amount`: Int): String {
        return translate(30, 67, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount} minutes */
    fun schedulingTimeSpanMinutes(`amount`: Int): String {
        return translate(30, 68, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount} months */
    fun schedulingTimeSpanMonths(`amount`: Int): String {
        return translate(30, 69, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount} seconds */
    fun schedulingTimeSpanSeconds(`amount`: Int): String {
        return translate(30, 70, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount} years */
    fun schedulingTimeSpanYears(`amount`: Int): String {
        return translate(30, 71, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** There are more new cards available, but the daily limit has been
reached. You can increase the limit in the options, but please
bear in mind that the more new cards you introduce, the higher
your short-term review workload will become. */
    fun schedulingTodayNewLimitReached(): String {
        return translate(30, 72, mapOf())
    }


    /** Today's review limit has been reached, but there are still cards
waiting to be reviewed. For optimum memory, consider increasing
the daily limit in the options. */
    fun schedulingTodayReviewLimitReached(): String {
        return translate(30, 73, mapOf())
    }


    /** unbury them */
    fun schedulingUnburyThem(): String {
        return translate(30, 74, mapOf())
    }


    /** Update */
    fun schedulingUpdateButton(): String {
        return translate(30, 75, mapOf())
    }


    /** Scheduler updated successfully. */
    fun schedulingUpdateDone(): String {
        return translate(30, 76, mapOf())
    }


    /** Later */
    fun schedulingUpdateLaterButton(): String {
        return translate(30, 77, mapOf())
    }


    /** Learn More */
    fun schedulingUpdateMoreInfoButton(): String {
        return translate(30, 78, mapOf())
    }


    /** Your collection needs to be upgraded to the V2 scheduler.
Please select  before proceeding. */
    fun schedulingUpdateRequired(): String {
        return translate(30, 79, mapOf())
    }


    /** Anki 2.1 comes with a new scheduler, which fixes a number of issues that previous Anki versions had. Updating to it is recommended. */
    fun schedulingUpdateSoon(): String {
        return translate(30, 80, mapOf())
    }


    /** Your changes will affect multiple decks. If you wish to change only the current deck, please add a new options group first. */
    fun schedulingYourChangesWillAffectMultipleDecks(): String {
        return translate(30, 81, mapOf())
    }


    /** Card Modified */
    fun searchCardModified(): String {
        return translate(31, 0, mapOf())
    }


    /** a group `(...)` was found, but there was nothing between the brackets to search for. If you want to search for literal brackets, wrap them in double quotes: `"( )"`. */
    fun searchEmptyGroup(): String {
        return translate(31, 1, mapOf())
    }


    /** a pair of double quotes `""` was found, but there was nothing between them to search for. If you want to search for literal double quotes, prepend backslashes: `\"\"`. */
    fun searchEmptyQuote(): String {
        return translate(31, 2, mapOf())
    }


    /** expected an answer button between 1-4 in "`{$context}`", but found "`{$provided}`". */
    fun searchInvalidAnswerButton(`context`: String, `provided`: String): String {
        return translate(31, 3, mapOf("context" to asTranslateArg(`context`), "provided" to asTranslateArg(`provided`)))
    }


    /** `{$term}` was given an invalid argument '`{$argument}`'. */
    fun searchInvalidArgument(`term`: String, `argument`: String): String {
        return translate(31, 4, mapOf("term" to asTranslateArg(`term`), "argument" to asTranslateArg(`argument`)))
    }


    /** `flag:` must be followed by a valid flag number: `1` (red), `2` (orange), `3` (green), `4` (blue), `5` (pink), `6` (turquoise), `7` (purple) or `0` (no flag). */
    fun searchInvalidFlag2(): String {
        return translate(31, 5, mapOf())
    }


    /** expected a whole number less than or equal to 0 in "`{$context}`", but found "`{$provided}`". */
    fun searchInvalidNegativeWholeNumber(`context`: String, `provided`: String): String {
        return translate(31, 6, mapOf("context" to asTranslateArg(`context`), "provided" to asTranslateArg(`provided`)))
    }


    /** expected a number in "`{$context}`", but found "`{$provided}`". */
    fun searchInvalidNumber(`context`: String, `provided`: String): String {
        return translate(31, 7, mapOf("context" to asTranslateArg(`context`), "provided" to asTranslateArg(`provided`)))
    }


    /** please check for typing mistakes. */
    fun searchInvalidOther(): String {
        return translate(31, 8, mapOf())
    }


    /** expected a positive whole number in "`{$context}`", but found "`{$provided}`". */
    fun searchInvalidPositiveWholeNumber(`context`: String, `provided`: String): String {
        return translate(31, 9, mapOf("context" to asTranslateArg(`context`), "provided" to asTranslateArg(`provided`)))
    }


    /** `prop:{$val}` must be followed by one of the following comparison operators: `=`, `!=`, `<`, `>`, `<=` or `>=`. */
    fun searchInvalidPropOperator(`val`: TranslateArg): String {
        return translate(31, 10, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Invalid search: {$reason} */
    fun searchInvalidSearch(`reason`: String): String {
        return translate(31, 11, mapOf("reason" to asTranslateArg(`reason`)))
    }


    /** expected a whole number in "`{$context}`", but found "`{$provided}`". */
    fun searchInvalidWholeNumber(`context`: String, `provided`: String): String {
        return translate(31, 12, mapOf("context" to asTranslateArg(`context`), "provided" to asTranslateArg(`provided`)))
    }


    /** an `and` was found but it is not connecting two search terms. If you want to search for the word itself, wrap it in double quotes: `"and"`. */
    fun searchMisplacedAnd(): String {
        return translate(31, 13, mapOf())
    }


    /** an `or` was found but it is not connecting two search terms. If you want to search for the word itself, wrap it in double quotes: `"or"`. */
    fun searchMisplacedOr(): String {
        return translate(31, 14, mapOf())
    }


    /** a colon `:` was found, but there was no keyword preceding it. If you want to search for a literal `:`, prepend a backslash: `\:`. */
    fun searchMissingKey(): String {
        return translate(31, 15, mapOf())
    }


    /** Note Modified */
    fun searchNoteModified(): String {
        return translate(31, 16, mapOf())
    }


    /** an opening bracket `(` was found, but there was no closing bracket `)` following it. If you want to search for a literal `(`, wrap it in double quotes or prepend a backslash: `"("` or `\(` . */
    fun searchUnclosedGroup(): String {
        return translate(31, 17, mapOf())
    }


    /** an opening double quote `"` was found, but there was no second one to close it. If you want to search for a literal `"`, prepend a backslash: `\"`. */
    fun searchUnclosedQuote(): String {
        return translate(31, 18, mapOf())
    }


    /** the escape sequence `{$val}` is not defined. If you want to search for a literal backslash `\`, prepend another one: `\\`. */
    fun searchUnknownEscape(`val`: TranslateArg): String {
        return translate(31, 19, mapOf("val" to asTranslateArg(`val`)))
    }


    /** a closing bracket `)` was found, but there was no opening bracket `(` preceding it. If you want to search for a literal `)`, wrap it in double quotes or prepend a backslash: `")"` or `\)`. */
    fun searchUnopenedGroup(): String {
        return translate(31, 20, mapOf())
    }


    /** View in browser */
    fun searchViewInBrowser(): String {
        return translate(31, 21, mapOf())
    }


    /** The number of new cards you have added. */
    fun statisticsAddedSubtitle(): String {
        return translate(32, 0, mapOf())
    }


    /** Added */
    fun statisticsAddedTitle(): String {
        return translate(32, 1, mapOf())
    }


    /** {$amount} of {$total} ({$percent}%) */
    fun statisticsAmountOfTotalWithPercentage(`amount`: Int, `total`: Int, `percent`: TranslateArg): String {
        return translate(32, 2, mapOf("amount" to asTranslateArg(`amount`), "total" to asTranslateArg(`total`), "percent" to asTranslateArg(`percent`)))
    }


    /** Button */
    fun statisticsAnswerButtonsButtonNumber(): String {
        return translate(32, 3, mapOf())
    }


    /** Times pressed */
    fun statisticsAnswerButtonsButtonPressed(): String {
        return translate(32, 4, mapOf())
    }


    /** The number of times you have pressed each button. */
    fun statisticsAnswerButtonsSubtitle(): String {
        return translate(32, 5, mapOf())
    }


    /** Answer Buttons */
    fun statisticsAnswerButtonsTitle(): String {
        return translate(32, 6, mapOf())
    }


    /** Average */
    fun statisticsAverage(): String {
        return translate(32, 7, mapOf())
    }


    /** {$average-seconds}s () */
    fun statisticsAverageAnswerTime(`averageSeconds`: Double, `cardsPerMinute`: Double): String {
        return translate(32, 8, mapOf("average-seconds" to asTranslateArg(`averageSeconds`), "cards-per-minute" to asTranslateArg(`cardsPerMinute`)))
    }


    /** Average answer time */
    fun statisticsAverageAnswerTimeLabel(): String {
        return translate(32, 9, mapOf())
    }


    /** Average difficulty */
    fun statisticsAverageDifficulty(): String {
        return translate(32, 10, mapOf())
    }


    /** Average ease */
    fun statisticsAverageEase(): String {
        return translate(32, 11, mapOf())
    }


    /** Average for days studied */
    fun statisticsAverageForDaysStudied(): String {
        return translate(32, 12, mapOf())
    }


    /** Average interval */
    fun statisticsAverageInterval(): String {
        return translate(32, 13, mapOf())
    }


    /** Average over period */
    fun statisticsAverageOverPeriod(): String {
        return translate(32, 14, mapOf())
    }


    /** Average retrievability */
    fun statisticsAverageRetrievability(): String {
        return translate(32, 15, mapOf())
    }


    /** Average stability */
    fun statisticsAverageStability(): String {
        return translate(32, 16, mapOf())
    }


    /** Backlog */
    fun statisticsBacklogCheckbox(): String {
        return translate(32, 17, mapOf())
    }


    /** Calendar */
    fun statisticsCalendarTitle(): String {
        return translate(32, 18, mapOf())
    }


    /** The higher the difficulty, the slower stability will increase. */
    fun statisticsCardDifficultySubtitle2(): String {
        return translate(32, 19, mapOf())
    }


    /** Card Difficulty */
    fun statisticsCardDifficultyTitle(): String {
        return translate(32, 20, mapOf())
    }


    /** {$cards} cards with {$percent} difficulty */
    fun statisticsCardDifficultyTooltip(`cards`: Int, `percent`: TranslateArg): String {
        return translate(32, 21, mapOf("cards" to asTranslateArg(`cards`), "percent" to asTranslateArg(`percent`)))
    }


    /** The lower the ease, the more frequently a card will appear. */
    fun statisticsCardEaseSubtitle(): String {
        return translate(32, 22, mapOf())
    }


    /** Card Ease */
    fun statisticsCardEaseTitle(): String {
        return translate(32, 23, mapOf())
    }


    /** {$cards} cards with {$percent} ease */
    fun statisticsCardEaseTooltip(`cards`: Int, `percent`: TranslateArg): String {
        return translate(32, 24, mapOf("cards" to asTranslateArg(`cards`), "percent" to asTranslateArg(`percent`)))
    }


    /** Card Retrievability */
    fun statisticsCardRetrievabilityTitle(): String {
        return translate(32, 25, mapOf())
    }


    /** The delay at which retrievability falls to 90%. */
    fun statisticsCardStabilitySubtitle(): String {
        return translate(32, 26, mapOf())
    }


    /** Card Stability */
    fun statisticsCardStabilityTitle(): String {
        return translate(32, 27, mapOf())
    }


    /** {$cards} cards */
    fun statisticsCards(`cards`: Int): String {
        return translate(32, 28, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** {$cards} cards due */
    fun statisticsCardsDue(`cards`: Int): String {
        return translate(32, 29, mapOf("cards" to asTranslateArg(`cards`)))
    }


    /** {$count} cards/day */
    fun statisticsCardsPerDay(`count`: Int): String {
        return translate(32, 30, mapOf("count" to asTranslateArg(`count`)))
    }


    /** {$cards-per-minute} cards/minute */
    fun statisticsCardsPerMin(`cardsPerMinute`: Double): String {
        return translate(32, 31, mapOf("cards-per-minute" to asTranslateArg(`cardsPerMinute`)))
    }


    /** Buried */
    fun statisticsCountsBuriedCards(): String {
        return translate(32, 32, mapOf())
    }


    /** Filtered */
    fun statisticsCountsFilteredCards(): String {
        return translate(32, 33, mapOf())
    }


    /** Learning */
    fun statisticsCountsLearningCards(): String {
        return translate(32, 34, mapOf())
    }


    /** Mature */
    fun statisticsCountsMatureCards(): String {
        return translate(32, 35, mapOf())
    }


    /** New */
    fun statisticsCountsNewCards(): String {
        return translate(32, 36, mapOf())
    }


    /** Relearning */
    fun statisticsCountsRelearningCards(): String {
        return translate(32, 37, mapOf())
    }


    /** Separate suspended/buried cards */
    fun statisticsCountsSeparateSuspendedBuriedCards(): String {
        return translate(32, 38, mapOf())
    }


    /** Suspended */
    fun statisticsCountsSuspendedCards(): String {
        return translate(32, 39, mapOf())
    }


    /** Card Counts */
    fun statisticsCountsTitle(): String {
        return translate(32, 40, mapOf())
    }


    /** Total */
    fun statisticsCountsTotalCards(): String {
        return translate(32, 41, mapOf())
    }


    /** Young */
    fun statisticsCountsYoungCards(): String {
        return translate(32, 42, mapOf())
    }


    /** Daily load */
    fun statisticsDailyLoad(): String {
        return translate(32, 43, mapOf())
    }


    /** {$daysStart}-{$daysEnd} days ago */
    fun statisticsDaysAgoRange(`daysStart`: Int, `daysEnd`: Int): String {
        return translate(32, 44, mapOf("daysStart" to asTranslateArg(`daysStart`), "daysEnd" to asTranslateArg(`daysEnd`)))
    }


    /** {$days} days ago */
    fun statisticsDaysAgoSingle(`days`: Int): String {
        return translate(32, 45, mapOf("days" to asTranslateArg(`days`)))
    }


    /** Days studied */
    fun statisticsDaysStudied(): String {
        return translate(32, 46, mapOf())
    }


    /** Due */
    fun statisticsDueCount(): String {
        return translate(32, 47, mapOf())
    }


    /** Due */
    fun statisticsDueDate(): String {
        return translate(32, 48, mapOf())
    }


    /** New #{$number} */
    fun statisticsDueForNewCard(`number`: TranslateArg): String {
        return translate(32, 49, mapOf("number" to asTranslateArg(`number`)))
    }


    /** Due tomorrow */
    fun statisticsDueTomorrow(): String {
        return translate(32, 50, mapOf())
    }


    /** {$amount}d */
    fun statisticsElapsedTimeDays(`amount`: Int): String {
        return translate(32, 51, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}h */
    fun statisticsElapsedTimeHours(`amount`: Int): String {
        return translate(32, 52, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}m */
    fun statisticsElapsedTimeMinutes(`amount`: Int): String {
        return translate(32, 53, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}mo */
    fun statisticsElapsedTimeMonths(`amount`: Int): String {
        return translate(32, 54, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}s */
    fun statisticsElapsedTimeSeconds(`amount`: Int): String {
        return translate(32, 55, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$amount}y */
    fun statisticsElapsedTimeYears(`amount`: Int): String {
        return translate(32, 56, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** Estimated total knowledge */
    fun statisticsEstimatedTotalKnowledge(): String {
        return translate(32, 57, mapOf())
    }


    /** The number of reviews due in the future. */
    fun statisticsFutureDueSubtitle(): String {
        return translate(32, 58, mapOf())
    }


    /** Future Due */
    fun statisticsFutureDueTitle(): String {
        return translate(32, 59, mapOf())
    }


    /** {$correct}/{$total} correct ({$percent}%) */
    fun statisticsHoursCorrect(`correct`: Int, `total`: Int, `percent`: TranslateArg): String {
        return translate(32, 60, mapOf("correct" to asTranslateArg(`correct`), "total" to asTranslateArg(`total`), "percent" to asTranslateArg(`percent`)))
    }


    /** → (not 'Again') */
    fun statisticsHoursCorrectInfo(): String {
        return translate(32, 61, mapOf())
    }


    /** 📈 {$percent}% correct ({$reviews}) */
    fun statisticsHoursCorrectReviews(`percent`: TranslateArg, `reviews`: Int): String {
        return translate(32, 62, mapOf("percent" to asTranslateArg(`percent`), "reviews" to asTranslateArg(`reviews`)))
    }


    /** From {$hourStart}:00~{$hourEnd}:00 */
    fun statisticsHoursRange(`hourStart`: Int, `hourEnd`: Int): String {
        return translate(32, 63, mapOf("hourStart" to asTranslateArg(`hourStart`), "hourEnd" to asTranslateArg(`hourEnd`)))
    }


    /** 📊 {$reviews} reviews */
    fun statisticsHoursReviews(`reviews`: Int): String {
        return translate(32, 64, mapOf("reviews" to asTranslateArg(`reviews`)))
    }


    /** Review success rate for each hour of the day. */
    fun statisticsHoursSubtitle(): String {
        return translate(32, 65, mapOf())
    }


    /** Hourly Breakdown */
    fun statisticsHoursTitle(): String {
        return translate(32, 66, mapOf())
    }


    /** In {$daysStart}-{$daysEnd} days */
    fun statisticsInDaysRange(`daysStart`: Int, `daysEnd`: Int): String {
        return translate(32, 67, mapOf("daysStart" to asTranslateArg(`daysStart`), "daysEnd" to asTranslateArg(`daysEnd`)))
    }


    /** In {$days} days */
    fun statisticsInDaysSingle(`days`: Int): String {
        return translate(32, 68, mapOf("days" to asTranslateArg(`days`)))
    }


    /** in {$amount} days */
    fun statisticsInTimeSpanDays(`amount`: Int): String {
        return translate(32, 69, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** in {$amount} hours */
    fun statisticsInTimeSpanHours(`amount`: Int): String {
        return translate(32, 70, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** in {$amount} minutes */
    fun statisticsInTimeSpanMinutes(`amount`: Int): String {
        return translate(32, 71, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** in {$amount} months */
    fun statisticsInTimeSpanMonths(`amount`: Int): String {
        return translate(32, 72, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** in {$amount} seconds */
    fun statisticsInTimeSpanSeconds(`amount`: Int): String {
        return translate(32, 73, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** in {$amount} years */
    fun statisticsInTimeSpanYears(`amount`: Int): String {
        return translate(32, 74, mapOf("amount" to asTranslateArg(`amount`)))
    }


    /** {$cards} cards with a {$daysStart}~{$daysEnd} day interval */
    fun statisticsIntervalsDayRange(`cards`: Int, `daysStart`: Int, `daysEnd`: Int): String {
        return translate(32, 75, mapOf("cards" to asTranslateArg(`cards`), "daysStart" to asTranslateArg(`daysStart`), "daysEnd" to asTranslateArg(`daysEnd`)))
    }


    /** {$cards} cards with a {$day} day interval */
    fun statisticsIntervalsDaySingle(`cards`: Int, `day`: TranslateArg): String {
        return translate(32, 76, mapOf("cards" to asTranslateArg(`cards`), "day" to asTranslateArg(`day`)))
    }


    /** Delays until review cards are shown again. */
    fun statisticsIntervalsSubtitle(): String {
        return translate(32, 77, mapOf())
    }


    /** Review Intervals */
    fun statisticsIntervalsTitle(): String {
        return translate(32, 78, mapOf())
    }


    /** Median difficulty */
    fun statisticsMedianDifficulty(): String {
        return translate(32, 79, mapOf())
    }


    /** Median ease */
    fun statisticsMedianEase(): String {
        return translate(32, 80, mapOf())
    }


    /** Median interval */
    fun statisticsMedianInterval(): String {
        return translate(32, 81, mapOf())
    }


    /** Median stability */
    fun statisticsMedianStability(): String {
        return translate(32, 82, mapOf())
    }


    /** {$memorized} cards memorized */
    fun statisticsMemorized(`memorized`: String): String {
        return translate(32, 83, mapOf("memorized" to asTranslateArg(`memorized`)))
    }


    /** {$count} minutes/day */
    fun statisticsMinutesPerDay(`count`: Int): String {
        return translate(32, 84, mapOf("count" to asTranslateArg(`count`)))
    }


    /** NO DATA */
    fun statisticsNoData(): String {
        return translate(32, 85, mapOf())
    }


    /** {$notes} notes */
    fun statisticsNotes(`notes`: Int): String {
        return translate(32, 86, mapOf("notes" to asTranslateArg(`notes`)))
    }


    /** last 12 months */
    fun statisticsRange1YearHistory(): String {
        return translate(32, 87, mapOf())
    }


    /** all history */
    fun statisticsRangeAllHistory(): String {
        return translate(32, 88, mapOf())
    }


    /** all */
    fun statisticsRangeAllTime(): String {
        return translate(32, 89, mapOf())
    }


    /** collection */
    fun statisticsRangeCollection(): String {
        return translate(32, 90, mapOf())
    }


    /** deck */
    fun statisticsRangeDeck(): String {
        return translate(32, 91, mapOf())
    }


    /** Search */
    fun statisticsRangeSearch(): String {
        return translate(32, 92, mapOf())
    }


    /** The probability of recalling a card today. */
    fun statisticsRetrievabilitySubtitle(): String {
        return translate(32, 93, mapOf())
    }


    /** {$cards} cards with {$percent} retrievability */
    fun statisticsRetrievabilityTooltip(`cards`: Int, `percent`: TranslateArg): String {
        return translate(32, 94, mapOf("cards" to asTranslateArg(`cards`), "percent" to asTranslateArg(`percent`)))
    }


    /** {$reviews} reviews */
    fun statisticsReviews(`reviews`: Int): String {
        return translate(32, 95, mapOf("reviews" to asTranslateArg(`reviews`)))
    }


    /** The number of questions you have answered. */
    fun statisticsReviewsCountSubtitle(): String {
        return translate(32, 96, mapOf())
    }


    /** {$count} reviews/day */
    fun statisticsReviewsPerDay(`count`: Int): String {
        return translate(32, 97, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Time */
    fun statisticsReviewsTimeCheckbox(): String {
        return translate(32, 98, mapOf())
    }


    /** The time taken to answer the questions. */
    fun statisticsReviewsTimeSubtitle(): String {
        return translate(32, 99, mapOf())
    }


    /** Reviews */
    fun statisticsReviewsTitle(): String {
        return translate(32, 100, mapOf())
    }


    /** Running total */
    fun statisticsRunningTotal(): String {
        return translate(32, 101, mapOf())
    }


    /** Save PDF */
    fun statisticsSavePdf(): String {
        return translate(32, 102, mapOf())
    }


    /** Saved. */
    fun statisticsSaved(): String {
        return translate(32, 103, mapOf())
    }


    /** {$cards} cards with a {$daysStart}~{$daysEnd} day stability */
    fun statisticsStabilityDayRange(`cards`: Int, `daysStart`: Int, `daysEnd`: Int): String {
        return translate(32, 104, mapOf("cards" to asTranslateArg(`cards`), "daysStart" to asTranslateArg(`daysStart`), "daysEnd" to asTranslateArg(`daysEnd`)))
    }


    /** {$cards} cards with a {$day} day stability */
    fun statisticsStabilityDaySingle(`cards`: Int, `day`: TranslateArg): String {
        return translate(32, 105, mapOf("cards" to asTranslateArg(`cards`), "day" to asTranslateArg(`day`)))
    }


    /** stats */
    fun statisticsStats(): String {
        return translate(32, 106, mapOf())
    }


    /** Studied 
 today
({$secs-per-card}s/card) */
    fun statisticsStudiedToday(`unit`: String, `secsPerCard`: Int, `amount`: Int, `cards`: Int): String {
        return translate(32, 107, mapOf("unit" to asTranslateArg(`unit`), "secs-per-card" to asTranslateArg(`secsPerCard`), "amount" to asTranslateArg(`amount`), "cards" to asTranslateArg(`cards`)))
    }


    /** Statistics */
    fun statisticsTitle(): String {
        return translate(32, 108, mapOf())
    }


    /** Again count: */
    fun statisticsTodayAgainCount(): String {
        return translate(32, 109, mapOf())
    }


    /** Correct answers on mature cards: {$correct}/{$total} ({$percent}%) */
    fun statisticsTodayCorrectMature(`correct`: Int, `total`: Int, `percent`: TranslateArg): String {
        return translate(32, 110, mapOf("correct" to asTranslateArg(`correct`), "total" to asTranslateArg(`total`), "percent" to asTranslateArg(`percent`)))
    }


    /** No cards have been studied today. */
    fun statisticsTodayNoCards(): String {
        return translate(32, 111, mapOf())
    }


    /** No mature cards were studied today. */
    fun statisticsTodayNoMatureCards(): String {
        return translate(32, 112, mapOf())
    }


    /** Today */
    fun statisticsTodayTitle(): String {
        return translate(32, 113, mapOf())
    }


    /** Learn: {$learnCount}, Review: {$reviewCount}, Relearn: {$relearnCount}, Filtered: {$filteredCount} */
    fun statisticsTodayTypeCounts(`learnCount`: Int, `reviewCount`: Int, `relearnCount`: Int, `filteredCount`: Int): String {
        return translate(32, 114, mapOf("learnCount" to asTranslateArg(`learnCount`), "reviewCount" to asTranslateArg(`reviewCount`), "relearnCount" to asTranslateArg(`relearnCount`), "filteredCount" to asTranslateArg(`filteredCount`)))
    }


    /** Total */
    fun statisticsTotal(): String {
        return translate(32, 115, mapOf())
    }


    /** All */
    fun statisticsTrueRetentionAll(): String {
        return translate(32, 116, mapOf())
    }


    /** All time */
    fun statisticsTrueRetentionAllTime(): String {
        return translate(32, 117, mapOf())
    }


    /** Count */
    fun statisticsTrueRetentionCount(): String {
        return translate(32, 118, mapOf())
    }


    /** Fail */
    fun statisticsTrueRetentionFail(): String {
        return translate(32, 119, mapOf())
    }


    /** Mature */
    fun statisticsTrueRetentionMature(): String {
        return translate(32, 120, mapOf())
    }


    /** Last month */
    fun statisticsTrueRetentionMonth(): String {
        return translate(32, 121, mapOf())
    }


    /** N/A */
    fun statisticsTrueRetentionNotApplicable(): String {
        return translate(32, 122, mapOf())
    }


    /** Pass */
    fun statisticsTrueRetentionPass(): String {
        return translate(32, 123, mapOf())
    }


    /** Range */
    fun statisticsTrueRetentionRange(): String {
        return translate(32, 124, mapOf())
    }


    /** Retention */
    fun statisticsTrueRetentionRetention(): String {
        return translate(32, 125, mapOf())
    }


    /** Pass rate of cards with an interval ≥ 1 day. */
    fun statisticsTrueRetentionSubtitle(): String {
        return translate(32, 126, mapOf())
    }


    /** Retention */
    fun statisticsTrueRetentionTitle(): String {
        return translate(32, 127, mapOf())
    }


    /** Today */
    fun statisticsTrueRetentionToday(): String {
        return translate(32, 128, mapOf())
    }


    /** If you are using FSRS, your retention is expected to be close to your desired retention. Please keep in mind that data for a single day is noisy, so it's better to look at monthly data. */
    fun statisticsTrueRetentionTooltip(): String {
        return translate(32, 129, mapOf())
    }


    /** Total */
    fun statisticsTrueRetentionTotal(): String {
        return translate(32, 130, mapOf())
    }


    /** Last week */
    fun statisticsTrueRetentionWeek(): String {
        return translate(32, 131, mapOf())
    }


    /** Last year */
    fun statisticsTrueRetentionYear(): String {
        return translate(32, 132, mapOf())
    }


    /** Yesterday */
    fun statisticsTrueRetentionYesterday(): String {
        return translate(32, 133, mapOf())
    }


    /** Young */
    fun statisticsTrueRetentionYoung(): String {
        return translate(32, 134, mapOf())
    }


    /** Again */
    fun studyingAgain(): String {
        return translate(33, 0, mapOf())
    }


    /** All Buried Cards */
    fun studyingAllBuriedCards(): String {
        return translate(33, 1, mapOf())
    }


    /** Answer time elapsed */
    fun studyingAnswerTimeElapsed(): String {
        return translate(33, 2, mapOf())
    }


    /** Audio -5s */
    fun studyingAudio5s(): String {
        return translate(33, 3, mapOf())
    }


    /** Audio +5s */
    fun studyingAudioAnd5s(): String {
        return translate(33, 4, mapOf())
    }


    /** Buried Siblings */
    fun studyingBuriedSiblings(): String {
        return translate(33, 5, mapOf())
    }


    /** Bury */
    fun studyingBury(): String {
        return translate(33, 6, mapOf())
    }


    /** Bury Card */
    fun studyingBuryCard(): String {
        return translate(33, 7, mapOf())
    }


    /** Bury Note */
    fun studyingBuryNote(): String {
        return translate(33, 8, mapOf())
    }


    /** {$count} cards studied in */
    fun studyingCardStudiedIn(`count`: Int): String {
        return translate(33, 9, mapOf("count" to asTranslateArg(`count`)))
    }


    /** {$cards} cards studied in
{$minutes} minutes. */
    fun studyingCardStudiedInMinute(`cards`: Int, `minutes`: String): String {
        return translate(33, 10, mapOf("cards" to asTranslateArg(`cards`), "minutes" to asTranslateArg(`minutes`)))
    }


    /** Card suspended. */
    fun studyingCardSuspended(): String {
        return translate(33, 11, mapOf())
    }


    /** Card was a leech. */
    fun studyingCardWasALeech(): String {
        return translate(33, 12, mapOf())
    }


    /** {$count} cards buried. */
    fun studyingCardsBuried(`count`: Int): String {
        return translate(33, 13, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Cards will be automatically returned to their original decks after you review them. */
    fun studyingCardsWillBeAutomaticallyReturnedTo(): String {
        return translate(33, 14, mapOf())
    }


    /** Continue */
    fun studyingContinue(): String {
        return translate(33, 15, mapOf())
    }


    /** Counts differ from the deck list, because burying is enabled. Some cards have been excluded, and others may have taken their place. */
    fun studyingCountsDiffer(): String {
        return translate(33, 16, mapOf())
    }


    /** Delete Note */
    fun studyingDeleteNote(): String {
        return translate(33, 17, mapOf())
    }


    /** Deleting this deck from the deck list will return all remaining cards to their original deck. */
    fun studyingDeletingThisDeckFromTheDeck(): String {
        return translate(33, 18, mapOf())
    }


    /** Easy */
    fun studyingEasy(): String {
        return translate(33, 19, mapOf())
    }


    /** Edit */
    fun studyingEdit(): String {
        return translate(33, 20, mapOf())
    }


    /** Empty */
    fun studyingEmpty(): String {
        return translate(33, 21, mapOf())
    }


    /** Finish */
    fun studyingFinish(): String {
        return translate(33, 22, mapOf())
    }


    /** Flag Card */
    fun studyingFlagCard(): String {
        return translate(33, 23, mapOf())
    }


    /** Good */
    fun studyingGood(): String {
        return translate(33, 24, mapOf())
    }


    /** Hard */
    fun studyingHard(): String {
        return translate(33, 25, mapOf())
    }


    /** It has been suspended. */
    fun studyingItHasBeenSuspended(): String {
        return translate(33, 26, mapOf())
    }


    /** Manually Buried Cards */
    fun studyingManuallyBuriedCards(): String {
        return translate(33, 27, mapOf())
    }


    /** Mark Note */
    fun studyingMarkNote(): String {
        return translate(33, 28, mapOf())
    }


    /** {$count} minutes. */
    fun studyingMinute(`count`: Int): String {
        return translate(33, 29, mapOf("count" to asTranslateArg(`count`)))
    }


    /** More */
    fun studyingMore(): String {
        return translate(33, 30, mapOf())
    }


    /** No cards are due yet. */
    fun studyingNoCardsAreDueYet(): String {
        return translate(33, 31, mapOf())
    }


    /** Note suspended. */
    fun studyingNoteSuspended(): String {
        return translate(33, 32, mapOf())
    }


    /** Pause Audio */
    fun studyingPauseAudio(): String {
        return translate(33, 33, mapOf())
    }


    /** Please run Tools>Empty Cards */
    fun studyingPleaseRunToolsemptyCards(): String {
        return translate(33, 34, mapOf())
    }


    /** Question time elapsed */
    fun studyingQuestionTimeElapsed(): String {
        return translate(33, 35, mapOf())
    }


    /** Record Own Voice */
    fun studyingRecordOwnVoice(): String {
        return translate(33, 36, mapOf())
    }


    /** Replay Own Voice */
    fun studyingReplayOwnVoice(): String {
        return translate(33, 37, mapOf())
    }


    /** Show Answer */
    fun studyingShowAnswer(): String {
        return translate(33, 38, mapOf())
    }


    /** Space */
    fun studyingSpace(): String {
        return translate(33, 39, mapOf())
    }


    /** Study Now */
    fun studyingStudyNow(): String {
        return translate(33, 40, mapOf())
    }


    /** Suspend */
    fun studyingSuspend(): String {
        return translate(33, 41, mapOf())
    }


    /** Suspend Note */
    fun studyingSuspendNote(): String {
        return translate(33, 42, mapOf())
    }


    /** This is a special deck for studying outside of the normal schedule. */
    fun studyingThisIsASpecialDeckFor(): String {
        return translate(33, 43, mapOf())
    }


    /** To Review */
    fun studyingToReview(): String {
        return translate(33, 44, mapOf())
    }


    /** Type answer: unknown field {$val} */
    fun studyingTypeAnswerUnknownField(`val`: TranslateArg): String {
        return translate(33, 45, mapOf("val" to asTranslateArg(`val`)))
    }


    /** Unbury */
    fun studyingUnbury(): String {
        return translate(33, 46, mapOf())
    }


    /** What would you like to unbury? */
    fun studyingWhatWouldYouLikeToUnbury(): String {
        return translate(33, 47, mapOf())
    }


    /** You haven't recorded your voice yet. */
    fun studyingYouHaventRecordedYourVoiceYet(): String {
        return translate(33, 48, mapOf())
    }


    /** Abort */
    fun syncAbortButton(): String {
        return translate(34, 0, mapOf())
    }


    /** <h1>Account Required</h1>
A free account is required to keep your collection synchronized. Please <a href="{$link}">sign up</a> for an account, then enter your details below. */
    fun syncAccountRequired(`link`: String): String {
        return translate(34, 1, mapOf("link" to asTranslateArg(`link`)))
    }


    /** Added/modified: {$up}↑ {$down}↓ */
    fun syncAddedUpdatedCount(`up`: TranslateArg, `down`: TranslateArg): String {
        return translate(34, 2, mapOf("up" to asTranslateArg(`up`), "down" to asTranslateArg(`down`)))
    }


    /** AnkiHub Add-on Installation */
    fun syncAnkihubAddonInstallation(): String {
        return translate(34, 3, mapOf())
    }


    /** AnkiHub Login */
    fun syncAnkihubDialogHeading(): String {
        return translate(34, 4, mapOf())
    }


    /** Unable to log in to AnkiHub with the provided credentials. */
    fun syncAnkihubLoginFailed(): String {
        return translate(34, 5, mapOf())
    }


    /** Username or Email: */
    fun syncAnkihubUsernameLabel(): String {
        return translate(34, 6, mapOf())
    }


    /** Email: */
    fun syncAnkiwebIdLabel(): String {
        return translate(34, 7, mapOf())
    }


    /** Cancel */
    fun syncCancelButton(): String {
        return translate(34, 8, mapOf())
    }


    /** Checking... */
    fun syncChecking(): String {
        return translate(34, 9, mapOf())
    }


    /** Your Anki version is too old. Please update to the latest version to continue syncing. */
    fun syncClientTooOld(): String {
        return translate(34, 10, mapOf())
    }


    /** Unable to sync - your clock is not set to the correct time. */
    fun syncClockOff(): String {
        return translate(34, 11, mapOf())
    }


    /** Collection sync complete. */
    fun syncCollectionComplete(): String {
        return translate(34, 12, mapOf())
    }


    /** Local collection has no cards. Download from AnkiWeb? */
    fun syncConfirmEmptyDownload(): String {
        return translate(34, 13, mapOf())
    }


    /** AnkiWeb collection has no cards. Replace it with local collection? */
    fun syncConfirmEmptyUpload(): String {
        return translate(34, 14, mapOf())
    }


    /** Only one copy of Anki can sync to your account at once. Please wait a few minutes, then try again. */
    fun syncConflict(): String {
        return translate(34, 15, mapOf())
    }


    /** Your decks here and on AnkiWeb differ in such a way that they can't be merged together, so it's necessary to overwrite the decks on one side with the decks from the other.

If you choose download, Anki will fetch the collection from AnkiWeb, and any changes you have made on this device since the last sync will be lost.

If you choose upload, Anki will send this device's data to AnkiWeb, and any changes that are waiting on AnkiWeb will be lost.

After all devices are in sync, future reviews and added cards can be merged automatically. */
    fun syncConflictExplanation(): String {
        return translate(34, 16, mapOf())
    }


    /** There is a conflict between decks on this device and AnkiWeb. You must choose which version to keep:

- Select **** to replace decks here with AnkiWeb’s version. You will lose any changes you made on this device since your last sync.
- Select **** to overwrite AnkiWeb’s versions with decks from this device, and delete any changes on AnkiWeb.

Once the conflict is resolved, syncing will work as usual. */
    fun syncConflictExplanation2(): String {
        return translate(34, 17, mapOf())
    }


    /** Connecting... */
    fun syncConnecting(): String {
        return translate(34, 18, mapOf())
    }


    /** Download from AnkiWeb */
    fun syncDownloadFromAnkiweb(): String {
        return translate(34, 19, mapOf())
    }


    /** Downloading from AnkiWeb... */
    fun syncDownloadingFromAnkiweb(): String {
        return translate(34, 20, mapOf())
    }


    /** Log In */
    fun syncLogInButton(): String {
        return translate(34, 21, mapOf())
    }


    /** Log Out */
    fun syncLogOutButton(): String {
        return translate(34, 22, mapOf())
    }


    /** Media sync aborted. */
    fun syncMediaAborted(): String {
        return translate(34, 23, mapOf())
    }


    /** Media sync aborting... */
    fun syncMediaAborting(): String {
        return translate(34, 24, mapOf())
    }


    /** Added: {$up}↑ {$down}↓ */
    fun syncMediaAddedCount(`up`: TranslateArg, `down`: TranslateArg): String {
        return translate(34, 25, mapOf("up" to asTranslateArg(`up`), "down" to asTranslateArg(`down`)))
    }


    /** Checked: {$count} */
    fun syncMediaCheckedCount(`count`: Int): String {
        return translate(34, 26, mapOf("count" to asTranslateArg(`count`)))
    }


    /** Media sync complete. */
    fun syncMediaComplete(): String {
        return translate(34, 27, mapOf())
    }


    /** Media sync disabled. */
    fun syncMediaDisabled(): String {
        return translate(34, 28, mapOf())
    }


    /** Media sync failed. */
    fun syncMediaFailed(): String {
        return translate(34, 29, mapOf())
    }


    /** Media Log */
    fun syncMediaLogButton(): String {
        return translate(34, 30, mapOf())
    }


    /** Media Sync Log */
    fun syncMediaLogTitle(): String {
        return translate(34, 31, mapOf())
    }


    /** Removed: {$up}↑ {$down}↓ */
    fun syncMediaRemovedCount(`up`: TranslateArg, `down`: TranslateArg): String {
        return translate(34, 32, mapOf("up" to asTranslateArg(`up`), "down" to asTranslateArg(`down`)))
    }


    /** Media sync starting... */
    fun syncMediaStarting(): String {
        return translate(34, 33, mapOf())
    }


    /** Anki is currently syncing. Please wait for the sync to complete, then try again. */
    fun syncMustWaitForEnd(): String {
        return translate(34, 34, mapOf())
    }


    /** Password: */
    fun syncPasswordLabel(): String {
        return translate(34, 35, mapOf())
    }


    /** Please sync again. If this message keeps appearing, please post on the support site. */
    fun syncResyncRequired(): String {
        return translate(34, 36, mapOf())
    }


    /** Please use the Check Database function, then sync again. If problems persist, please force a one-way sync in the preferences screen. */
    fun syncSanityCheckFailed(): String {
        return translate(34, 37, mapOf())
    }


    /** AnkiWeb encountered a problem. Please try again in a few minutes. */
    fun syncServerError(): String {
        return translate(34, 38, mapOf())
    }


    /** Sign in */
    fun syncSignIn(): String {
        return translate(34, 39, mapOf())
    }


    /** Syncing... */
    fun syncSyncing(): String {
        return translate(34, 40, mapOf())
    }


    /** Upload to AnkiWeb */
    fun syncUploadToAnkiweb(): String {
        return translate(34, 41, mapOf())
    }


    /** Your collection file is too large to send to AnkiWeb. You can reduce its size by removing any unwanted decks (optionally exporting them first), and then using Check Database to shrink the file size down.

{$details} (uncompressed) */
    fun syncUploadTooLarge(`details`: String): String {
        return translate(34, 42, mapOf("details" to asTranslateArg(`details`)))
    }


    /** Uploading to AnkiWeb... */
    fun syncUploadingToAnkiweb(): String {
        return translate(34, 43, mapOf())
    }


    /** Email or password was incorrect; please try again. */
    fun syncWrongPass(): String {
        return translate(34, 44, mapOf())
    }


    /** {$action} redone */
    fun undoActionRedone(`action`: String): String {
        return translate(35, 0, mapOf("action" to asTranslateArg(`action`)))
    }


    /** {$action} undone */
    fun undoActionUndone(`action`: String): String {
        return translate(35, 1, mapOf("action" to asTranslateArg(`action`)))
    }


    /** Redo */
    fun undoRedo(): String {
        return translate(35, 2, mapOf())
    }


    /** Redo {$action} */
    fun undoRedoAction(`action`: String): String {
        return translate(35, 3, mapOf("action" to asTranslateArg(`action`)))
    }


    /** Undo */
    fun undoUndo(): String {
        return translate(35, 4, mapOf())
    }


    /** Undo {$val} */
    fun undoUndoAction(`val`: TranslateArg): String {
        return translate(35, 5, mapOf("val" to asTranslateArg(`val`)))
    }

}

/** Note: This class is used for tooling and should not be used directly */
object PreviewTranslations : GeneratedTranslations {
    override fun translate(module: Int, translation: Int, args: Map<String, TranslateArgValue>): String = "Unused"


    /** A big thanks to all the people who have provided suggestions, bug reports and donations. */
    override fun aboutABigThanksToAllThe(): String {
        return """A big thanks to all the people who have provided suggestions, bug reports and donations."""
    }


    /** About Anki */
    override fun aboutAboutAnki(): String {
        return """About Anki"""
    }


    /** and others */
    override fun aboutAndOthers(): String {
        return """and others"""
    }


    /** Anki is a friendly, intelligent spaced learning system. It's free and open source. */
    override fun aboutAnkiIsAFriendlyIntelligentSpaced(): String {
        return """Anki is a friendly, intelligent spaced learning system. It's free and open source."""
    }


    /** Anki is licensed under the AGPL3 license. Please see the license file in the source distribution for more information. */
    override fun aboutAnkiIsLicensedUnderTheAgpl3(): String {
        return """Anki is licensed under the AGPL3 license. Please see the license file in the source distribution for more information."""
    }


    /** Copied to clipboard */
    override fun aboutCopiedToClipboard(): String {
        return """Copied to clipboard"""
    }


    /** Copy Debug Info */
    override fun aboutCopyDebugInfo(): String {
        return """Copy Debug Info"""
    }


    /** If you have contributed and are not on this list, please get in touch. */
    override fun aboutIfYouHaveContributedAndAre(): String {
        return """If you have contributed and are not on this list, please get in touch."""
    }


    /** Version {$val} */
    override fun aboutVersion(`val`: TranslateArg): String {
        return """Version ${`val`}"""
    }


    /** <a href='{$val}'>Visit website</a> */
    override fun aboutVisitWebsite(`val`: TranslateArg): String {
        return """<a href='${`val`}'>Visit website</a>"""
    }


    /** Written by Damien Elmes, with patches, translation,    testing and design from:<p>{$cont} */
    override fun aboutWrittenByDamienElmesWithPatches(`cont`: String): String {
        return """Written by Damien Elmes, with patches, translation,    testing and design from:<p>${`cont`}"""
    }


    /** Add */
    override fun actionsAdd(): String {
        return """Add"""
    }


    /** Add Deck */
    override fun actionsAddDeck(): String {
        return """Add Deck"""
    }


    /** Add Note */
    override fun actionsAddNote(): String {
        return """Add Note"""
    }


    /** Add Note Type */
    override fun actionsAddNotetype(): String {
        return """Add Note Type"""
    }


    /** All selected */
    override fun actionsAllSelected(): String {
        return """All selected"""
    }


    /** Answer Card */
    override fun actionsAnswerCard(): String {
        return """Answer Card"""
    }


    /** Any selected */
    override fun actionsAnySelected(): String {
        return """Any selected"""
    }


    /** Auto Advance */
    override fun actionsAutoAdvance(): String {
        return """Auto Advance"""
    }


    /** Auto Advance enabled */
    override fun actionsAutoAdvanceActivated(): String {
        return """Auto Advance enabled"""
    }


    /** Auto Advance disabled */
    override fun actionsAutoAdvanceDeactivated(): String {
        return """Auto Advance disabled"""
    }


    /** Build Deck */
    override fun actionsBuildFilteredDeck(): String {
        return """Build Deck"""
    }


    /** Cancel */
    override fun actionsCancel(): String {
        return """Cancel"""
    }


    /** Card Info */
    override fun actionsCardInfo(): String {
        return """Card Info"""
    }


    /** Choose */
    override fun actionsChoose(): String {
        return """Choose"""
    }


    /** Close */
    override fun actionsClose(): String {
        return """Close"""
    }


    /** Copy */
    override fun actionsCopy(): String {
        return """Copy"""
    }


    /** Create Copy */
    override fun actionsCreateCopy(): String {
        return """Create Copy"""
    }


    /** Custom Study */
    override fun actionsCustomStudy(): String {
        return """Custom Study"""
    }


    /** Decks */
    override fun actionsDecks(): String {
        return """Decks"""
    }


    /** Decrement value */
    override fun actionsDecrementValue(): String {
        return """Decrement value"""
    }


    /** Delete */
    override fun actionsDelete(): String {
        return """Delete"""
    }


    /** Discard */
    override fun actionsDiscard(): String {
        return """Discard"""
    }


    /** Empty Cards */
    override fun actionsEmptyCards(): String {
        return """Empty Cards"""
    }


    /** Export */
    override fun actionsExport(): String {
        return """Export"""
    }


    /** Filter */
    override fun actionsFilter(): String {
        return """Filter"""
    }


    /** Blue */
    override fun actionsFlagBlue(): String {
        return """Blue"""
    }


    /** Green */
    override fun actionsFlagGreen(): String {
        return """Green"""
    }


    /** Flag {$number} */
    override fun actionsFlagNumber(`number`: TranslateArg): String {
        return """Flag ${`number`}"""
    }


    /** Orange */
    override fun actionsFlagOrange(): String {
        return """Orange"""
    }


    /** Pink */
    override fun actionsFlagPink(): String {
        return """Pink"""
    }


    /** Purple */
    override fun actionsFlagPurple(): String {
        return """Purple"""
    }


    /** Red */
    override fun actionsFlagRed(): String {
        return """Red"""
    }


    /** Turquoise */
    override fun actionsFlagTurquoise(): String {
        return """Turquoise"""
    }


    /** Reset Card */
    override fun actionsForgetCard(): String {
        return """Reset Card"""
    }


    /** Full screen mode is not supported for your video driver. Try switching to a different one from the preferences screen. */
    override fun actionsFullscreenUnsupported(): String {
        return """Full screen mode is not supported for your video driver. Try switching to a different one from the preferences screen."""
    }


    /** Grade Now */
    override fun actionsGradeNow(): String {
        return """Grade Now"""
    }


    /** Help */
    override fun actionsHelp(): String {
        return """Help"""
    }


    /** Import */
    override fun actionsImport(): String {
        return """Import"""
    }


    /** Increment value */
    override fun actionsIncrementValue(): String {
        return """Increment value"""
    }


    /** Manage... */
    override fun actionsManage(): String {
        return """Manage..."""
    }


    /** Name: */
    override fun actionsName(): String {
        return """Name:"""
    }


    /** New */
    override fun actionsNew(): String {
        return """New"""
    }


    /** New name: */
    override fun actionsNewName(): String {
        return """New name:"""
    }


    /** Nothing to redo */
    override fun actionsNothingToRedo(): String {
        return """Nothing to redo"""
    }


    /** Nothing to undo */
    override fun actionsNothingToUndo(): String {
        return """Nothing to undo"""
    }


    /** Options */
    override fun actionsOptions(): String {
        return """Options"""
    }


    /** Options for {$val} */
    override fun actionsOptionsFor(`val`: TranslateArg): String {
        return """Options for ${`val`}"""
    }


    /** Preview */
    override fun actionsPreview(): String {
        return """Preview"""
    }


    /** Previous Card Info */
    override fun actionsPreviousCardInfo(): String {
        return """Previous Card Info"""
    }


    /** Processing... */
    override fun actionsProcessing(): String {
        return """Processing..."""
    }


    /** Rebuild */
    override fun actionsRebuild(): String {
        return """Rebuild"""
    }


    /** Remove Note Type */
    override fun actionsRemoveNotetype(): String {
        return """Remove Note Type"""
    }


    /** Remove Tag */
    override fun actionsRemoveTag(): String {
        return """Remove Tag"""
    }


    /** Rename */
    override fun actionsRename(): String {
        return """Rename"""
    }


    /** Rename Deck */
    override fun actionsRenameDeck(): String {
        return """Rename Deck"""
    }


    /** Rename Tag */
    override fun actionsRenameTag(): String {
        return """Rename Tag"""
    }


    /** Rename with Parents */
    override fun actionsRenameWithParents(): String {
        return """Rename with Parents"""
    }


    /** Replay Audio */
    override fun actionsReplayAudio(): String {
        return """Replay Audio"""
    }


    /** Reposition */
    override fun actionsReposition(): String {
        return """Reposition"""
    }


    /** Save */
    override fun actionsSave(): String {
        return """Save"""
    }


    /** Search */
    override fun actionsSearch(): String {
        return """Search"""
    }


    /** Select */
    override fun actionsSelect(): String {
        return """Select"""
    }


    /** Set Due Date */
    override fun actionsSetDueDate(): String {
        return """Set Due Date"""
    }


    /** Set Flag */
    override fun actionsSetFlag(): String {
        return """Set Flag"""
    }


    /** Shortcut key: {$val} */
    override fun actionsShortcutKey(`val`: TranslateArg): String {
        return """Shortcut key: ${`val`}"""
    }


    /** Suspend Card */
    override fun actionsSuspendCard(): String {
        return """Suspend Card"""
    }


    /** Toggle Load Balancer */
    override fun actionsToggleLoadBalancer(): String {
        return """Toggle Load Balancer"""
    }


    /** Unbury/Unsuspend */
    override fun actionsUnburyUnsuspend(): String {
        return """Unbury/Unsuspend"""
    }


    /** Update Card */
    override fun actionsUpdateCard(): String {
        return """Update Card"""
    }


    /** Update Config */
    override fun actionsUpdateConfig(): String {
        return """Update Config"""
    }


    /** Update Deck */
    override fun actionsUpdateDeck(): String {
        return """Update Deck"""
    }


    /** Update Note */
    override fun actionsUpdateNote(): String {
        return """Update Note"""
    }


    /** Update Note Type */
    override fun actionsUpdateNotetype(): String {
        return """Update Note Type"""
    }


    /** Update Tag */
    override fun actionsUpdateTag(): String {
        return """Update Tag"""
    }


    /** {$action}... */
    override fun actionsWithEllipsis(`action`: String): String {
        return """${`action`}..."""
    }


    /** Add (shortcut: ctrl+enter) */
    override fun addingAddShortcutCtrlandenter(): String {
        return """Add (shortcut: ctrl+enter)"""
    }


    /** Added */
    override fun addingAdded(): String {
        return """Added"""
    }


    /** Cloze deletion can only be used in fields which use the 'cloze:' filter. This is typically the first field. */
    override fun addingClozeOutsideClozeField(): String {
        return """Cloze deletion can only be used in fields which use the 'cloze:' filter. This is typically the first field."""
    }


    /** Cloze deletion can only be used on cloze note types. */
    override fun addingClozeOutsideClozeNotetype(): String {
        return """Cloze deletion can only be used on cloze note types."""
    }


    /** Discard current input? */
    override fun addingDiscardCurrentInput(): String {
        return """Discard current input?"""
    }


    /** Edit "{$val}" */
    override fun addingEdit(`val`: TranslateArg): String {
        return """Edit "${`val`}""""
    }


    /** History */
    override fun addingHistory(): String {
        return """History"""
    }


    /** Keep Editing */
    override fun addingKeepEditing(): String {
        return """Keep Editing"""
    }


    /** (Note deleted) */
    override fun addingNoteDeleted(): String {
        return """(Note deleted)"""
    }


    /** Shortcut: {$val} */
    override fun addingShortcut(`val`: TranslateArg): String {
        return """Shortcut: ${`val`}"""
    }


    /** The first field is empty. */
    override fun addingTheFirstFieldIsEmpty(): String {
        return """The first field is empty."""
    }


    /** You have a cloze note type but have not made any cloze deletions. Proceed? */
    override fun addingYouHaveAClozeDeletionNote(): String {
        return """You have a cloze note type but have not made any cloze deletions. Proceed?"""
    }


    /** Add-on has no configuration. */
    override fun addonsAddonHasNoConfiguration(): String {
        return """Add-on has no configuration."""
    }


    /** Add-on installation error */
    override fun addonsAddonInstallationError(): String {
        return """Add-on installation error"""
    }


    /** Browse Add-ons */
    override fun addonsBrowseAddons(): String {
        return """Browse Add-ons"""
    }


    /** Changes will take effect when Anki is restarted. */
    override fun addonsChangesWillTakeEffectWhenAnki(): String {
        return """Changes will take effect when Anki is restarted."""
    }


    /** Check for Updates */
    override fun addonsCheckForUpdates(): String {
        return """Check for Updates"""
    }


    /** Checking... */
    override fun addonsChecking(): String {
        return """Checking..."""
    }


    /** Update All */
    override fun addonsChooseUpdateUpdateAll(): String {
        return """Update All"""
    }


    /** Update Add-ons */
    override fun addonsChooseUpdateWindowTitle(): String {
        return """Update Add-ons"""
    }


    /** Code: */
    override fun addonsCode(): String {
        return """Code:"""
    }


    /** Config */
    override fun addonsConfig(): String {
        return """Config"""
    }


    /** There was a problem with the provided configuration: {$problem}, at path {$path}, against schema {$schema}. */
    override fun addonsConfigValidationError(`problem`: String, `path`: String, `schema`: String): String {
        return """There was a problem with the provided configuration: ${`problem`}, at path ${`path`}, against schema ${`schema`}."""
    }


    /** Configure '{$name}' */
    override fun addonsConfigWindowTitle(`name`: String): String {
        return """Configure '${`name`}'"""
    }


    /** Configuration */
    override fun addonsConfiguration(): String {
        return """Configuration"""
    }


    /** Corrupt add-on file. */
    override fun addonsCorruptAddonFile(): String {
        return """Corrupt add-on file."""
    }


    /** Delete the {$count} selected add-ons? */
    override fun addonsDeleteTheNumdSelectedAddon(`count`: Int): String {
        return """Delete the ${`count`} selected add-ons?"""
    }


    /** (disabled) */
    override fun addonsDisabled(): String {
        return """(disabled)"""
    }


    /** (disabled) */
    override fun addonsDisabled2(): String {
        return """(disabled)"""
    }


    /** Download complete. Please restart Anki to apply changes. */
    override fun addonsDownloadCompletePleaseRestartAnkiTo(): String {
        return """Download complete. Please restart Anki to apply changes."""
    }


    /** Downloaded {$fname} */
    override fun addonsDownloadedFnames(`fname`: String): String {
        return """Downloaded ${`fname`}"""
    }


    /** Downloading {$part}/{$total} ({$kilobytes}KB)... */
    override fun addonsDownloadingAdbdKb02fkb(`part`: TranslateArg, `total`: Int, `kilobytes`: Int): String {
        return """Downloading ${`part`}/${`total`} (${`kilobytes`}KB)..."""
    }


    /** Error downloading <i>{$id}</i>: {$error} */
    override fun addonsErrorDownloadingIdsErrors(`id`: String, `error`: String): String {
        return """Error downloading <i>${`id`}</i>: ${`error`}"""
    }


    /** Error installing <i>{$base}</i>: {$error} */
    override fun addonsErrorInstallingBasesErrors(`base`: String, `error`: String): String {
        return """Error installing <i>${`base`}</i>: ${`error`}"""
    }


    /** An add-on you installed failed to load. If problems persist, please go to the Tools>Add-ons menu, and disable or delete the add-on.

When loading '{$name}':
{$traceback} */
    override fun addonsFailedToLoad(`name`: String, `traceback`: String): String {
        return """An add-on you installed failed to load. If problems persist, please go to the Tools>Add-ons menu, and disable or delete the add-on.

When loading '${`name`}':
${`traceback`}"""
    }


    /** The following add-ons failed to load:
{$addons}

They may need to be updated to support this version of Anki. Click the  button
to see if any updates are available.

You can use the  button to get information that you can paste in a report to
the add-on author.

For add-ons that don't have an update available, you can disable or delete the add-on to prevent this
message from appearing. */
    override fun addonsFailedToLoad2(`addons`: String): String {
        return """The following add-ons failed to load:
${`addons`}

They may need to be updated to support this version of Anki. Click the  button
to see if any updates are available.

You can use the  button to get information that you can paste in a report to
the add-on author.

For add-ons that don't have an update available, you can disable or delete the add-on to prevent this
message from appearing."""
    }


    /** Get Add-ons... */
    override fun addonsGetAddons(): String {
        return """Get Add-ons..."""
    }


    /** <b>Important</b>: As add-ons are programs downloaded from the internet, they are potentially malicious.<b>You should only install add-ons you trust.</b><br><br>Are you sure you want to proceed with the installation of the following Anki add-on(s)?<br><br>%(names)s */
    override fun addonsImportantAsAddonsAreProgramsDownloaded(): String {
        return """<b>Important</b>: As add-ons are programs downloaded from the internet, they are potentially malicious.<b>You should only install add-ons you trust.</b><br><br>Are you sure you want to proceed with the installation of the following Anki add-on(s)?<br><br>%(names)s"""
    }


    /** Install Add-on */
    override fun addonsInstallAddon(): String {
        return """Install Add-on"""
    }


    /** Install Add-on(s) */
    override fun addonsInstallAddons(): String {
        return """Install Add-on(s)"""
    }


    /** Install Anki add-on */
    override fun addonsInstallAnkiAddon(): String {
        return """Install Anki add-on"""
    }


    /** Install from file... */
    override fun addonsInstallFromFile(): String {
        return """Install from file..."""
    }


    /** Installation complete */
    override fun addonsInstallationComplete(): String {
        return """Installation complete"""
    }


    /** Installed {$name} */
    override fun addonsInstalledNames(`name`: String): String {
        return """Installed ${`name`}"""
    }


    /** Installed successfully. */
    override fun addonsInstalledSuccessfully(): String {
        return """Installed successfully."""
    }


    /** Invalid add-on manifest. */
    override fun addonsInvalidAddonManifest(): String {
        return """Invalid add-on manifest."""
    }


    /** Invalid code. */
    override fun addonsInvalidCode(): String {
        return """Invalid code."""
    }


    /** Invalid code, or add-on not available for your version of Anki. */
    override fun addonsInvalidCodeOrAddonNotAvailable(): String {
        return """Invalid code, or add-on not available for your version of Anki."""
    }


    /** Invalid configuration: */
    override fun addonsInvalidConfiguration(): String {
        return """Invalid configuration:"""
    }


    /** Invalid configuration: top level object must be a map */
    override fun addonsInvalidConfigurationTopLevelObjectMust(): String {
        return """Invalid configuration: top level object must be a map"""
    }


    /** No updates available. */
    override fun addonsNoUpdatesAvailable(): String {
        return """No updates available."""
    }


    /** One or more errors occurred: */
    override fun addonsOneOrMoreErrorsOccurred(): String {
        return """One or more errors occurred:"""
    }


    /** Packaged Anki Add-on */
    override fun addonsPackagedAnkiAddon(): String {
        return """Packaged Anki Add-on"""
    }


    /** Please check your internet connection. */
    override fun addonsPleaseCheckYourInternetConnection(): String {
        return """Please check your internet connection."""
    }


    /** Please report this to the respective add-on author(s). */
    override fun addonsPleaseReportThisToTheRespective(): String {
        return """Please report this to the respective add-on author(s)."""
    }


    /** <b>Please restart Anki to complete the installation.</b> */
    override fun addonsPleaseRestartAnkiToCompleteThe(): String {
        return """<b>Please restart Anki to complete the installation.</b>"""
    }


    /** Please select a single add-on first. */
    override fun addonsPleaseSelectASingleAddonFirst(): String {
        return """Please select a single add-on first."""
    }


    /** Add-ons possibly involved: {$addons} */
    override fun addonsPossiblyInvolved(`addons`: String): String {
        return """Add-ons possibly involved: ${`addons`}"""
    }


    /** (requires {$val}) */
    override fun addonsRequires(`val`: TranslateArg): String {
        return """(requires ${`val`})"""
    }


    /** Restored defaults */
    override fun addonsRestoredDefaults(): String {
        return """Restored defaults"""
    }


    /** Add-on Startup Failed */
    override fun addonsStartupFailed(): String {
        return """Add-on Startup Failed"""
    }


    /** The following add-ons are incompatible with {$name} and have been disabled: {$found} */
    override fun addonsTheFollowingAddonsAreIncompatibleWith(`name`: String, `found`: TranslateArg): String {
        return """The following add-ons are incompatible with ${`name`} and have been disabled: ${`found`}"""
    }


    /** The following add-ons have updates available. Install them now? */
    override fun addonsTheFollowingAddonsHaveUpdatesAvailable(): String {
        return """The following add-ons have updates available. Install them now?"""
    }


    /** The following conflicting add-ons were disabled: */
    override fun addonsTheFollowingConflictingAddonsWereDisabled(): String {
        return """The following conflicting add-ons were disabled:"""
    }


    /** This add-on is not compatible with your version of Anki. */
    override fun addonsThisAddonIsNotCompatibleWith(): String {
        return """This add-on is not compatible with your version of Anki."""
    }


    /** To browse add-ons, please click the browse button below.<br><br>When you've found an add-on you like, please paste its code below. You can paste multiple codes, separated by spaces. */
    override fun addonsToBrowseAddonsPleaseClickThe(): String {
        return """To browse add-ons, please click the browse button below.<br><br>When you've found an add-on you like, please paste its code below. You can paste multiple codes, separated by spaces."""
    }


    /** Toggle Enabled */
    override fun addonsToggleEnabled(): String {
        return """Toggle Enabled"""
    }


    /** Unable to update or delete add-on. Please start Anki while holding down the shift key to temporarily disable add-ons, then try again.  Debug info: {$val} */
    override fun addonsUnableToUpdateOrDeleteAddon(`val`: TranslateArg): String {
        return """Unable to update or delete add-on. Please start Anki while holding down the shift key to temporarily disable add-ons, then try again.  Debug info: ${`val`}"""
    }


    /** Unknown error: {$val} */
    override fun addonsUnknownError(`val`: TranslateArg): String {
        return """Unknown error: ${`val`}"""
    }


    /** View Add-on Page */
    override fun addonsViewAddonPage(): String {
        return """View Add-on Page"""
    }


    /** View Files */
    override fun addonsViewFiles(): String {
        return """View Files"""
    }


    /** Add-ons */
    override fun addonsWindowTitle(): String {
        return """Add-ons"""
    }


    /** Add Notes... */
    override fun browsingAddNotes(): String {
        return """Add Notes..."""
    }


    /** Add Tags... */
    override fun browsingAddTags2(): String {
        return """Add Tags..."""
    }


    /** Add to Selected Notes */
    override fun browsingAddToSelectedNotes(): String {
        return """Add to Selected Notes"""
    }


    /** Added */
    override fun browsingAddedToday(): String {
        return """Added"""
    }


    /** Add-on */
    override fun browsingAddon(): String {
        return """Add-on"""
    }


    /** Again */
    override fun browsingAgainToday(): String {
        return """Again"""
    }


    /** All Fields */
    override fun browsingAllFields(): String {
        return """All Fields"""
    }


    /** Answer */
    override fun browsingAnswer(): String {
        return """Answer"""
    }


    /** Any Flag */
    override fun browsingAnyFlag(): String {
        return """Any Flag"""
    }


    /** Avg. Ease */
    override fun browsingAverageEase(): String {
        return """Avg. Ease"""
    }


    /** Avg. Interval */
    override fun browsingAverageInterval(): String {
        return """Avg. Interval"""
    }


    /** Browser Appearance */
    override fun browsingBrowserAppearance(): String {
        return """Browser Appearance"""
    }


    /** Browser Options */
    override fun browsingBrowserOptions(): String {
        return """Browser Options"""
    }


    /** Buried */
    override fun browsingBuried(): String {
        return """Buried"""
    }


    /** Card */
    override fun browsingCard(): String {
        return """Card"""
    }


    /** C */
    override fun browsingCardInitial(): String {
        return """C"""
    }


    /** Card List */
    override fun browsingCardList(): String {
        return """Card List"""
    }


    /** Cards */
    override fun browsingCards(): String {
        return """Cards"""
    }


    /** Cards can't be manually moved into a filtered deck. */
    override fun browsingCardsCantBeManuallyMovedInto(): String {
        return """Cards can't be manually moved into a filtered deck."""
    }


    /** {$count} cards deleted. */
    override fun browsingCardsDeleted(`count`: Int): String {
        return """${`count`} cards deleted."""
    }


    /** {$count} cards deleted from {$deck_name}. */
    override fun browsingCardsDeletedWithDeckname(`count`: Int, `deckName`: String): String {
        return """${`count`} cards deleted from ${`deckName`}."""
    }


    /** {$count} cards updated. */
    override fun browsingCardsUpdated(`count`: Int): String {
        return """${`count`} cards updated."""
    }


    /** Change Deck */
    override fun browsingChangeDeck(): String {
        return """Change Deck"""
    }


    /** Change Deck... */
    override fun browsingChangeDeck2(): String {
        return """Change Deck..."""
    }


    /** Change Note Type */
    override fun browsingChangeNoteType(): String {
        return """Change Note Type"""
    }


    /** Change Note Type... */
    override fun browsingChangeNoteType2(): String {
        return """Change Note Type..."""
    }


    /** Change Note Type */
    override fun browsingChangeNotetype(): String {
        return """Change Note Type"""
    }


    /** Changed position of {$count} new cards. */
    override fun browsingChangedNewPosition(`count`: Int): String {
        return """Changed position of ${`count`} new cards."""
    }


    /** Clear Unused Tags */
    override fun browsingClearUnusedTags(): String {
        return """Clear Unused Tags"""
    }


    /** A saved search with the name {$name} already exists. Do you want to overwrite it? */
    override fun browsingConfirmSavedSearchOverwrite(`name`: String): String {
        return """A saved search with the name ${`name`} already exists. Do you want to overwrite it?"""
    }


    /** Created */
    override fun browsingCreated(): String {
        return """Created"""
    }


    /** Current Deck */
    override fun browsingCurrentDeck(): String {
        return """Current Deck"""
    }


    /** Current note type: */
    override fun browsingCurrentNoteType(): String {
        return """Current note type:"""
    }


    /** Delete Notes */
    override fun browsingDeleteNotes(): String {
        return """Delete Notes"""
    }


    /** Now */
    override fun browsingDueNow(): String {
        return """Now"""
    }


    /** duplicate */
    override fun browsingDuplicate(): String {
        return """duplicate"""
    }


    /** Ease */
    override fun browsingEase(): String {
        return """Ease"""
    }


    /** Edited */
    override fun browsingEditedToday(): String {
        return """Edited"""
    }


    /** Clear search */
    override fun browsingEmptyClearSearch(): String {
        return """Clear search"""
    }


    /** No cards yet */
    override fun browsingEmptyCollectionTitle(`notesMode`: String): String {
        return """No cards yet"""
    }


    /** No cards match this search */
    override fun browsingEmptyNoMatchTitle(`notesMode`: String): String {
        return """No cards match this search"""
    }


    /** Enter tags to add: */
    override fun browsingEnterTagsToAdd(): String {
        return """Enter tags to add:"""
    }


    /** Enter tags to delete: */
    override fun browsingEnterTagsToDelete(): String {
        return """Enter tags to delete:"""
    }


    /** (filtered) */
    override fun browsingFiltered(): String {
        return """(filtered)"""
    }


    /** <b>Find</b>: */
    override fun browsingFind(): String {
        return """<b>Find</b>:"""
    }


    /** Find and Replace */
    override fun browsingFindAndReplace(): String {
        return """Find and Replace"""
    }


    /** Find Duplicates */
    override fun browsingFindDuplicates(): String {
        return """Find Duplicates"""
    }


    /** First Card */
    override fun browsingFirstCard(): String {
        return """First Card"""
    }


    /** Flag */
    override fun browsingFlag(): String {
        return """Flag"""
    }


    /** <b>Font</b>: */
    override fun browsingFont(): String {
        return """<b>Font</b>:"""
    }


    /** <b>Font Size</b>: */
    override fun browsingFontSize(): String {
        return """<b>Font Size</b>:"""
    }


    /** Found {$part} across {$whole}. */
    override fun browsingFoundAsAcrossBs(`part`: TranslateArg, `whole`: String): String {
        return """Found ${`part`} across ${`whole`}."""
    }


    /** {$count} groups */
    override fun browsingGroup(`count`: Int): String {
        return """${`count`} groups"""
    }


    /** Ignore case */
    override fun browsingIgnoreCase(): String {
        return """Ignore case"""
    }


    /** <b>In</b>: */
    override fun browsingIn(): String {
        return """<b>In</b>:"""
    }


    /** Interval */
    override fun browsingInterval(): String {
        return """Interval"""
    }


    /** Last Card */
    override fun browsingLastCard(): String {
        return """Last Card"""
    }


    /** (learning) */
    override fun browsingLearning(): String {
        return """(learning)"""
    }


    /** Leech */
    override fun browsingLeech(): String {
        return """Leech"""
    }


    /** Leech, {$count} lapses */
    override fun browsingLeechLapses(`count`: Int): String {
        return """Leech, ${`count`} lapses"""
    }


    /** <b>Line Size</b>: */
    override fun browsingLineSize(): String {
        return """<b>Line Size</b>:"""
    }


    /** Manage Note Types */
    override fun browsingManageNoteTypes(): String {
        return """Manage Note Types"""
    }


    /** {$count} more tags */
    override fun browsingMoreTags(`count`: Int): String {
        return """${`count`} more tags"""
    }


    /** Move Cards */
    override fun browsingMoveCards(): String {
        return """Move Cards"""
    }


    /** Move cards to deck: */
    override fun browsingMoveCardsToDeck(): String {
        return """Move cards to deck:"""
    }


    /** (new) */
    override fun browsingNew(): String {
        return """(new)"""
    }


    /** New note type: */
    override fun browsingNewNoteType(): String {
        return """New note type:"""
    }


    /** No Flag */
    override fun browsingNoFlag(): String {
        return """No Flag"""
    }


    /** No cards or notes selected. */
    override fun browsingNoSelection(): String {
        return """No cards or notes selected."""
    }


    /** Note */
    override fun browsingNote(): String {
        return """Note"""
    }


    /** {$count} notes */
    override fun browsingNoteCount(`count`: Int): String {
        return """${`count`} notes"""
    }


    /** N */
    override fun browsingNoteInitial(): String {
        return """N"""
    }


    /** Notes */
    override fun browsingNotes(): String {
        return """Notes"""
    }


    /** {$count} notes updated. */
    override fun browsingNotesUpdated(`count`: Int): String {
        return """${`count`} notes updated."""
    }


    /** Optional filter: */
    override fun browsingOptionalFilter(): String {
        return """Optional filter:"""
    }


    /** Override back template: */
    override fun browsingOverrideBackTemplate(): String {
        return """Override back template:"""
    }


    /** Override font: */
    override fun browsingOverrideFont(): String {
        return """Override font:"""
    }


    /** Override front template: */
    override fun browsingOverrideFrontTemplate(): String {
        return """Override front template:"""
    }


    /** Please give your filter a name: */
    override fun browsingPleaseGiveYourFilterAName(): String {
        return """Please give your filter a name:"""
    }


    /** Preview Selected Card ({$val}) */
    override fun browsingPreviewSelectedCard(`val`: TranslateArg): String {
        return """Preview Selected Card (${`val`})"""
    }


    /** Question */
    override fun browsingQuestion(): String {
        return """Question"""
    }


    /** Queue bottom: {$val} */
    override fun browsingQueueBottom(`val`: TranslateArg): String {
        return """Queue bottom: ${`val`}"""
    }


    /** Queue top: {$val} */
    override fun browsingQueueTop(`val`: TranslateArg): String {
        return """Queue top: ${`val`}"""
    }


    /** Randomize order */
    override fun browsingRandomizeOrder(): String {
        return """Randomize order"""
    }


    /** Remove from Selected Notes */
    override fun browsingRemoveFromSelectedNotes(): String {
        return """Remove from Selected Notes"""
    }


    /** Remove Tags... */
    override fun browsingRemoveTags(): String {
        return """Remove Tags..."""
    }


    /** Removed {$count} unused tags. */
    override fun browsingRemovedUnusedTagsCount(`count`: Int): String {
        return """Removed ${`count`} unused tags."""
    }


    /** Renamed {$count} decks. */
    override fun browsingReparentedDecks(`count`: Int): String {
        return """Renamed ${`count`} decks."""
    }


    /** <b>Replace With</b>: */
    override fun browsingReplaceWith(): String {
        return """<b>Replace With</b>:"""
    }


    /** Reposition... */
    override fun browsingReposition(): String {
        return """Reposition..."""
    }


    /** Reposition New Cards */
    override fun browsingRepositionNewCards(): String {
        return """Reposition New Cards"""
    }


    /** Reschedule */
    override fun browsingReschedule(): String {
        return """Reschedule"""
    }


    /** (deleted) */
    override fun browsingRowDeleted(): String {
        return """(deleted)"""
    }


    /** Search cards/notes (type text, then press Enter) */
    override fun browsingSearchBarHint(): String {
        return """Search cards/notes (type text, then press Enter)"""
    }


    /** Filter by */
    override fun browsingSearchFacetStarters(): String {
        return """Filter by"""
    }


    /** Search in: */
    override fun browsingSearchIn(): String {
        return """Search in:"""
    }


    /** Quick filters */
    override fun browsingSearchQuick(): String {
        return """Quick filters"""
    }


    /** Flagged */
    override fun browsingSearchQuickFlagged(): String {
        return """Flagged"""
    }


    /** Leeches */
    override fun browsingSearchQuickLeeches(): String {
        return """Leeches"""
    }


    /** Recent */
    override fun browsingSearchRecent(): String {
        return """Recent"""
    }


    /** Results unchanged until the search is valid */
    override fun browsingSearchResultsUnchanged(): String {
        return """Results unchanged until the search is valid"""
    }


    /** Suggestions */
    override fun browsingSearchSuggestions(): String {
        return """Suggestions"""
    }


    /** Syntax mode */
    override fun browsingSearchSyntaxMode(): String {
        return """Syntax mode"""
    }


    /** Search "{$query}" */
    override fun browsingSearchTextMatch(`query`: String): String {
        return """Search "${`query`}""""
    }


    /** Search within formatting (slow) */
    override fun browsingSearchWithinFormattingSlow(): String {
        return """Search within formatting (slow)"""
    }


    /** Select Deck */
    override fun browsingSelectDeck(): String {
        return """Select Deck"""
    }


    /** Selected notes only */
    override fun browsingSelectedNotesOnly(): String {
        return """Selected notes only"""
    }


    /** Shift position of existing cards */
    override fun browsingShiftPositionOfExistingCards(): String {
        return """Shift position of existing cards"""
    }


    /** Sidebar */
    override fun browsingSidebar(): String {
        return """Sidebar"""
    }


    /** Card State */
    override fun browsingSidebarCardState(): String {
        return """Card State"""
    }


    /** Review */
    override fun browsingSidebarCardStateReview(): String {
        return """Review"""
    }


    /** Collapse */
    override fun browsingSidebarCollapse(): String {
        return """Collapse"""
    }


    /** Collapse Children */
    override fun browsingSidebarCollapseChildren(): String {
        return """Collapse Children"""
    }


    /** Decks */
    override fun browsingSidebarDecks(): String {
        return """Decks"""
    }


    /** Due */
    override fun browsingSidebarDueToday(): String {
        return """Due"""
    }


    /** Expand */
    override fun browsingSidebarExpand(): String {
        return """Expand"""
    }


    /** Expand Children */
    override fun browsingSidebarExpandChildren(): String {
        return """Expand Children"""
    }


    /** Sidebar filter */
    override fun browsingSidebarFilter(): String {
        return """Sidebar filter"""
    }


    /** First Review */
    override fun browsingSidebarFirstReview(): String {
        return """First Review"""
    }


    /** Flags */
    override fun browsingSidebarFlags(): String {
        return """Flags"""
    }


    /** Note Types */
    override fun browsingSidebarNotetypes(): String {
        return """Note Types"""
    }


    /** Overdue */
    override fun browsingSidebarOverdue(): String {
        return """Overdue"""
    }


    /** Rescheduled */
    override fun browsingSidebarRescheduled(): String {
        return """Rescheduled"""
    }


    /** Save Current Search */
    override fun browsingSidebarSaveCurrentSearch(): String {
        return """Save Current Search"""
    }


    /** Saved Searches */
    override fun browsingSidebarSavedSearches(): String {
        return """Saved Searches"""
    }


    /** Tags */
    override fun browsingSidebarTags(): String {
        return """Tags"""
    }


    /** Untagged */
    override fun browsingSidebarUntagged(): String {
        return """Untagged"""
    }


    /** Sort Field */
    override fun browsingSortField(): String {
        return """Sort Field"""
    }


    /** Sorting on this column is not supported. Please choose another. */
    override fun browsingSortingOnThisColumnIsNot(): String {
        return """Sorting on this column is not supported. Please choose another."""
    }


    /** Start position: */
    override fun browsingStartPosition(): String {
        return """Start position:"""
    }


    /** Step: */
    override fun browsingStep(): String {
        return """Step:"""
    }


    /** Studied */
    override fun browsingStudiedToday(): String {
        return """Studied"""
    }


    /** Suspended */
    override fun browsingSuspended(): String {
        return """Suspended"""
    }


    /** Tag Duplicates */
    override fun browsingTagDuplicates(): String {
        return """Tag Duplicates"""
    }


    /** You can't rename a tag that has no notes. */
    override fun browsingTagRenameWarningEmpty(): String {
        return """You can't rename a tag that has no notes."""
    }


    /** Target field: */
    override fun browsingTargetField(): String {
        return """Target field:"""
    }


    /** Today */
    override fun browsingToday(): String {
        return """Today"""
    }


    /** Toggle Bury */
    override fun browsingToggleBury(): String {
        return """Toggle Bury"""
    }


    /** Toggle Mark */
    override fun browsingToggleMark(): String {
        return """Toggle Mark"""
    }


    /** Toggle Cards/Notes */
    override fun browsingToggleShowingCardsNotes(): String {
        return """Toggle Cards/Notes"""
    }


    /** Toggle Suspend */
    override fun browsingToggleSuspend(): String {
        return """Toggle Suspend"""
    }


    /** The back side of a card, customisable in the card template editor */
    override fun browsingTooltipAnswer(): String {
        return """The back side of a card, customisable in the card template editor"""
    }


    /** The name of a card's card template */
    override fun browsingTooltipCard(): String {
        return """The name of a card's card template"""
    }


    /** The last time changes were made to a card, including reviews, flags and deck changes */
    override fun browsingTooltipCardModified(): String {
        return """The last time changes were made to a card, including reviews, flags and deck changes"""
    }


    /** The number of cards a note has */
    override fun browsingTooltipCards(): String {
        return """The number of cards a note has"""
    }


    /** The last time changes were made to a note, usually field content or tag edits */
    override fun browsingTooltipNoteModified(): String {
        return """The last time changes were made to a note, usually field content or tag edits"""
    }


    /** The name of a note's note type */
    override fun browsingTooltipNotetype(): String {
        return """The name of a note's note type"""
    }


    /** The front side of a card, customisable in the card template editor */
    override fun browsingTooltipQuestion(): String {
        return """The front side of a card, customisable in the card template editor"""
    }


    /** Treat input as regular expression */
    override fun browsingTreatInputAsRegularExpression(): String {
        return """Treat input as regular expression"""
    }


    /** Update with Current Search */
    override fun browsingUpdateSavedSearch(): String {
        return """Update with Current Search"""
    }


    /** Whole Collection */
    override fun browsingWholeCollection(): String {
        return """Whole Collection"""
    }


    /** Browse ({$selected} of {$total} cards selected) */
    override fun browsingWindowTitle(`selected`: Int, `total`: Int): String {
        return """Browse (${`selected`} of ${`total`} cards selected)"""
    }


    /** Browse ({$selected} of {$total} notes selected) */
    override fun browsingWindowTitleNotes(`selected`: Int, `total`: Int): String {
        return """Browse (${`selected`} of ${`total`} notes selected)"""
    }


    /** You must have at least one column. */
    override fun browsingYouMustHaveAtLeastOne(): String {
        return """You must have at least one column."""
    }


    /** Added */
    override fun cardStatsAdded(): String {
        return """Added"""
    }


    /** Average Time */
    override fun cardStatsAverageTime(): String {
        return """Average Time"""
    }


    /** Card ID */
    override fun cardStatsCardId(): String {
        return """Card ID"""
    }


    /** Card Type */
    override fun cardStatsCardTemplate(): String {
        return """Card Type"""
    }


    /** Current Card ({$context}) */
    override fun cardStatsCurrentCard(`context`: String): String {
        return """Current Card (${`context`})"""
    }


    /** Custom Data */
    override fun cardStatsCustomData(): String {
        return """Custom Data"""
    }


    /** Deck */
    override fun cardStatsDeckName(): String {
        return """Deck"""
    }


    /** Ease */
    override fun cardStatsEase(): String {
        return """Ease"""
    }


    /** First Review */
    override fun cardStatsFirstReview(): String {
        return """First Review"""
    }


    /** Difficulty */
    override fun cardStatsFsrsDifficulty(): String {
        return """Difficulty"""
    }


    /** All Time */
    override fun cardStatsFsrsForgettingCurveAllTime(): String {
        return """All Time"""
    }


    /** Desired Retention */
    override fun cardStatsFsrsForgettingCurveDesiredRetention(): String {
        return """Desired Retention"""
    }


    /** First Month */
    override fun cardStatsFsrsForgettingCurveFirstMonth(): String {
        return """First Month"""
    }


    /** First Week */
    override fun cardStatsFsrsForgettingCurveFirstWeek(): String {
        return """First Week"""
    }


    /** First Year */
    override fun cardStatsFsrsForgettingCurveFirstYear(): String {
        return """First Year"""
    }


    /** Probability of Recall */
    override fun cardStatsFsrsForgettingCurveProbabilityOfRecalling(): String {
        return """Probability of Recall"""
    }


    /** Forgetting Curve */
    override fun cardStatsFsrsForgettingCurveTitle(): String {
        return """Forgetting Curve"""
    }


    /** Retrievability */
    override fun cardStatsFsrsRetrievability(): String {
        return """Retrievability"""
    }


    /** Stability */
    override fun cardStatsFsrsStability(): String {
        return """Stability"""
    }


    /** Interval */
    override fun cardStatsInterval(): String {
        return """Interval"""
    }


    /** Lapses */
    override fun cardStatsLapseCount(): String {
        return """Lapses"""
    }


    /** Latest Review */
    override fun cardStatsLatestReview(): String {
        return """Latest Review"""
    }


    /** Position */
    override fun cardStatsNewCardPosition(): String {
        return """Position"""
    }


    /** (No card to display.) */
    override fun cardStatsNoCard(): String {
        return """(No card to display.)"""
    }


    /** Note ID */
    override fun cardStatsNoteId(): String {
        return """Note ID"""
    }


    /** Note Type */
    override fun cardStatsNoteType(): String {
        return """Note Type"""
    }


    /** Preset */
    override fun cardStatsPreset(): String {
        return """Preset"""
    }


    /** Previous Card ({$context}) */
    override fun cardStatsPreviousCard(`context`: String): String {
        return """Previous Card (${`context`})"""
    }


    /** Reviews */
    override fun cardStatsReviewCount(): String {
        return """Reviews"""
    }


    /** Date */
    override fun cardStatsReviewLogDate(): String {
        return """Date"""
    }


    /** Elapsed Time */
    override fun cardStatsReviewLogElapsedTime(): String {
        return """Elapsed Time"""
    }


    /** Rating */
    override fun cardStatsReviewLogRating(): String {
        return """Rating"""
    }


    /** Time */
    override fun cardStatsReviewLogTimeTaken(): String {
        return """Time"""
    }


    /** Type */
    override fun cardStatsReviewLogType(): String {
        return """Type"""
    }


    /** Filtered */
    override fun cardStatsReviewLogTypeFiltered(): String {
        return """Filtered"""
    }


    /** Learn */
    override fun cardStatsReviewLogTypeLearn(): String {
        return """Learn"""
    }


    /** Manual */
    override fun cardStatsReviewLogTypeManual(): String {
        return """Manual"""
    }


    /** Relearn */
    override fun cardStatsReviewLogTypeRelearn(): String {
        return """Relearn"""
    }


    /** Rescheduled */
    override fun cardStatsReviewLogTypeRescheduled(): String {
        return """Rescheduled"""
    }


    /** Review */
    override fun cardStatsReviewLogTypeReview(): String {
        return """Review"""
    }


    /** Total Time */
    override fun cardStatsTotalTime(): String {
        return """Total Time"""
    }


    /** Back template has a problem: */
    override fun cardTemplateRenderingBackSideProblem(): String {
        return """Back template has a problem:"""
    }


    /** Browser-specific back template has a problem: */
    override fun cardTemplateRenderingBrowserBackSideProblem(): String {
        return """Browser-specific back template has a problem:"""
    }


    /** Browser-specific front template has a problem: */
    override fun cardTemplateRenderingBrowserFrontSideProblem(): String {
        return """Browser-specific front template has a problem:"""
    }


    /** Missing '{$missing}' */
    override fun cardTemplateRenderingConditionalNotClosed(`missing`: String): String {
        return """Missing '${`missing`}'"""
    }


    /** Found '{$found}', but missing '{$missing1}' or '{$missing2}' */
    override fun cardTemplateRenderingConditionalNotOpen(`found`: TranslateArg, `missing1`: String, `missing2`: String): String {
        return """Found '${`found`}', but missing '${`missing1`}' or '${`missing2`}'"""
    }


    /** The front of this card is blank. */
    override fun cardTemplateRenderingEmptyFront(): String {
        return """The front of this card is blank."""
    }


    /** Front template has a problem: */
    override fun cardTemplateRenderingFrontSideProblem(): String {
        return """Front template has a problem:"""
    }


    /** No cloze {$number} found on card.
Please either add a cloze deletion, or use the Empty Cards tool. */
    override fun cardTemplateRenderingMissingCloze(`number`: TranslateArg): String {
        return """No cloze ${`number`} found on card.
Please either add a cloze deletion, or use the Empty Cards tool."""
    }


    /** More information */
    override fun cardTemplateRenderingMoreInfo(): String {
        return """More information"""
    }


    /** Missing '{$missing}' in '{$tag}' */
    override fun cardTemplateRenderingNoClosingBrackets(`missing`: String, `tag`: String): String {
        return """Missing '${`missing`}' in '${`tag`}'"""
    }


    /** Found '{$found}', but there is no field called '{$field}' */
    override fun cardTemplateRenderingNoSuchField(`found`: TranslateArg, `field`: String): String {
        return """Found '${`found`}', but there is no field called '${`field`}'"""
    }


    /** Found '{$found}', but expected '{$expected}' */
    override fun cardTemplateRenderingWrongConditionalClosed(`found`: TranslateArg, `expected`: TranslateArg): String {
        return """Found '${`found`}', but expected '${`expected`}'"""
    }


    /** Add Card Type... */
    override fun cardTemplatesAddCardType(): String {
        return """Add Card Type..."""
    }


    /** Add Mobile Class */
    override fun cardTemplatesAddMobileClass(): String {
        return """Add Mobile Class"""
    }


    /** Anki couldn't find the line between the question and answer. Please adjust the template manually to switch the question and answer. */
    override fun cardTemplatesAnkiCouldntFindTheLineBetween(): String {
        return """Anki couldn't find the line between the question and answer. Please adjust the template manually to switch the question and answer."""
    }


    /** At least one card type is required. */
    override fun cardTemplatesAtLeastOneCardTypeIs(): String {
        return """At least one card type is required."""
    }


    /** Back Preview */
    override fun cardTemplatesBackPreview(): String {
        return """Back Preview"""
    }


    /** Back Template */
    override fun cardTemplatesBackTemplate(): String {
        return """Back Template"""
    }


    /** blank */
    override fun cardTemplatesBlank(): String {
        return """blank"""
    }


    /** Browser Appearance... */
    override fun cardTemplatesBrowserAppearance(): String {
        return """Browser Appearance..."""
    }


    /** Card {$val} */
    override fun cardTemplatesCard(`val`: TranslateArg): String {
        return """Card ${`val`}"""
    }


    /** {$count} cards */
    override fun cardTemplatesCardCount(`count`: Int): String {
        return """${`count`} cards"""
    }


    /** Card Type: */
    override fun cardTemplatesCardType(): String {
        return """Card Type:"""
    }


    /** Card Types for {$val} */
    override fun cardTemplatesCardTypesFor(`val`: TranslateArg): String {
        return """Card Types for ${`val`}"""
    }


    /** Changes saved. */
    override fun cardTemplatesChangesSaved(): String {
        return """Changes saved."""
    }


    /** Changes below will affect the {$count} notes that use this card type. */
    override fun cardTemplatesChangesWillAffectNotes(`count`: Int): String {
        return """Changes below will affect the ${`count`} notes that use this card type."""
    }


    /** Cloze {$val} */
    override fun cardTemplatesCloze(`val`: TranslateArg): String {
        return """Cloze ${`val`}"""
    }


    /** Copy Info to Clipboard */
    override fun cardTemplatesCopyInfo(): String {
        return """Copy Info to Clipboard"""
    }


    /** Deck Override... */
    override fun cardTemplatesDeckOverride(): String {
        return """Deck Override..."""
    }


    /** Delete the '{$template}' card type, and its {$cards}? */
    override fun cardTemplatesDeleteTheAsCardTypeAnd(`template`: String, `cards`: Int): String {
        return """Delete the '${`template`}' card type, and its ${`cards`}?"""
    }


    /** Discard changes? */
    override fun cardTemplatesDiscardChanges(): String {
        return """Discard changes?"""
    }


    /** Enter deck to place new {$val} cards in, or leave blank: */
    override fun cardTemplatesEnterDeckToPlaceNew(`val`: TranslateArg): String {
        return """Enter deck to place new ${`val`} cards in, or leave blank:"""
    }


    /** Enter new card position (1...{$val}): */
    override fun cardTemplatesEnterNewCardPosition1(`val`: TranslateArg): String {
        return """Enter new card position (1...${`val`}):"""
    }


    /** 'cloze:' can only be used on cloze note types. */
    override fun cardTemplatesExtraneousCloze(): String {
        return """'cloze:' can only be used on cloze note types."""
    }


    /** Field '{$field}' not found. */
    override fun cardTemplatesFieldNotFound(`field`: String): String {
        return """Field '${`field`}' not found."""
    }


    /** Fill Empty Fields */
    override fun cardTemplatesFillEmpty(): String {
        return """Fill Empty Fields"""
    }


    /** Flip */
    override fun cardTemplatesFlip(): String {
        return """Flip"""
    }


    /** Form */
    override fun cardTemplatesForm(): String {
        return """Form"""
    }


    /** Front Preview */
    override fun cardTemplatesFrontPreview(): String {
        return """Front Preview"""
    }


    /** Front Template */
    override fun cardTemplatesFrontTemplate(): String {
        return """Front Template"""
    }


    /** The front side is identical to card template {$number}. */
    override fun cardTemplatesIdenticalFront(`number`: TranslateArg): String {
        return """The front side is identical to card template ${`number`}."""
    }


    /** Card template {$number} in note type '{$notetype}' has a problem. */
    override fun cardTemplatesInvalidTemplateNumber(`number`: TranslateArg, `notetype`: String): String {
        return """Card template ${`number`} in note type '${`notetype`}' has a problem."""
    }


    /** Expected to find 'cloze:Text' or similar on the front and back of the card template. */
    override fun cardTemplatesMissingCloze(): String {
        return """Expected to find 'cloze:Text' or similar on the front and back of the card template."""
    }


    /** Night Mode */
    override fun cardTemplatesNightMode(): String {
        return """Night Mode"""
    }


    /** Expected to find a field replacement on the front of the card template. */
    override fun cardTemplatesNoFrontField(): String {
        return """Expected to find a field replacement on the front of the card template."""
    }


    /** (off) */
    override fun cardTemplatesOff(): String {
        return """(off)"""
    }


    /** (on) */
    override fun cardTemplatesOn(): String {
        return """(on)"""
    }


    /** Preview */
    override fun cardTemplatesPreviewBox(): String {
        return """Preview"""
    }


    /** Options */
    override fun cardTemplatesPreviewSettings(): String {
        return """Options"""
    }


    /** Remove Card Type... */
    override fun cardTemplatesRemoveCardType(): String {
        return """Remove Card Type..."""
    }


    /** Rename Card Type... */
    override fun cardTemplatesRenameCardType(): String {
        return """Rename Card Type..."""
    }


    /** Reposition Card Type... */
    override fun cardTemplatesRepositionCardType(): String {
        return """Reposition Card Type..."""
    }


    /** Restore to Default */
    override fun cardTemplatesRestoreToDefault(): String {
        return """Restore to Default"""
    }


    /** This will reset all fields and templates in this note type to their default values, removing any extra fields/templates and their content, and any custom styling. Do you wish to proceed? */
    override fun cardTemplatesRestoreToDefaultConfirmation(): String {
        return """This will reset all fields and templates in this note type to their default values, removing any extra fields/templates and their content, and any custom styling. Do you wish to proceed?"""
    }


    /** Note type has been restored to its original state. */
    override fun cardTemplatesRestoredToDefault(): String {
        return """Note type has been restored to its original state."""
    }


    /** This is a sample cloze deletion. */
    override fun cardTemplatesSampleCloze(): String {
        return """This is a sample cloze deletion."""
    }


    /** See the preview for more information. */
    override fun cardTemplatesSeePreview(): String {
        return """See the preview for more information."""
    }


    /** Template */
    override fun cardTemplatesTemplateBox(): String {
        return """Template"""
    }


    /** Styling */
    override fun cardTemplatesTemplateStyling(): String {
        return """Styling"""
    }


    /** This will create {$count} cards. Proceed? */
    override fun cardTemplatesThisWillCreateCardProceed(`count`: Int): String {
        return """This will create ${`count`} cards. Proceed?"""
    }


    /** Only one typing box per card template is supported. */
    override fun cardTemplatesTypeBoxesWarning(): String {
        return """Only one typing box per card template is supported."""
    }


    /** Collapse */
    override fun changeNotetypeCollapse(): String {
        return """Collapse"""
    }


    /** Current */
    override fun changeNotetypeCurrent(): String {
        return """Current"""
    }


    /** Expand */
    override fun changeNotetypeExpand(): String {
        return """Expand"""
    }


    /** Fields */
    override fun changeNotetypeFields(): String {
        return """Fields"""
    }


    /** New */
    override fun changeNotetypeNew(): String {
        return """New"""
    }


    /** (Nothing) */
    override fun changeNotetypeNothing(): String {
        return """(Nothing)"""
    }


    /** Templates */
    override fun changeNotetypeTemplates(): String {
        return """Templates"""
    }


    /** When changing to or from a Cloze note type, card numbers remain unchanged.

If changing to a regular note type, and there are more cloze deletions
than available card templates, any extra cards will be removed. */
    override fun changeNotetypeToFromCloze(): String {
        return """When changing to or from a Cloze note type, card numbers remain unchanged.

If changing to a regular note type, and there are more cloze deletions
than available card templates, any extra cards will be removed."""
    }


    /** Will remove the following cards: */
    override fun changeNotetypeWillDiscardCards(): String {
        return """Will remove the following cards:"""
    }


    /** Will discard content on the following fields: */
    override fun changeNotetypeWillDiscardContent(): String {
        return """Will discard content on the following fields:"""
    }


    /** All cards in random order (don't reschedule) */
    override fun customStudyAllCardsInRandomOrderDont(): String {
        return """All cards in random order (don't reschedule)"""
    }


    /** All review cards in random order */
    override fun customStudyAllReviewCardsInRandomOrder(): String {
        return """All review cards in random order"""
    }


    /** ({$count} in subdecks) */
    override fun customStudyAvailableChildCount(`count`: Int): String {
        return """(${`count`} in subdecks)"""
    }


    /** Available new cards: {$count} */
    override fun customStudyAvailableNewCards(`count`: Int): String {
        return """Available new cards: ${`count`}"""
    }


    /** Available new cards: {$countString} */
    override fun customStudyAvailableNewCards2(`countString`: String): String {
        return """Available new cards: ${`countString`}"""
    }


    /** Available review cards: {$count} */
    override fun customStudyAvailableReviewCards(`count`: Int): String {
        return """Available review cards: ${`count`}"""
    }


    /** Available review cards: {$countString} */
    override fun customStudyAvailableReviewCards2(`countString`: String): String {
        return """Available review cards: ${`countString`}"""
    }


    /** cards */
    override fun customStudyCards(`count`: Int): String {
        return """cards"""
    }


    /** cards from the deck */
    override fun customStudyCardsFromTheDeck(`count`: Int): String {
        return """cards from the deck"""
    }


    /** Choose Tags */
    override fun customStudyChooseTags(): String {
        return """Choose Tags"""
    }


    /** Custom Study Session */
    override fun customStudyCustomStudySession(): String {
        return """Custom Study Session"""
    }


    /** days */
    override fun customStudyDays(`count`: Int): String {
        return """days"""
    }


    /** Due cards only */
    override fun customStudyDueCardsOnly(): String {
        return """Due cards only"""
    }


    /** Increase today's new card limit */
    override fun customStudyIncreaseTodaysNewCardLimit(): String {
        return """Increase today's new card limit"""
    }


    /** Increase today's new card limit by */
    override fun customStudyIncreaseTodaysNewCardLimitBy(): String {
        return """Increase today's new card limit by"""
    }


    /** Increase today's review card limit */
    override fun customStudyIncreaseTodaysReviewCardLimit(): String {
        return """Increase today's review card limit"""
    }


    /** Increase today's review limit by */
    override fun customStudyIncreaseTodaysReviewLimitBy(): String {
        return """Increase today's review limit by"""
    }


    /** Please rename the existing Custom Study deck first. */
    override fun customStudyMustRenameDeck(): String {
        return """Please rename the existing Custom Study deck first."""
    }


    /** New cards only */
    override fun customStudyNewCardsOnly(): String {
        return """New cards only"""
    }


    /** No cards matched the criteria you provided. */
    override fun customStudyNoCardsMatchedTheCriteriaYou(): String {
        return """No cards matched the criteria you provided."""
    }


    /** OK */
    override fun customStudyOk(): String {
        return """OK"""
    }


    /** Preview new cards */
    override fun customStudyPreviewNewCards(): String {
        return """Preview new cards"""
    }


    /** Preview new cards added in the last */
    override fun customStudyPreviewNewCardsAddedInThe(): String {
        return """Preview new cards added in the last"""
    }


    /** Require one or more of these tags: */
    override fun customStudyRequireOneOrMoreOfThese(): String {
        return """Require one or more of these tags:"""
    }


    /** Review ahead */
    override fun customStudyReviewAhead(): String {
        return """Review ahead"""
    }


    /** Review ahead by */
    override fun customStudyReviewAheadBy(): String {
        return """Review ahead by"""
    }


    /** Review cards forgotten in the last */
    override fun customStudyReviewCardsForgottenInLast(): String {
        return """Review cards forgotten in the last"""
    }


    /** Review forgotten cards */
    override fun customStudyReviewForgottenCards(): String {
        return """Review forgotten cards"""
    }


    /** Select */
    override fun customStudySelect(): String {
        return """Select"""
    }


    /** Select tags to exclude: */
    override fun customStudySelectTagsToExclude(): String {
        return """Select tags to exclude:"""
    }


    /** Selective Study */
    override fun customStudySelectiveStudy(): String {
        return """Selective Study"""
    }


    /** Study by card state or tag */
    override fun customStudyStudyByCardStateOrTag(): String {
        return """Study by card state or tag"""
    }


    /** Added last review time to {$count} cards. */
    override fun databaseCheckCardLastReviewTimeEmpty(`count`: Int): String {
        return """Added last review time to ${`count`} cards."""
    }


    /** Deleted {$count} cards with missing note. */
    override fun databaseCheckCardMissingNote(`count`: Int): String {
        return """Deleted ${`count`} cards with missing note."""
    }


    /** Fixed {$count} invalid card properties. */
    override fun databaseCheckCardProperties(`count`: Int): String {
        return """Fixed ${`count`} invalid card properties."""
    }


    /** Checking cards... */
    override fun databaseCheckCheckingCards(): String {
        return """Checking cards..."""
    }


    /** Checking history... */
    override fun databaseCheckCheckingHistory(): String {
        return """Checking history..."""
    }


    /** Checking collection... */
    override fun databaseCheckCheckingIntegrity(): String {
        return """Checking collection..."""
    }


    /** Checking notes... */
    override fun databaseCheckCheckingNotes(): String {
        return """Checking notes..."""
    }


    /** Collection file is corrupt. Please restore from an automatic backup. */
    override fun databaseCheckCorrupt(): String {
        return """Collection file is corrupt. Please restore from an automatic backup."""
    }


    /** Deleted {$count} cards with duplicate template. */
    override fun databaseCheckDuplicateCardOrds(`count`: Int): String {
        return """Deleted ${`count`} cards with duplicate template."""
    }


    /** Fixed {$count} notes with wrong field count. */
    override fun databaseCheckFieldCount(`count`: Int): String {
        return """Fixed ${`count`} notes with wrong field count."""
    }


    /** Fixed {$count} objects with timestamps in the future. */
    override fun databaseCheckFixedInvalidIds(`count`: Int): String {
        return """Fixed ${`count`} objects with timestamps in the future."""
    }


    /** Fixed {$count} missing decks. */
    override fun databaseCheckMissingDecks(`count`: Int): String {
        return """Fixed ${`count`} missing decks."""
    }


    /** Deleted {$count} cards with missing template. */
    override fun databaseCheckMissingTemplates(`count`: Int): String {
        return """Deleted ${`count`} cards with missing template."""
    }


    /** Found {$count} new cards with a due number >= 1,000,000 - consider repositioning them in the Browse screen. */
    override fun databaseCheckNewCardHighDue(`count`: Int): String {
        return """Found ${`count`} new cards with a due number >= 1,000,000 - consider repositioning them in the Browse screen."""
    }


    /** Fixed {$count} notes with invalid utf8 characters. */
    override fun databaseCheckNotesWithInvalidUtf8(`count`: Int): String {
        return """Fixed ${`count`} notes with invalid utf8 characters."""
    }


    /** One or more note types were missing. The notes that used them have been given new note types starting with "db-check", but field names and card design have been lost, so you may be better off restoring from an automatic backup. */
    override fun databaseCheckNotetypesRecovered(): String {
        return """One or more note types were missing. The notes that used them have been given new note types starting with "db-check", but field names and card design have been lost, so you may be better off restoring from an automatic backup."""
    }


    /** Rebuilding... */
    override fun databaseCheckRebuilding(): String {
        return """Rebuilding..."""
    }


    /** Database rebuilt and optimized. */
    override fun databaseCheckRebuilt(): String {
        return """Database rebuilt and optimized."""
    }


    /** Fixed {$count} review entries with invalid properties. */
    override fun databaseCheckRevlogProperties(`count`: Int): String {
        return """Fixed ${`count`} review entries with invalid properties."""
    }


    /** Check Database */
    override fun databaseCheckTitle(): String {
        return """Check Database"""
    }


    /** A 100 day interval will become {$days} days. */
    override fun deckConfigA100DayInterval(`days`: Int): String {
        return """A 100 day interval will become ${`days`} days."""
    }


    /** Add Preset */
    override fun deckConfigAddGroup(): String {
        return """Add Preset"""
    }


    /** Additional new cards to simulate */
    override fun deckConfigAdditionalNewCardsToSimulate(): String {
        return """Additional new cards to simulate"""
    }


    /** Advanced Settings */
    override fun deckConfigAdvancedSettings(): String {
        return """Advanced Settings"""
    }


    /** Advanced */
    override fun deckConfigAdvancedTitle(): String {
        return """Advanced"""
    }


    /** Affects the entire collection. */
    override fun deckConfigAffectsEntireCollection(): String {
        return """Affects the entire collection."""
    }


    /** Whether the question audio should be included when the Replay action is
used while looking at the answer side of a card. */
    override fun deckConfigAlwaysIncludeQuestionAudioTooltip(): String {
        return """Whether the question audio should be included when the Replay action is
used while looking at the answer side of a card."""
    }


    /** Answer action */
    override fun deckConfigAnswerAction(): String {
        return """Answer action"""
    }


    /** The action to perform on the current card before automatically advancing to the next one. */
    override fun deckConfigAnswerActionTooltip(): String {
        return """The action to perform on the current card before automatically advancing to the next one."""
    }


    /** The action to perform after the answer is shown, and time has elapsed. */
    override fun deckConfigAnswerActionTooltip2(): String {
        return """The action to perform after the answer is shown, and time has elapsed."""
    }


    /** Answer Again */
    override fun deckConfigAnswerAgain(): String {
        return """Answer Again"""
    }


    /** Answer Good */
    override fun deckConfigAnswerGood(): String {
        return """Answer Good"""
    }


    /** Answer Hard */
    override fun deckConfigAnswerHard(): String {
        return """Answer Hard"""
    }


    /** Limits start from top */
    override fun deckConfigApplyAllParentLimits(): String {
        return """Limits start from top"""
    }


    /** By default, the daily limits of a higher-level deck do not apply if you're studying from its subdeck.
If this option is enabled, the limits will
start from the top-level deck instead, which can be useful if you wish to study individual
subdecks, while enforcing a total limit on cards for the deck tree. */
    override fun deckConfigApplyAllParentLimitsTooltip(): String {
        return """By default, the daily limits of a higher-level deck do not apply if you're studying from its subdeck.
If this option is enabled, the limits will
start from the top-level deck instead, which can be useful if you wish to study individual
subdecks, while enforcing a total limit on cards for the deck tree."""
    }


    /** Audio */
    override fun deckConfigAudioTitle(): String {
        return """Audio"""
    }


    /** Bury if new */
    override fun deckConfigBuryIfNew(): String {
        return """Bury if new"""
    }


    /** Bury if new or review */
    override fun deckConfigBuryIfNewOrReview(): String {
        return """Bury if new or review"""
    }


    /** Bury if new, review, or interday learning */
    override fun deckConfigBuryIfNewReviewOrInterday(): String {
        return """Bury if new, review, or interday learning"""
    }


    /** Bury interday learning siblings */
    override fun deckConfigBuryInterdayLearningSiblings(): String {
        return """Bury interday learning siblings"""
    }


    /** Whether other `learning` cards of the same note with intervals > 1 day
will be delayed until the next day. */
    override fun deckConfigBuryInterdayLearningTooltip(): String {
        return """Whether other `learning` cards of the same note with intervals > 1 day
will be delayed until the next day."""
    }


    /** Bury new siblings */
    override fun deckConfigBuryNewSiblings(): String {
        return """Bury new siblings"""
    }


    /** Whether other `new` cards of the same note (e.g. reverse cards, adjacent cloze deletions)
will be delayed until the next day. */
    override fun deckConfigBuryNewTooltip(): String {
        return """Whether other `new` cards of the same note (e.g. reverse cards, adjacent cloze deletions)
will be delayed until the next day."""
    }


    /** When Anki gathers cards, it first gathers intraday learning cards, then
interday learning cards, then review cards, and finally new cards. This affects
how burying works:

- If you have all burying options enabled, the sibling that comes earliest in
that list will be shown. For example, a review card will be shown in preference
to a new card.
- Siblings later in the list can not bury earlier card types. For example, if you
disable burying of new cards, and study a new card, it will not bury any interday
learning or review cards, and you may see both a review sibling and new sibling in the
same session. */
    override fun deckConfigBuryPriorityTooltip(): String {
        return """When Anki gathers cards, it first gathers intraday learning cards, then
interday learning cards, then review cards, and finally new cards. This affects
how burying works:

- If you have all burying options enabled, the sibling that comes earliest in
that list will be shown. For example, a review card will be shown in preference
to a new card.
- Siblings later in the list can not bury earlier card types. For example, if you
disable burying of new cards, and study a new card, it will not bury any interday
learning or review cards, and you may see both a review sibling and new sibling in the
same session."""
    }


    /** Bury review siblings */
    override fun deckConfigBuryReviewSiblings(): String {
        return """Bury review siblings"""
    }


    /** Whether other `review` cards of the same note will be delayed until the next day. */
    override fun deckConfigBuryReviewTooltip(): String {
        return """Whether other `review` cards of the same note will be delayed until the next day."""
    }


    /** Bury siblings */
    override fun deckConfigBurySiblings(): String {
        return """Bury siblings"""
    }


    /** Burying */
    override fun deckConfigBuryTitle(): String {
        return """Burying"""
    }


    /** Siblings are other cards from the same note (eg forward/reverse cards, or
other cloze deletions from the same text).

When this option is off, multiple cards from the same note may be seen on the same
day. When enabled, Anki will automatically *bury* siblings, hiding them until the next
day. This option allows you to choose which kinds of cards may be buried when you answer
one of their siblings.

When using the V3 scheduler, interday learning cards can also be buried. Interday
learning cards are cards with a current learning step of one or more days. */
    override fun deckConfigBuryTooltip(): String {
        return """Siblings are other cards from the same note (eg forward/reverse cards, or
other cloze deletions from the same text).

When this option is off, multiple cards from the same note may be seen on the same
day. When enabled, Anki will automatically *bury* siblings, hiding them until the next
day. This option allows you to choose which kinds of cards may be buried when you answer
one of their siblings.

When using the V3 scheduler, interday learning cards can also be buried. Interday
learning cards are cards with a current learning step of one or more days."""
    }


    /** Checking for improvement... */
    override fun deckConfigCheckingForImprovement(): String {
        return """Checking for improvement..."""
    }


    /** Clear Last Simulation */
    override fun deckConfigClearLastSimulate(): String {
        return """Clear Last Simulation"""
    }


    /** Clone Preset */
    override fun deckConfigCloneGroup(): String {
        return """Clone Preset"""
    }


    /** {$num}% complete. */
    override fun deckConfigComplete(`num`: TranslateArg): String {
        return """${`num`}% complete."""
    }


    /** Compute */
    override fun deckConfigComputeButton(): String {
        return """Compute"""
    }


    /** Minimum recommended retention */
    override fun deckConfigComputeMinimumRecommendedRetention(): String {
        return """Minimum recommended retention"""
    }


    /** Compute minimum recommended retention */
    override fun deckConfigComputeOptimalRetention(): String {
        return """Compute minimum recommended retention"""
    }


    /** This tool assumes you're starting with 0 cards, and will attempt to calculate the amount of material you'll
be able to retain in the given time frame. The estimated retention will greatly depend on your inputs, and
if it significantly differs from 0.9, it's a sign that the time you've allocated each day is either too low
or too high for the amount of cards you're trying to learn. This number can be useful as a reference, but it
is not recommended to copy it into the desired retention field. */
    override fun deckConfigComputeOptimalRetentionTooltip(): String {
        return """This tool assumes you're starting with 0 cards, and will attempt to calculate the amount of material you'll
be able to retain in the given time frame. The estimated retention will greatly depend on your inputs, and
if it significantly differs from 0.9, it's a sign that the time you've allocated each day is either too low
or too high for the amount of cards you're trying to learn. This number can be useful as a reference, but it
is not recommended to copy it into the desired retention field."""
    }


    /** This tool assumes that you’re starting with 0 learned cards, and will attempt to find the desired retention
value that will lead to the most material learnt, in the least amount of time. This number can be used as a
reference when deciding what to set your desired retention to. You may wish to choose a higher desired retention,
if you’re willing to trade more study time for a greater recall rate. Setting your desired retention lower than
the minimum is not recommended, as it will lead to more work without benefit. */
    override fun deckConfigComputeOptimalRetentionTooltip2(): String {
        return """This tool assumes that you’re starting with 0 learned cards, and will attempt to find the desired retention
value that will lead to the most material learnt, in the least amount of time. This number can be used as a
reference when deciding what to set your desired retention to. You may wish to choose a higher desired retention,
if you’re willing to trade more study time for a greater recall rate. Setting your desired retention lower than
the minimum is not recommended, as it will lead to more work without benefit."""
    }


    /** This tool assumes that you’re starting with 0 learned cards, and will attempt to find the desired retention value 
that will lead to the most material learnt, in the least amount of time. To accurately simulate your learning process, 
this feature requires a minimum of 400+ reviews. The calculated number can serve as a reference when deciding what to 
set your desired retention to. You may wish to choose a higher desired retention, if you’re willing to trade more study 
time for a greater recall rate. Setting your desired retention lower than the minimum is not recommended, as it will 
lead to a higher workload, because of the high forgetting rate. */
    override fun deckConfigComputeOptimalRetentionTooltip3(): String {
        return """This tool assumes that you’re starting with 0 learned cards, and will attempt to find the desired retention value 
that will lead to the most material learnt, in the least amount of time. To accurately simulate your learning process, 
this feature requires a minimum of 400+ reviews. The calculated number can serve as a reference when deciding what to 
set your desired retention to. You may wish to choose a higher desired retention, if you’re willing to trade more study 
time for a greater recall rate. Setting your desired retention lower than the minimum is not recommended, as it will 
lead to a higher workload, because of the high forgetting rate."""
    }


    /** This tool will attempt to find the desired retention value 
that will lead to the most material learnt, in the least amount of time. The calculated number can serve as a reference
when deciding what to set your desired retention to. You may wish to choose a higher desired retention if you’re 
willing to invest more study time to achieve it. Setting your desired retention lower than the minimum
is not recommended, as it will lead to a higher workload, because of the high forgetting rate. */
    override fun deckConfigComputeOptimalRetentionTooltip4(): String {
        return """This tool will attempt to find the desired retention value 
that will lead to the most material learnt, in the least amount of time. The calculated number can serve as a reference
when deciding what to set your desired retention to. You may wish to choose a higher desired retention if you’re 
willing to invest more study time to achieve it. Setting your desired retention lower than the minimum
is not recommended, as it will lead to a higher workload, because of the high forgetting rate."""
    }


    /** Optimize FSRS parameters */
    override fun deckConfigComputeOptimalWeights(): String {
        return """Optimize FSRS parameters"""
    }


    /** Once you've done 1000+ reviews in Anki, you can use the Optimize button to analyze your review history,
and automatically generate parameters that are optimal for your memory and the content you're studying.
If you have decks that vary wildly in difficulty, it is recommended to assign them separate presets, as
the parameters for easy decks and hard decks will be different. There is no need to optimize your parameters
frequently - once every few months is sufficient.

By default, parameters will be calculated from the review history of all decks using the current preset. You can
optionally adjust the search before calculating the parameters, if you'd like to alter which cards are used for
optimizing the parameters. */
    override fun deckConfigComputeOptimalWeightsTooltip(): String {
        return """Once you've done 1000+ reviews in Anki, you can use the Optimize button to analyze your review history,
and automatically generate parameters that are optimal for your memory and the content you're studying.
If you have decks that vary wildly in difficulty, it is recommended to assign them separate presets, as
the parameters for easy decks and hard decks will be different. There is no need to optimize your parameters
frequently - once every few months is sufficient.

By default, parameters will be calculated from the review history of all decks using the current preset. You can
optionally adjust the search before calculating the parameters, if you'd like to alter which cards are used for
optimizing the parameters."""
    }


    /** When you click the Optimize button, FSRS will analyze your review history, and generate parameters that are 
optimal for your memory and the content you're studying. If your decks vary wildly in subjective difficulty, it 
is recommended to assign them separate presets, as the parameters for easy decks and hard decks will be different. 
You don't need to optimize your parameters frequently - once every few months is sufficient.

By default, parameters will be calculated from the review history of all decks using the current preset. You can
optionally adjust the search before calculating the parameters, if you'd like to alter which cards are used for
optimizing the parameters. */
    override fun deckConfigComputeOptimalWeightsTooltip2(): String {
        return """When you click the Optimize button, FSRS will analyze your review history, and generate parameters that are 
optimal for your memory and the content you're studying. If your decks vary wildly in subjective difficulty, it 
is recommended to assign them separate presets, as the parameters for easy decks and hard decks will be different. 
You don't need to optimize your parameters frequently - once every few months is sufficient.

By default, parameters will be calculated from the review history of all decks using the current preset. You can
optionally adjust the search before calculating the parameters, if you'd like to alter which cards are used for
optimizing the parameters."""
    }


    /** Remove {$name}? */
    override fun deckConfigConfirmRemoveName(`name`: String): String {
        return """Remove ${`name`}?"""
    }


    /** Custom scheduling */
    override fun deckConfigCustomScheduling(): String {
        return """Custom scheduling"""
    }


    /** Affects the entire collection. Use at your own risk! */
    override fun deckConfigCustomSchedulingTooltip(): String {
        return """Affects the entire collection. Use at your own risk!"""
    }


    /** A parent deck has a limit of {$cards} cards, which will override this limit. */
    override fun deckConfigDailyLimitWillBeCapped(`cards`: Int): String {
        return """A parent deck has a limit of ${`cards`} cards, which will override this limit."""
    }


    /** Daily Limits */
    override fun deckConfigDailyLimits(): String {
        return """Daily Limits"""
    }


    /** Days to simulate */
    override fun deckConfigDaysToSimulate(): String {
        return """Days to simulate"""
    }


    /** This deck */
    override fun deckConfigDeckOnly(): String {
        return """This deck"""
    }


    /** Default */
    override fun deckConfigDefaultName(): String {
        return """Default"""
    }


    /** Anki 2.1.41+ handling */
    override fun deckConfigDescriptionNewHandling(): String {
        return """Anki 2.1.41+ handling"""
    }


    /** Treats input as markdown, and cleans HTML input. When enabled, the
description will also be shown on the congratulations screen.
Markdown will appear as text on Anki 2.1.40 and below. */
    override fun deckConfigDescriptionNewHandlingHint(): String {
        return """Treats input as markdown, and cleans HTML input. When enabled, the
description will also be shown on the congratulations screen.
Markdown will appear as text on Anki 2.1.40 and below."""
    }


    /** Interpret as Markdown */
    override fun deckConfigDescriptionNewHandling2(): String {
        return """Interpret as Markdown"""
    }


    /** Desired retention */
    override fun deckConfigDesiredRetention(): String {
        return """Desired retention"""
    }


    /** Your desired retention is below optimal. Increasing it is recommended. */
    override fun deckConfigDesiredRetentionBelowOptimal(): String {
        return """Your desired retention is below optimal. Increasing it is recommended."""
    }


    /** Your desired retention is very high, which can lead to very short intervals. */
    override fun deckConfigDesiredRetentionTooHigh(): String {
        return """Your desired retention is very high, which can lead to very short intervals."""
    }


    /** Your desired retention is very low, which can lead to very long intervals. */
    override fun deckConfigDesiredRetentionTooLow(): String {
        return """Your desired retention is very low, which can lead to very long intervals."""
    }


    /** By default, Anki schedules cards so that you have a 90% chance of remembering them when
they come up for review again. If you increase this value, Anki will show cards more frequently
to increase the chances of you remembering them. If you decrease the value, Anki will show cards
less frequently, and you will forget more of them. Be conservative when adjusting this - higher
values will greatly increase your workload, and lower values can be demoralizing when you forget
a lot of material. */
    override fun deckConfigDesiredRetentionTooltip(): String {
        return """By default, Anki schedules cards so that you have a 90% chance of remembering them when
they come up for review again. If you increase this value, Anki will show cards more frequently
to increase the chances of you remembering them. If you decrease the value, Anki will show cards
less frequently, and you will forget more of them. Be conservative when adjusting this - higher
values will greatly increase your workload, and lower values can be demoralizing when you forget
a lot of material."""
    }


    /** The workload values provided by the info box are a rough approximation. For a greater level of accuracy, use the simulator. */
    override fun deckConfigDesiredRetentionTooltip2(): String {
        return """The workload values provided by the info box are a rough approximation. For a greater level of accuracy, use the simulator."""
    }


    /** Don't play audio automatically */
    override fun deckConfigDisableAutoplay(): String {
        return """Don't play audio automatically"""
    }


    /** When enabled, Anki will not play audio automatically.
It can be played manually by clicking/tapping on an audio icon, or by using the Replay action. */
    override fun deckConfigDisableAutoplayTooltip(): String {
        return """When enabled, Anki will not play audio automatically.
It can be played manually by clicking/tapping on an audio icon, or by using the Replay action."""
    }


    /** Anki will use the display order from the deck you 
select to study, and not any subdecks it may have. */
    override fun deckConfigDisplayOrderWillUseCurrentDeck(): String {
        return """Anki will use the display order from the deck you 
select to study, and not any subdecks it may have."""
    }


    /** Do not bury siblings */
    override fun deckConfigDoNotBury(): String {
        return """Do not bury siblings"""
    }


    /** An extra multiplier that is applied to a review card's interval when you rate
it `Easy`. */
    override fun deckConfigEasyBonusTooltip(): String {
        return """An extra multiplier that is applied to a review card's interval when you rate
it `Easy`."""
    }


    /** Existing reviews will not be rescheduled unless '' is enabled in the FSRS options. */
    override fun deckConfigEasyDaysChange(): String {
        return """Existing reviews will not be rescheduled unless '' is enabled in the FSRS options."""
    }


    /** Fri */
    override fun deckConfigEasyDaysFriday(): String {
        return """Fri"""
    }


    /** Minimum */
    override fun deckConfigEasyDaysMinimum(): String {
        return """Minimum"""
    }


    /** Mon */
    override fun deckConfigEasyDaysMonday(): String {
        return """Mon"""
    }


    /** At least one day should be set to ''. */
    override fun deckConfigEasyDaysNoNormalDays(): String {
        return """At least one day should be set to ''."""
    }


    /** Normal */
    override fun deckConfigEasyDaysNormal(): String {
        return """Normal"""
    }


    /** Reduced */
    override fun deckConfigEasyDaysReduced(): String {
        return """Reduced"""
    }


    /** Sat */
    override fun deckConfigEasyDaysSaturday(): String {
        return """Sat"""
    }


    /** Sun */
    override fun deckConfigEasyDaysSunday(): String {
        return """Sun"""
    }


    /** Thu */
    override fun deckConfigEasyDaysThursday(): String {
        return """Thu"""
    }


    /** Easy Days */
    override fun deckConfigEasyDaysTitle(): String {
        return """Easy Days"""
    }


    /** Tue */
    override fun deckConfigEasyDaysTuesday(): String {
        return """Tue"""
    }


    /** Wed */
    override fun deckConfigEasyDaysWednesday(): String {
        return """Wed"""
    }


    /** The number of days to wait before showing a card again, after the `Easy` button
is used to immediately remove a card from learning. */
    override fun deckConfigEasyIntervalTooltip(): String {
        return """The number of days to wait before showing a card again, after the `Easy` button
is used to immediately remove a card from learning."""
    }


    /** Evaluate */
    override fun deckConfigEvaluateButton(): String {
        return """Evaluate"""
    }


    /** Health Check:
Your memory is difficult for FSRS to predict. Recommendations:

- Suspend or reformulate any cards you constantly forget.
- Use the answer buttons consistently. Keep in mind that "Hard" is a passing grade, not a failing grade.
- Understand before you memorize.

If you follow these suggestions, performance will usually improve over the next few months. */
    override fun deckConfigFsrsBadFitWarning(): String {
        return """Health Check:
Your memory is difficult for FSRS to predict. Recommendations:

- Suspend or reformulate any cards you constantly forget.
- Use the answer buttons consistently. Keep in mind that "Hard" is a passing grade, not a failing grade.
- Understand before you memorize.

If you follow these suggestions, performance will usually improve over the next few months."""
    }


    /** This will save any other changes you have made. Are you sure? */
    override fun deckConfigFsrsConfirmSaveAndOptimize(): String {
        return """This will save any other changes you have made. Are you sure?"""
    }


    /** Help Me Decide (Experimental) */
    override fun deckConfigFsrsDesiredRetentionHelpMeDecideExperimental(): String {
        return """Help Me Decide (Experimental)"""
    }


    /** Health Check:
FSRS can adapt to your memory well. */
    override fun deckConfigFsrsGoodFit(): String {
        return """Health Check:
FSRS can adapt to your memory well."""
    }


    /** FSRS must be enabled first. */
    override fun deckConfigFsrsMustBeEnabled(): String {
        return """FSRS must be enabled first."""
    }


    /** Please ensure all of your Anki clients are Anki(Mobile) 23.10+ or AnkiDroid 2.17+. FSRS will
not work correctly if one of your clients is older. */
    override fun deckConfigFsrsOnAllClients(): String {
        return """Please ensure all of your Anki clients are Anki(Mobile) 23.10+ or AnkiDroid 2.17+. FSRS will
not work correctly if one of your clients is older."""
    }


    /** No reviews found. Make sure this preset is assigned to all decks (including subdecks) that you want to optimize, and try again. */
    override fun deckConfigFsrsParamsNoReviews(): String {
        return """No reviews found. Make sure this preset is assigned to all decks (including subdecks) that you want to optimize, and try again."""
    }


    /** The FSRS parameters are currently optimal. This is expected once parameters are well-fitted to your review history. You can try optimizing again after doing more reviews. */
    override fun deckConfigFsrsParamsOptimal(): String {
        return """The FSRS parameters are currently optimal. This is expected once parameters are well-fitted to your review history. You can try optimizing again after doing more reviews."""
    }


    /** FSRS Desired Retention Simulator (Experimental) */
    override fun deckConfigFsrsSimulateDesiredRetentionExperimental(): String {
        return """FSRS Desired Retention Simulator (Experimental)"""
    }


    /** After optimizing, please save your deck preset before running the simulator. */
    override fun deckConfigFsrsSimulateSavePreset(): String {
        return """After optimizing, please save your deck preset before running the simulator."""
    }


    /** FSRS Simulator (Experimental) */
    override fun deckConfigFsrsSimulatorExperimental(): String {
        return """FSRS Simulator (Experimental)"""
    }


    /** Reviews */
    override fun deckConfigFsrsSimulatorRadioCount(): String {
        return """Reviews"""
    }


    /** Efficiency */
    override fun deckConfigFsrsSimulatorRadioEfficiency(): String {
        return """Efficiency"""
    }


    /** Memorized */
    override fun deckConfigFsrsSimulatorRadioMemorized(): String {
        return """Memorized"""
    }


    /** Time / Memorized Ratio */
    override fun deckConfigFsrsSimulatorRadioRatio(): String {
        return """Time / Memorized Ratio"""
    }


    /** {$time} per memorized card */
    override fun deckConfigFsrsSimulatorRatioTooltip(`time`: String): String {
        return """${`time`} per memorized card"""
    }


    /** {$time} memorized cards per hour */
    override fun deckConfigFsrsSimulatorRatioTooltip2(`time`: String): String {
        return """${`time`} memorized cards per hour"""
    }


    /** Review Count/Day */
    override fun deckConfigFsrsSimulatorYAxisTitleCount(): String {
        return """Review Count/Day"""
    }


    /** Memorized Total */
    override fun deckConfigFsrsSimulatorYAxisTitleMemorized(): String {
        return """Memorized Total"""
    }


    /** Review Time/Day */
    override fun deckConfigFsrsSimulatorYAxisTitleTime(): String {
        return """Review Time/Day"""
    }


    /** Affects the entire collection.

The Free Spaced Repetition Scheduler (FSRS) is an alternative to Anki's legacy SuperMemo 2 (SM-2) algorithm.
By more accurately determining how likely you are to forget a card, it can help you remember
more material in the same amount of time. This setting is shared by all presets. */
    override fun deckConfigFsrsTooltip(): String {
        return """Affects the entire collection.

The Free Spaced Repetition Scheduler (FSRS) is an alternative to Anki's legacy SuperMemo 2 (SM-2) algorithm.
By more accurately determining how likely you are to forget a card, it can help you remember
more material in the same amount of time. This setting is shared by all presets."""
    }


    /** Get Params */
    override fun deckConfigGetParams(): String {
        return """Get Params"""
    }


    /** The easy interval should be at least as long as the graduating interval. */
    override fun deckConfigGoodAboveEasy(): String {
        return """The easy interval should be at least as long as the graduating interval."""
    }


    /** The number of days to wait before showing a card again, after the `Good` button
is pressed on the final learning step. */
    override fun deckConfigGraduatingIntervalTooltip(): String {
        return """The number of days to wait before showing a card again, after the `Good` button
is pressed on the final learning step."""
    }


    /** The multiplier applied to a review interval when answering `Hard`. */
    override fun deckConfigHardIntervalTooltip(): String {
        return """The multiplier applied to a review interval when answering `Hard`."""
    }


    /** Check health when optimizing */
    override fun deckConfigHealthCheck(): String {
        return """Check health when optimizing"""
    }


    /** This will show a warning if FSRS struggles to adapt to your memory. */
    override fun deckConfigHealthCheckTooltip1(): String {
        return """This will show a warning if FSRS struggles to adapt to your memory."""
    }


    /** Health check is performed only when using Optimize Current Preset. */
    override fun deckConfigHealthCheckTooltip2(): String {
        return """Health check is performed only when using Optimize Current Preset."""
    }


    /** Historical retention */
    override fun deckConfigHistoricalRetention(): String {
        return """Historical retention"""
    }


    /** When some of your review history is missing, FSRS needs to fill in the gaps. By default, it will
assume that when you did those old reviews, you remembered 90% of the material. If your old retention
was appreciably higher or lower than 90%, adjusting this option will allow FSRS to better approximate
the missing reviews.

Your review history may be incomplete for two reasons:
1. Because you're using the 'ignore cards reviewed before' option.
2. Because you previously deleted review logs to free up space, or imported material from a different
SRS program.

The latter is quite rare, so unless you're using the former option, you probably don't need to adjust
this option. */
    override fun deckConfigHistoricalRetentionTooltip(): String {
        return """When some of your review history is missing, FSRS needs to fill in the gaps. By default, it will
assume that when you did those old reviews, you remembered 90% of the material. If your old retention
was appreciably higher or lower than 90%, adjusting this option will allow FSRS to better approximate
the missing reviews.

Your review history may be incomplete for two reasons:
1. Because you're using the 'ignore cards reviewed before' option.
2. Because you previously deleted review logs to free up space, or imported material from a different
SRS program.

The latter is quite rare, so unless you're using the former option, you probably don't need to adjust
this option."""
    }


    /** Ignore cards reviewed before */
    override fun deckConfigIgnoreBefore(): String {
        return """Ignore cards reviewed before"""
    }


    /** (Approximately) {$included}/{$totalCards} cards will be used to optimize the FSRS parameters. */
    override fun deckConfigIgnoreBeforeInfo(`included`: String, `totalCards`: String): String {
        return """(Approximately) ${`included`}/${`totalCards`} cards will be used to optimize the FSRS parameters."""
    }


    /** If set, reviews before the provided date will be ignored when optimizing & evaluating FSRS parameters.
This can be useful if you imported someone else's scheduling data, or have changed the way you use the answer buttons. */
    override fun deckConfigIgnoreBeforeTooltip(): String {
        return """If set, reviews before the provided date will be ignored when optimizing & evaluating FSRS parameters.
This can be useful if you imported someone else's scheduling data, or have changed the way you use the answer buttons."""
    }


    /** If set, cards reviewed before the provided date will be ignored when optimizing FSRS parameters.
This can be useful if you imported someone else's scheduling data, or have changed the way you use the answer buttons. */
    override fun deckConfigIgnoreBeforeTooltip2(): String {
        return """If set, cards reviewed before the provided date will be ignored when optimizing FSRS parameters.
This can be useful if you imported someone else's scheduling data, or have changed the way you use the answer buttons."""
    }


    /** Interday learning/review order */
    override fun deckConfigInterdayStepPriority(): String {
        return """Interday learning/review order"""
    }


    /** When to show (re)learning cards that cross a day boundary.

The review limit is always applied first to interday learning cards, and
then review cards. This option will control the order the gathered cards are shown in,
but interday learning cards will always be gathered first. */
    override fun deckConfigInterdayStepPriorityTooltip(): String {
        return """When to show (re)learning cards that cross a day boundary.

The review limit is always applied first to interday learning cards, and
then review cards. This option will control the order the gathered cards are shown in,
but interday learning cards will always be gathered first."""
    }


    /** This multiplier is applied to all reviews, and minor adjustments can be used
to make Anki more conservative or aggressive in its scheduling. Please see
the manual before changing this option. */
    override fun deckConfigIntervalModifierTooltip(): String {
        return """This multiplier is applied to all reviews, and minor adjustments can be used
to make Anki more conservative or aggressive in its scheduling. Please see
the manual before changing this option."""
    }


    /** The provided FSRS parameters are invalid. Leave them blank to use the default values. */
    override fun deckConfigInvalidParameters(): String {
        return """The provided FSRS parameters are invalid. Leave them blank to use the default values."""
    }


    /** Parameters must be either left blank to use the defaults, or must be 17 comma-separated numbers. */
    override fun deckConfigInvalidWeights(): String {
        return """Parameters must be either left blank to use the defaults, or must be 17 comma-separated numbers."""
    }


    /** Iteration: {$count}... */
    override fun deckConfigIterations(`count`: Int): String {
        return """Iteration: ${`count`}..."""
    }


    /** The graduating interval should be at least as long as your final learning step. */
    override fun deckConfigLearningStepAboveGraduatingInterval(): String {
        return """The graduating interval should be at least as long as your final learning step."""
    }


    /** Learning steps */
    override fun deckConfigLearningSteps(): String {
        return """Learning steps"""
    }


    /** One or more delays, separated by spaces. The first delay will be used
when you press the `Again` button on a new card, and is 1 minute by default.
The `Good` button will advance to the next step, which is 10 minutes by default.
Once all steps have been passed, the card will become a review card, and
will appear on a different day.  */
    override fun deckConfigLearningStepsTooltip(): String {
        return """One or more delays, separated by spaces. The first delay will be used
when you press the `Again` button on a new card, and is 1 minute by default.
The `Good` button will advance to the next step, which is 10 minutes by default.
Once all steps have been passed, the card will become a review card, and
will appear on a different day. """
    }


    /** `Tag Only`: Add a 'leech' tag to the note, and display a pop-up.

`Suspend Card`: In addition to tagging the note, hide the card until it is
manually unsuspended. */
    override fun deckConfigLeechActionTooltip(): String {
        return """`Tag Only`: Add a 'leech' tag to the note, and display a pop-up.

`Suspend Card`: In addition to tagging the note, hide the card until it is
manually unsuspended."""
    }


    /** The number of times `Again` needs to be pressed on a review card before it is
marked as a leech. Leeches are cards that consume a lot of your time, and
when a card is marked as a leech, it's a good idea to rewrite it, delete it, or
think of a mnemonic to help you remember it. */
    override fun deckConfigLeechThresholdTooltip(): String {
        return """The number of times `Again` needs to be pressed on a review card before it is
marked as a leech. Leeches are cards that consume a lot of your time, and
when a card is marked as a leech, it's a good idea to rewrite it, delete it, or
think of a mnemonic to help you remember it."""
    }


    /** When studying a deck that has subdecks inside it, the limits set on each
subdeck control the maximum number of cards gathered from that particular deck.
The selected deck's limits control the total cards that will be shown. */
    override fun deckConfigLimitDeckV3(): String {
        return """When studying a deck that has subdecks inside it, the limits set on each
subdeck control the maximum number of cards gathered from that particular deck.
The selected deck's limits control the total cards that will be shown."""
    }


    /** The review limit also affects interday learning cards. When applying the limit,
interday learning cards are gathered first, then review cards. */
    override fun deckConfigLimitInterdayBoundByReviews(): String {
        return """The review limit also affects interday learning cards. When applying the limit,
interday learning cards are gathered first, then review cards."""
    }


    /** The review limit affects the new limit. For example, if your review limit is
set to 200, and you have 190 reviews waiting, a maximum of 10 new cards will
be introduced. If your review limit has been reached, no new cards will be
shown. */
    override fun deckConfigLimitNewBoundByReviews(): String {
        return """The review limit affects the new limit. For example, if your review limit is
set to 200, and you have 190 reviews waiting, a maximum of 10 new cards will
be introduced. If your review limit has been reached, no new cards will be
shown."""
    }


    /** The parameters should only be modified using the optimize button. Manually editing them is heavily advised against. */
    override fun deckConfigManualParameterEditWarning(): String {
        return """The parameters should only be modified using the optimize button. Manually editing them is heavily advised against."""
    }


    /** Maximum answer seconds */
    override fun deckConfigMaximumAnswerSecs(): String {
        return """Maximum answer seconds"""
    }


    /** Anki can schedule your reviews more efficiently when you keep each question short. */
    override fun deckConfigMaximumAnswerSecsAboveRecommended(): String {
        return """Anki can schedule your reviews more efficiently when you keep each question short."""
    }


    /** The maximum number of seconds to record for a single review. If an answer
exceeds this time (because you stepped away from the screen for example),
the time taken will be recorded as the limit you have set. */
    override fun deckConfigMaximumAnswerSecsTooltip(): String {
        return """The maximum number of seconds to record for a single review. If an answer
exceeds this time (because you stepped away from the screen for example),
the time taken will be recorded as the limit you have set."""
    }


    /** The maximum number of days a review card will wait. When reviews have
reached the limit, `Hard`, `Good` and `Easy` will all give the same delay.
The shorter you set this, the greater your workload will be. */
    override fun deckConfigMaximumIntervalTooltip(): String {
        return """The maximum number of days a review card will wait. When reviews have
reached the limit, `Hard`, `Good` and `Easy` will all give the same delay.
The shorter you set this, the greater your workload will be."""
    }


    /** The minimum interval given to a review card after answering `Again`. */
    override fun deckConfigMinimumIntervalTooltip(): String {
        return """The minimum interval given to a review card after answering `Again`."""
    }


    /** Only {$count} reviews were found. You must have at least 400 reviews for this operation. */
    override fun deckConfigMustHave400Reviews(`count`: Int): String {
        return """Only ${`count`} reviews were found. You must have at least 400 reviews for this operation."""
    }


    /** Name */
    override fun deckConfigNamePrompt(): String {
        return """Name"""
    }


    /** New card sort order */
    override fun deckConfigNewCardSortOrder(): String {
        return """New card sort order"""
    }


    /** `Card type, then order gathered`: Shows cards in order of card type number.
Cards of each card type number are shown in the order they were gathered. 
If you have sibling burying disabled, this will ensure all front→back cards are seen before any back→front cards.
This is useful to have all cards of the same note shown in the same session, but not
too close to one another.

`Order gathered`: Shows cards exactly as they were gathered. If sibling burying is disabled,
this will typically result in all cards of a note being seen one after the other.

`Card type, then random`: Shows cards in order of card type number. Cards of each card
type number are shown in a random order. This order is useful if you don't want sibling cards
to appear too close to each other, but still want the cards to appear in a random order.

`Random note, then card type`: Picks notes at random, then shows all of its cards
in order.

`Random`: Shows cards in a random order. */
    override fun deckConfigNewCardSortOrderTooltip2(): String {
        return """`Card type, then order gathered`: Shows cards in order of card type number.
Cards of each card type number are shown in the order they were gathered. 
If you have sibling burying disabled, this will ensure all front→back cards are seen before any back→front cards.
This is useful to have all cards of the same note shown in the same session, but not
too close to one another.

`Order gathered`: Shows cards exactly as they were gathered. If sibling burying is disabled,
this will typically result in all cards of a note being seen one after the other.

`Card type, then random`: Shows cards in order of card type number. Cards of each card
type number are shown in a random order. This order is useful if you don't want sibling cards
to appear too close to each other, but still want the cards to appear in a random order.

`Random note, then card type`: Picks notes at random, then shows all of its cards
in order.

`Random`: Shows cards in a random order."""
    }


    /** New cards ignore review limit */
    override fun deckConfigNewCardsIgnoreReviewLimit(): String {
        return """New cards ignore review limit"""
    }


    /** By default, the review limit also applies to new cards, and no new cards will be
shown when the review limit has been reached. If this option is enabled, new cards
will be shown regardless of the review limit. */
    override fun deckConfigNewCardsIgnoreReviewLimitTooltip(): String {
        return """By default, the review limit also applies to new cards, and no new cards will be
shown when the review limit has been reached. If this option is enabled, new cards
will be shown regardless of the review limit."""
    }


    /** New card gather order */
    override fun deckConfigNewGatherPriority(): String {
        return """New card gather order"""
    }


    /** Deck */
    override fun deckConfigNewGatherPriorityDeck(): String {
        return """Deck"""
    }


    /** Deck, then random notes */
    override fun deckConfigNewGatherPriorityDeckThenRandomNotes(): String {
        return """Deck, then random notes"""
    }


    /** Descending position */
    override fun deckConfigNewGatherPriorityPositionHighestFirst(): String {
        return """Descending position"""
    }


    /** Ascending position */
    override fun deckConfigNewGatherPriorityPositionLowestFirst(): String {
        return """Ascending position"""
    }


    /** Random cards */
    override fun deckConfigNewGatherPriorityRandomCards(): String {
        return """Random cards"""
    }


    /** Random notes */
    override fun deckConfigNewGatherPriorityRandomNotes(): String {
        return """Random notes"""
    }


    /** `Deck`: Gathers cards from each subdeck in order, starting from the top. Cards from each subdeck are
gathered in ascending position. If the daily limit of the selected deck is reached, gathering
can stop before all subdecks have been checked. This order is fastest in large collections, and
allows you to prioritize subdecks that are closer to the top.

`Ascending position`: Gathers cards by ascending position (due #), which is typically
the oldest-added first.

`Descending position`: Gathers cards by descending position (due #), which is typically
the latest-added first.

`Random notes`: Picks notes at random, then gathers all of its cards.

`Random cards`: Gathers cards in a random order. */
    override fun deckConfigNewGatherPriorityTooltip2(): String {
        return """`Deck`: Gathers cards from each subdeck in order, starting from the top. Cards from each subdeck are
gathered in ascending position. If the daily limit of the selected deck is reached, gathering
can stop before all subdecks have been checked. This order is fastest in large collections, and
allows you to prioritize subdecks that are closer to the top.

`Ascending position`: Gathers cards by ascending position (due #), which is typically
the oldest-added first.

`Descending position`: Gathers cards by descending position (due #), which is typically
the latest-added first.

`Random notes`: Picks notes at random, then gathers all of its cards.

`Random cards`: Gathers cards in a random order."""
    }


    /** Insertion order */
    override fun deckConfigNewInsertionOrder(): String {
        return """Insertion order"""
    }


    /** Random */
    override fun deckConfigNewInsertionOrderRandom(): String {
        return """Random"""
    }


    /** With the v3 scheduler, it is better to leave this set to sequential, and
adjust the new card gather order instead. */
    override fun deckConfigNewInsertionOrderRandomWithV3(): String {
        return """With the v3 scheduler, it is better to leave this set to sequential, and
adjust the new card gather order instead."""
    }


    /** Sequential (oldest cards first) */
    override fun deckConfigNewInsertionOrderSequential(): String {
        return """Sequential (oldest cards first)"""
    }


    /** Controls the position (due #) new cards are assigned when you add new cards.
Cards with a lower due number will be shown first when studying. Changing
this option will automatically update the existing position of new cards. */
    override fun deckConfigNewInsertionOrderTooltip(): String {
        return """Controls the position (due #) new cards are assigned when you add new cards.
Cards with a lower due number will be shown first when studying. Changing
this option will automatically update the existing position of new cards."""
    }


    /** The multiplier applied to a review interval when answering `Again`. */
    override fun deckConfigNewIntervalTooltip(): String {
        return """The multiplier applied to a review interval when answering `Again`."""
    }


    /** The maximum number of new cards to introduce in a day, if new cards are available.
Because new material will increase your short-term review workload, this should typically
be at least 10x smaller than your review limit. */
    override fun deckConfigNewLimitTooltip(): String {
        return """The maximum number of new cards to introduce in a day, if new cards are available.
Because new material will increase your short-term review workload, this should typically
be at least 10x smaller than your review limit."""
    }


    /** New/review order */
    override fun deckConfigNewReviewPriority(): String {
        return """New/review order"""
    }


    /** When to show new cards in relation to review cards. */
    override fun deckConfigNewReviewPriorityTooltip(): String {
        return """When to show new cards in relation to review cards."""
    }


    /** Insufficient review history to perform this operation. */
    override fun deckConfigNotEnoughHistory(): String {
        return """Insufficient review history to perform this operation."""
    }


    /** You can optimize all presets at once by using the dropdown button next to "Save". */
    override fun deckConfigOptimizeAllTip(): String {
        return """You can optimize all presets at once by using the dropdown button next to "Save"."""
    }


    /** Optimize Current Preset */
    override fun deckConfigOptimizeButton(): String {
        return """Optimize Current Preset"""
    }


    /** Optimizing preset {$current_count}/{$total_count}... */
    override fun deckConfigOptimizingPreset(`currentCount`: Int, `totalCount`: Int): String {
        return """Optimizing preset ${`currentCount`}/${`totalCount`}..."""
    }


    /** Display Order */
    override fun deckConfigOrderingTitle(): String {
        return """Display Order"""
    }


    /** {$pct}% */
    override fun deckConfigPercentInput(`pct`: String): String {
        return """${`pct`}%"""
    }


    /** {$pct}% of {$reviews} reviews */
    override fun deckConfigPercentOfReviews(`reviews`: Int, `pct`: String): String {
        return """${`pct`}% of ${`reviews`} reviews"""
    }


    /** Default parameters
(Press "" periodically to allow FSRS to better adjust to your memory) */
    override fun deckConfigPlaceholderParameters(): String {
        return """Default parameters
(Press "" periodically to allow FSRS to better adjust to your memory)"""
    }


    /** Please save your changes first. */
    override fun deckConfigPleaseSaveYourChangesFirst(): String {
        return """Please save your changes first."""
    }


    /** (Plotted on the X-axis) */
    override fun deckConfigPlottedOnXAxis(): String {
        return """(Plotted on the X-axis)"""
    }


    /** Minimum recommended retention: {$num} */
    override fun deckConfigPredictedMinimumRecommendedRetention(`num`: TranslateArg): String {
        return """Minimum recommended retention: ${`num`}"""
    }


    /** Minimum recommended retention: {$num} */
    override fun deckConfigPredictedOptimalRetention(`num`: TranslateArg): String {
        return """Minimum recommended retention: ${`num`}"""
    }


    /** Question action */
    override fun deckConfigQuestionAction(): String {
        return """Question action"""
    }


    /** Show Answer */
    override fun deckConfigQuestionActionShowAnswer(): String {
        return """Show Answer"""
    }


    /** Show Reminder */
    override fun deckConfigQuestionActionShowReminder(): String {
        return """Show Reminder"""
    }


    /** The action to perform after the question is shown, and time has elapsed. */
    override fun deckConfigQuestionActionToolTip(): String {
        return """The action to perform after the question is shown, and time has elapsed."""
    }


    /** Relearning steps */
    override fun deckConfigRelearningSteps(): String {
        return """Relearning steps"""
    }


    /** The minimum lapse interval should be at least as long as your final relearning step. */
    override fun deckConfigRelearningStepsAboveMinimumInterval(): String {
        return """The minimum lapse interval should be at least as long as your final relearning step."""
    }


    /** Zero or more delays, separated by spaces. By default, pressing the `Again`
button on a review card will show it again 10 minutes later. If no delays
are provided, the card will have its interval changed, without entering
relearning.  */
    override fun deckConfigRelearningStepsTooltip(): String {
        return """Zero or more delays, separated by spaces. By default, pressing the `Again`
button on a review card will show it again 10 minutes later. If no delays
are provided, the card will have its interval changed, without entering
relearning. """
    }


    /** Remove Preset */
    override fun deckConfigRemoveGroup(): String {
        return """Remove Preset"""
    }


    /** Rename Preset */
    override fun deckConfigRenameGroup(): String {
        return """Rename Preset"""
    }


    /** Reschedule cards on change */
    override fun deckConfigRescheduleCardsOnChange(): String {
        return """Reschedule cards on change"""
    }


    /** Affects the entire collection, and is not saved.

This option controls whether the due dates of cards will be changed when you enable FSRS, or optimize
the parameters. The default is not to reschedule cards: future reviews will use the new scheduling, but
there will be no immediate change to your workload. If rescheduling is enabled, the due dates of cards
will be changed. */
    override fun deckConfigRescheduleCardsOnChangeTooltip(): String {
        return """Affects the entire collection, and is not saved.

This option controls whether the due dates of cards will be changed when you enable FSRS, or optimize
the parameters. The default is not to reschedule cards: future reviews will use the new scheduling, but
there will be no immediate change to your workload. If rescheduling is enabled, the due dates of cards
will be changed."""
    }


    /** Depending on your desired retention, this can result in a large number of cards becoming
due, so is not recommended when first switching from SM-2.

Use this option sparingly, as it will add a review entry to each of your cards, and
increase the size of your collection. */
    override fun deckConfigRescheduleCardsWarning(): String {
        return """Depending on your desired retention, this can result in a large number of cards becoming
due, so is not recommended when first switching from SM-2.

Use this option sparingly, as it will add a review entry to each of your cards, and
increase the size of your collection."""
    }


    /** Restore this setting to its default value? */
    override fun deckConfigRevertButtonTooltip(): String {
        return """Restore this setting to its default value?"""
    }


    /** The maximum number of review cards to show in a day,
if cards are ready for review. */
    override fun deckConfigReviewLimitTooltip(): String {
        return """The maximum number of review cards to show in a day,
if cards are ready for review."""
    }


    /** Mix with reviews */
    override fun deckConfigReviewMixMixWithReviews(): String {
        return """Mix with reviews"""
    }


    /** Show after reviews */
    override fun deckConfigReviewMixShowAfterReviews(): String {
        return """Show after reviews"""
    }


    /** Show before reviews */
    override fun deckConfigReviewMixShowBeforeReviews(): String {
        return """Show before reviews"""
    }


    /** Review sort order */
    override fun deckConfigReviewSortOrder(): String {
        return """Review sort order"""
    }


    /** The default order prioritizes cards that have been waiting longest, so that
if you have a backlog of reviews, the longest-waiting ones will appear
first. If you have a large backlog that will take more than a few days to
clear, or wish to see cards in subdeck order, you may find the alternate
sort orders preferable. */
    override fun deckConfigReviewSortOrderTooltip(): String {
        return """The default order prioritizes cards that have been waiting longest, so that
if you have a backlog of reviews, the longest-waiting ones will appear
first. If you have a large backlog that will take more than a few days to
clear, or wish to see cards in subdeck order, you may find the alternate
sort orders preferable."""
    }


    /** If adding {$cards} new cards each day, your review limit should be at least {$expected}. */
    override fun deckConfigReviewsTooLow(`cards`: Int, `expected`: TranslateArg): String {
        return """If adding ${`cards`} new cards each day, your review limit should be at least ${`expected`}."""
    }


    /** Optimize All Presets */
    override fun deckConfigSaveAndOptimize(): String {
        return """Optimize All Presets"""
    }


    /** Save */
    override fun deckConfigSaveButton(): String {
        return """Save"""
    }


    /** Save Changes to Preset */
    override fun deckConfigSaveOptionsToPreset(): String {
        return """Save Changes to Preset"""
    }


    /** Overwrite the options in your current preset with the options that are currently set in the simulator? */
    override fun deckConfigSaveOptionsToPresetConfirm(): String {
        return """Overwrite the options in your current preset with the options that are currently set in the simulator?"""
    }


    /** Save to All Subdecks */
    override fun deckConfigSaveToAllSubdecks(): String {
        return """Save to All Subdecks"""
    }


    /** Seconds to show answer for */
    override fun deckConfigSecondsToShowAnswer(): String {
        return """Seconds to show answer for"""
    }


    /** When auto advance is activated, the number of seconds to wait before applying the answer action. Set to 0 to disable. */
    override fun deckConfigSecondsToShowAnswerTooltip2(): String {
        return """When auto advance is activated, the number of seconds to wait before applying the answer action. Set to 0 to disable."""
    }


    /** Seconds to show question for */
    override fun deckConfigSecondsToShowQuestion(): String {
        return """Seconds to show question for"""
    }


    /** When auto advance is activated, the number of seconds to wait before revealing the answer. Set to 0 to disable. */
    override fun deckConfigSecondsToShowQuestionTooltip(): String {
        return """When auto advance is activated, the number of seconds to wait before revealing the answer. Set to 0 to disable."""
    }


    /** When auto advance is activated, the number of seconds to wait before revealing the answer. Set to 0 to disable. */
    override fun deckConfigSecondsToShowQuestionTooltip2(): String {
        return """When auto advance is activated, the number of seconds to wait before revealing the answer. Set to 0 to disable."""
    }


    /** When auto advance is activated, the number of seconds to wait before applying the question action. Set to 0 to disable. */
    override fun deckConfigSecondsToShowQuestionTooltip3(): String {
        return """When auto advance is activated, the number of seconds to wait before applying the question action. Set to 0 to disable."""
    }


    /** Preset */
    override fun deckConfigSharedPreset(): String {
        return """Preset"""
    }


    /** On the Study screen, show a timer that counts the time you're
taking to study each card. */
    override fun deckConfigShowAnswerTimerTooltip(): String {
        return """On the Study screen, show a timer that counts the time you're
taking to study each card."""
    }


    /** Show Reminder */
    override fun deckConfigShowReminder(): String {
        return """Show Reminder"""
    }


    /** Simulate */
    override fun deckConfigSimulate(): String {
        return """Simulate"""
    }


    /** Skip question when replaying answer */
    override fun deckConfigSkipQuestionWhenReplaying(): String {
        return """Skip question when replaying answer"""
    }


    /** {$text} (slow) */
    override fun deckConfigSlowSuffix(`text`: String): String {
        return """${`text`} (slow)"""
    }


    /** Smaller numbers indicate a better fit to your review history. */
    override fun deckConfigSmallerIsBetter(): String {
        return """Smaller numbers indicate a better fit to your review history."""
    }


    /** Smooth graph */
    override fun deckConfigSmoothGraph(): String {
        return """Smooth graph"""
    }


    /** Easy cards first */
    override fun deckConfigSortOrderAscendingDifficulty(): String {
        return """Easy cards first"""
    }


    /** Ascending ease */
    override fun deckConfigSortOrderAscendingEase(): String {
        return """Ascending ease"""
    }


    /** Ascending intervals */
    override fun deckConfigSortOrderAscendingIntervals(): String {
        return """Ascending intervals"""
    }


    /** Card type, then random */
    override fun deckConfigSortOrderCardTemplateThenRandom(): String {
        return """Card type, then random"""
    }


    /** Deck, then due date */
    override fun deckConfigSortOrderDeckThenDueDate(): String {
        return """Deck, then due date"""
    }


    /** Difficult cards first */
    override fun deckConfigSortOrderDescendingDifficulty(): String {
        return """Difficult cards first"""
    }


    /** Descending ease */
    override fun deckConfigSortOrderDescendingEase(): String {
        return """Descending ease"""
    }


    /** Descending intervals */
    override fun deckConfigSortOrderDescendingIntervals(): String {
        return """Descending intervals"""
    }


    /** Due date, then deck */
    override fun deckConfigSortOrderDueDateThenDeck(): String {
        return """Due date, then deck"""
    }


    /** Due date, then random */
    override fun deckConfigSortOrderDueDateThenRandom(): String {
        return """Due date, then random"""
    }


    /** Order gathered */
    override fun deckConfigSortOrderGather(): String {
        return """Order gathered"""
    }


    /** Random */
    override fun deckConfigSortOrderRandom(): String {
        return """Random"""
    }


    /** Random note, then card type */
    override fun deckConfigSortOrderRandomNoteThenTemplate(): String {
        return """Random note, then card type"""
    }


    /** Ascending retrievability */
    override fun deckConfigSortOrderRetrievabilityAscending(): String {
        return """Ascending retrievability"""
    }


    /** Descending retrievability */
    override fun deckConfigSortOrderRetrievabilityDescending(): String {
        return """Descending retrievability"""
    }


    /** Card type, then order gathered */
    override fun deckConfigSortOrderTemplateThenGather(): String {
        return """Card type, then order gathered"""
    }


    /** The ease multiplier new cards start with. By default, the `Good` button on a
newly-learned card will delay the next review by 2.5x the previous delay. */
    override fun deckConfigStartingEaseTooltip(): String {
        return """The ease multiplier new cards start with. By default, the `Good` button on a
newly-learned card will delay the next review by 2.5x the previous delay."""
    }


    /** When FSRS is enabled, steps of 1 day or more are not recommended. */
    override fun deckConfigStepsTooLargeForFsrs(): String {
        return """When FSRS is enabled, steps of 1 day or more are not recommended."""
    }


    /** Stop on-screen timer on answer */
    override fun deckConfigStopTimerOnAnswer(): String {
        return """Stop on-screen timer on answer"""
    }


    /** Whether to stop the on-screen timer when the answer is revealed.
This doesn't affect statistics. */
    override fun deckConfigStopTimerOnAnswerTooltip(): String {
        return """Whether to stop the on-screen timer when the answer is revealed.
This doesn't affect statistics."""
    }


    /** Suspend leeches */
    override fun deckConfigSuspendLeeches(): String {
        return """Suspend leeches"""
    }


    /** - `Preset`: The limit applies to all decks using this preset.
- `This deck`: The limit is specific to this deck.
- `Today only`: Make a temporary change to this deck's limit. */
    override fun deckConfigTabDescription(): String {
        return """- `Preset`: The limit applies to all decks using this preset.
- `This deck`: The limit is specific to this deck.
- `Today only`: Make a temporary change to this deck's limit."""
    }


    /** It's been a while - using the Optimize All Presets button is recommended. */
    override fun deckConfigTimeToOptimize(): String {
        return """It's been a while - using the Optimize All Presets button is recommended."""
    }


    /** Timers */
    override fun deckConfigTimerTitle(): String {
        return """Timers"""
    }


    /** Deck Options */
    override fun deckConfigTitle(): String {
        return """Deck Options"""
    }


    /** Today only */
    override fun deckConfigTodayOnly(): String {
        return """Today only"""
    }


    /** A maximum interval less than 6 months is not recommended. */
    override fun deckConfigTooShortMaximumInterval(): String {
        return """A maximum interval less than 6 months is not recommended."""
    }


    /** Unable to determine a minimum recommended retention. */
    override fun deckConfigUnableToDetermineDesiredRetention(): String {
        return """Unable to determine a minimum recommended retention."""
    }


    /** Updating cards: {$current_cards_count}/{$total_cards_count}... */
    override fun deckConfigUpdatingCards(`currentCardsCount`: Int, `totalCardsCount`: Int): String {
        return """Updating cards: ${`currentCardsCount`}/${`totalCardsCount`}..."""
    }


    /** used by {$decks} decks */
    override fun deckConfigUsedByDecks(`decks`: Int): String {
        return """used by ${`decks`} decks"""
    }


    /** Wait for audio */
    override fun deckConfigWaitForAudio(): String {
        return """Wait for audio"""
    }


    /** Wait for audio to finish before automatically revealing answer or next question. */
    override fun deckConfigWaitForAudioTooltip(): String {
        return """Wait for audio to finish before automatically revealing answer or next question."""
    }


    /** Wait for audio to finish before automatically applying the question action or answer action. */
    override fun deckConfigWaitForAudioTooltip2(): String {
        return """Wait for audio to finish before automatically applying the question action or answer action."""
    }


    /** FSRS parameters */
    override fun deckConfigWeights(): String {
        return """FSRS parameters"""
    }


    /** FSRS parameters affect how cards are scheduled. Anki will start with default parameters. Once
you've accumulated 1000+ reviews, you can use the option below to optimize the parameters to best
match your performance in decks using this preset. */
    override fun deckConfigWeightsTooltip(): String {
        return """FSRS parameters affect how cards are scheduled. Anki will start with default parameters. Once
you've accumulated 1000+ reviews, you can use the option below to optimize the parameters to best
match your performance in decks using this preset."""
    }


    /** FSRS parameters affect how cards are scheduled. Anki will start with default parameters. You can use 
the option below to optimize the parameters to best match your performance in decks using this preset. */
    override fun deckConfigWeightsTooltip2(): String {
        return """FSRS parameters affect how cards are scheduled. Anki will start with default parameters. You can use 
the option below to optimize the parameters to best match your performance in decks using this preset."""
    }


    /** Which deck would you like to display options for? */
    override fun deckConfigWhichDeck(): String {
        return """Which deck would you like to display options for?"""
    }


    /** The requested change will require a one-way sync. If you have made changes
on another device, and not synced them to this device yet, please do so before
you proceed. */
    override fun deckConfigWillRequireFullSync(): String {
        return """The requested change will require a one-way sync. If you have made changes
on another device, and not synced them to this device yet, please do so before
you proceed."""
    }


    /** Approximate workload: {$factor}x
(compared to {$previousDR}% desired retention) */
    override fun deckConfigWorkloadFactorChange(`factor`: String, `previousDr`: String): String {
        return """Approximate workload: ${`factor`}x
(compared to ${`previousDr`}% desired retention)"""
    }


    /** The higher your desired retention, the more frequently cards will be shown to you. */
    override fun deckConfigWorkloadFactorUnchanged(): String {
        return """The higher your desired retention, the more frequently cards will be shown to you."""
    }


    /** Add New Deck (Ctrl+N) */
    override fun decksAddNewDeckCtrlandn(): String {
        return """Add New Deck (Ctrl+N)"""
    }


    /** Build */
    override fun decksBuild(): String {
        return """Build"""
    }


    /** cards selected by */
    override fun decksCardsSelectedBy(): String {
        return """cards selected by"""
    }


    /** Choose Deck */
    override fun decksChooseDeck(): String {
        return """Choose Deck"""
    }


    /** Create Deck */
    override fun decksCreateDeck(): String {
        return """Create Deck"""
    }


    /** Custom steps (in minutes) */
    override fun decksCustomStepsInMinutes(): String {
        return """Custom steps (in minutes)"""
    }


    /** Deck */
    override fun decksDeck(): String {
        return """Deck"""
    }


    /** Decreasing intervals */
    override fun decksDecreasingIntervals(): String {
        return """Decreasing intervals"""
    }


    /** Delay for {$button} */
    override fun decksDelayForButton(`button`: String): String {
        return """Delay for ${`button`}"""
    }


    /** Delete Deck */
    override fun decksDeleteDeck(): String {
        return """Delete Deck"""
    }


    /** Enable second filter */
    override fun decksEnableSecondFilter(): String {
        return """Enable second filter"""
    }


    /** Filter: */
    override fun decksFilter(): String {
        return """Filter:"""
    }


    /** Filter 2 */
    override fun decksFilter2(): String {
        return """Filter 2"""
    }


    /** No cards matched the provided search. Some cards may have been excluded because they are in a different filtered deck, or suspended. */
    override fun decksFilteredDeckSearchEmpty(): String {
        return """No cards matched the provided search. Some cards may have been excluded because they are in a different filtered deck, or suspended."""
    }


    /** Get Shared */
    override fun decksGetShared(): String {
        return """Get Shared"""
    }


    /** Import File */
    override fun decksImportFile(): String {
        return """Import File"""
    }


    /** Increasing intervals */
    override fun decksIncreasingIntervals(): String {
        return """Increasing intervals"""
    }


    /** Latest added first */
    override fun decksLatestAddedFirst(): String {
        return """Latest added first"""
    }


    /** Learn */
    override fun decksLearnHeader(): String {
        return """Learn"""
    }


    /** Limit to */
    override fun decksLimitTo(): String {
        return """Limit to"""
    }


    /** minutes */
    override fun decksMinutes(): String {
        return """minutes"""
    }


    /** Most lapses */
    override fun decksMostLapses(): String {
        return """Most lapses"""
    }


    /** New deck name: */
    override fun decksNewDeckName(): String {
        return """New deck name:"""
    }


    /** [no deck] */
    override fun decksNoDeck(): String {
        return """[no deck]"""
    }


    /** Oldest seen first */
    override fun decksOldestSeenFirst(): String {
        return """Oldest seen first"""
    }


    /** Order added */
    override fun decksOrderAdded(): String {
        return """Order added"""
    }


    /** Order due */
    override fun decksOrderDue(): String {
        return """Order due"""
    }


    /** Please select something. */
    override fun decksPleaseSelectSomething(): String {
        return """Please select something."""
    }


    /** Random */
    override fun decksRandom(): String {
        return """Random"""
    }


    /** Relative overdueness */
    override fun decksRelativeOverdueness(): String {
        return """Relative overdueness"""
    }


    /** Delay Repeat failed cards after */
    override fun decksRepeatFailedCardsAfter(): String {
        return """Delay Repeat failed cards after"""
    }


    /** Reschedule cards based on my answers in this deck */
    override fun decksRescheduleCardsBasedOnMyAnswers(): String {
        return """Reschedule cards based on my answers in this deck"""
    }


    /** Due */
    override fun decksReviewHeader(): String {
        return """Due"""
    }


    /** Study */
    override fun decksStudy(): String {
        return """Study"""
    }


    /** Study Deck */
    override fun decksStudyDeck(): String {
        return """Study Deck"""
    }


    /** Target Deck (Ctrl+D) */
    override fun decksTargetDeckCtrlandd(): String {
        return """Target Deck (Ctrl+D)"""
    }


    /** Show any excluded cards */
    override fun decksUnmovableCards(): String {
        return """Show any excluded cards"""
    }


    /** (0 = return card to original deck) */
    override fun decksZeroMinutesHint(): String {
        return """(0 = return card to original deck)"""
    }


    /** Create/update this deck even if empty */
    override fun decksCreateEvenIfEmpty(): String {
        return """Create/update this deck even if empty"""
    }


    /** Toggle actual size */
    override fun editingActualSize(): String {
        return """Toggle actual size"""
    }


    /** Add Media */
    override fun editingAddMedia(): String {
        return """Add Media"""
    }


    /** Align left */
    override fun editingAlignLeft(): String {
        return """Align left"""
    }


    /** Align right */
    override fun editingAlignRight(): String {
        return """Align right"""
    }


    /** Alignment */
    override fun editingAlignment(): String {
        return """Alignment"""
    }


    /** An error occurred while opening {$val} */
    override fun editingAnErrorOccurredWhileOpening(`val`: TranslateArg): String {
        return """An error occurred while opening ${`val`}"""
    }


    /** Attach pictures/audio/video */
    override fun editingAttachPicturesaudiovideo(): String {
        return """Attach pictures/audio/video"""
    }


    /** Bold text */
    override fun editingBoldText(): String {
        return """Bold text"""
    }


    /** Cards */
    override fun editingCards(): String {
        return """Cards"""
    }


    /** Center */
    override fun editingCenter(): String {
        return """Center"""
    }


    /** Change color */
    override fun editingChangeColor(): String {
        return """Change color"""
    }


    /** Auto-close HTML tags */
    override fun editingCloseHtmlTags(): String {
        return """Auto-close HTML tags"""
    }


    /** Cloze deletion (new card) */
    override fun editingClozeDeletion(): String {
        return """Cloze deletion (new card)"""
    }


    /** Cloze deletion (same card) */
    override fun editingClozeDeletionRepeat(): String {
        return """Cloze deletion (same card)"""
    }


    /** Collapse */
    override fun editingCollapse(): String {
        return """Collapse"""
    }


    /** Collapse field */
    override fun editingCollapseField(): String {
        return """Collapse field"""
    }


    /** Copy image */
    override fun editingCopyImage(): String {
        return """Copy image"""
    }


    /** Couldn't record audio. Have you installed 'lame'? */
    override fun editingCouldntRecordAudioHaveYouInstalled(): String {
        return """Couldn't record audio. Have you installed 'lame'?"""
    }


    /** Customize Card Templates */
    override fun editingCustomizeCardTemplates(): String {
        return """Customize Card Templates"""
    }


    /** Customize Fields */
    override fun editingCustomizeFields(): String {
        return """Customize Fields"""
    }


    /** Cut */
    override fun editingCut(): String {
        return """Cut"""
    }


    /** double-click image */
    override fun editingDoubleClickImage(): String {
        return """double-click image"""
    }


    /** double-click to collapse */
    override fun editingDoubleClickToCollapse(): String {
        return """double-click to collapse"""
    }


    /** double-click to expand */
    override fun editingDoubleClickToExpand(): String {
        return """double-click to expand"""
    }


    /** Edit Current */
    override fun editingEditCurrent(): String {
        return """Edit Current"""
    }


    /** Edit HTML */
    override fun editingEditHtml(): String {
        return """Edit HTML"""
    }


    /** Equations */
    override fun editingEquations(): String {
        return """Equations"""
    }


    /** Expand */
    override fun editingExpand(): String {
        return """Expand"""
    }


    /** Expand field */
    override fun editingExpandField(): String {
        return """Expand field"""
    }


    /** Fields */
    override fun editingFields(): String {
        return """Fields"""
    }


    /** Float left */
    override fun editingFloatLeft(): String {
        return """Float left"""
    }


    /** No float */
    override fun editingFloatNone(): String {
        return """No float"""
    }


    /** Float right */
    override fun editingFloatRight(): String {
        return """Float right"""
    }


    /** From Clipboard */
    override fun editingFromClipboard(): String {
        return """From Clipboard"""
    }


    /** HTML Editor */
    override fun editingHtmlEditor(): String {
        return """HTML Editor"""
    }


    /** Align Bottom */
    override fun editingImageOcclusionAlignBottom(): String {
        return """Align Bottom"""
    }


    /** Align Horizontal Centers */
    override fun editingImageOcclusionAlignHCenter(): String {
        return """Align Horizontal Centers"""
    }


    /** Align Left */
    override fun editingImageOcclusionAlignLeft(): String {
        return """Align Left"""
    }


    /** Align Right */
    override fun editingImageOcclusionAlignRight(): String {
        return """Align Right"""
    }


    /** Align Top */
    override fun editingImageOcclusionAlignTop(): String {
        return """Align Top"""
    }


    /** Align Vertical Centers */
    override fun editingImageOcclusionAlignVCenter(): String {
        return """Align Vertical Centers"""
    }


    /** Alignment */
    override fun editingImageOcclusionAlignment(): String {
        return """Alignment"""
    }


    /** Are you sure you want to reset this image occlusion? */
    override fun editingImageOcclusionConfirmReset(): String {
        return """Are you sure you want to reset this image occlusion?"""
    }


    /** Delete */
    override fun editingImageOcclusionDelete(): String {
        return """Delete"""
    }


    /** Duplicate */
    override fun editingImageOcclusionDuplicate(): String {
        return """Duplicate"""
    }


    /** Ellipse */
    override fun editingImageOcclusionEllipseTool(): String {
        return """Ellipse"""
    }


    /** Fill with colour */
    override fun editingImageOcclusionFillTool(): String {
        return """Fill with colour"""
    }


    /** Group Selection */
    override fun editingImageOcclusionGroup(): String {
        return """Group Selection"""
    }


    /** Image Occlusion Mode */
    override fun editingImageOcclusionMode(): String {
        return """Image Occlusion Mode"""
    }


    /** Polygon */
    override fun editingImageOcclusionPolygonTool(): String {
        return """Polygon"""
    }


    /** Rectangle */
    override fun editingImageOcclusionRectangleTool(): String {
        return """Rectangle"""
    }


    /** Reset Image Occlusion */
    override fun editingImageOcclusionReset(): String {
        return """Reset Image Occlusion"""
    }


    /** Select All */
    override fun editingImageOcclusionSelectAll(): String {
        return """Select All"""
    }


    /** Select */
    override fun editingImageOcclusionSelectTool(): String {
        return """Select"""
    }


    /** Text */
    override fun editingImageOcclusionTextTool(): String {
        return """Text"""
    }


    /** Toggle Mask Editor */
    override fun editingImageOcclusionToggleMaskEditor(): String {
        return """Toggle Mask Editor"""
    }


    /** Toggle Translucency */
    override fun editingImageOcclusionToggleTranslucent(): String {
        return """Toggle Translucency"""
    }


    /** Ungroup Selection */
    override fun editingImageOcclusionUngroup(): String {
        return """Ungroup Selection"""
    }


    /** Zoom In */
    override fun editingImageOcclusionZoomIn(): String {
        return """Zoom In"""
    }


    /** Zoom Out */
    override fun editingImageOcclusionZoomOut(): String {
        return """Zoom Out"""
    }


    /** Reset Zoom */
    override fun editingImageOcclusionZoomReset(): String {
        return """Reset Zoom"""
    }


    /** Zoom */
    override fun editingImageOcclusionZoomTool(): String {
        return """Zoom"""
    }


    /** Increase indent */
    override fun editingIndent(): String {
        return """Increase indent"""
    }


    /** Italic text */
    override fun editingItalicText(): String {
        return """Italic text"""
    }


    /** Jump to tags with Ctrl+Shift+T */
    override fun editingJumpToTagsWithCtrlandshiftandt(): String {
        return """Jump to tags with Ctrl+Shift+T"""
    }


    /** Justify */
    override fun editingJustify(): String {
        return """Justify"""
    }


    /** LaTeX */
    override fun editingLatex(): String {
        return """LaTeX"""
    }


    /** LaTeX equation */
    override fun editingLatexEquation(): String {
        return """LaTeX equation"""
    }


    /** LaTeX math env. */
    override fun editingLatexMathEnv(): String {
        return """LaTeX math env."""
    }


    /** MathJax block */
    override fun editingMathjaxBlock(): String {
        return """MathJax block"""
    }


    /** MathJax chemistry */
    override fun editingMathjaxChemistry(): String {
        return """MathJax chemistry"""
    }


    /** MathJax inline */
    override fun editingMathjaxInline(): String {
        return """MathJax inline"""
    }


    /** Press {$accept} to accept, {$newline} for new line. */
    override fun editingMathjaxPlaceholder(`accept`: String, `newline`: String): String {
        return """Press ${`accept`} to accept, ${`newline`} for new line."""
    }


    /** MathJax Preview */
    override fun editingMathjaxPreview(): String {
        return """MathJax Preview"""
    }


    /** Media */
    override fun editingMedia(): String {
        return """Media"""
    }


    /** No image found on clipboard. */
    override fun editingNoImageFoundOnClipboard(): String {
        return """No image found on clipboard."""
    }


    /** Open image */
    override fun editingOpenImage(): String {
        return """Open image"""
    }


    /** Ordered list */
    override fun editingOrderedList(): String {
        return """Ordered list"""
    }


    /** Decrease indent */
    override fun editingOutdent(): String {
        return """Decrease indent"""
    }


    /** Paste */
    override fun editingPaste(): String {
        return """Paste"""
    }


    /** Record audio */
    override fun editingRecordAudio(): String {
        return """Record audio"""
    }


    /** Remove formatting */
    override fun editingRemoveFormatting(): String {
        return """Remove formatting"""
    }


    /** Restore original size */
    override fun editingRestoreOriginalSize(): String {
        return """Restore original size"""
    }


    /** Select formatting to remove */
    override fun editingSelectRemoveFormatting(): String {
        return """Select formatting to remove"""
    }


    /** Show Duplicates */
    override fun editingShowDuplicates(): String {
        return """Show Duplicates"""
    }


    /** Show in folder */
    override fun editingShowInFolder(): String {
        return """Show in folder"""
    }


    /** Shrink Images */
    override fun editingShrinkImages(): String {
        return """Shrink Images"""
    }


    /** Subscript */
    override fun editingSubscript(): String {
        return """Subscript"""
    }


    /** Superscript */
    override fun editingSuperscript(): String {
        return """Superscript"""
    }


    /** {$count} tags */
    override fun editingTagCount(`count`: Int): String {
        return """${`count`} tags"""
    }


    /** Tags */
    override fun editingTags(): String {
        return """Tags"""
    }


    /** Add tag */
    override fun editingTagsAdd(): String {
        return """Add tag"""
    }


    /** Copy tags */
    override fun editingTagsCopy(): String {
        return """Copy tags"""
    }


    /** Remove tags */
    override fun editingTagsRemove(): String {
        return """Remove tags"""
    }


    /** Select all tags */
    override fun editingTagsSelectAll(): String {
        return """Select all tags"""
    }


    /** Text color */
    override fun editingTextColor(): String {
        return """Text color"""
    }


    /** Text highlight color */
    override fun editingTextHighlightColor(): String {
        return """Text highlight color"""
    }


    /** To make a cloze deletion on an existing note, you need to change it to a cloze type first, via 'Notes>Change Note Type' */
    override fun editingToMakeAClozeDeletionOn(): String {
        return """To make a cloze deletion on an existing note, you need to change it to a cloze type first, via 'Notes>Change Note Type'"""
    }


    /** Toggle HTML Editor */
    override fun editingToggleHtmlEditor(): String {
        return """Toggle HTML Editor"""
    }


    /** Toggle sticky */
    override fun editingToggleSticky(): String {
        return """Toggle sticky"""
    }


    /** Toggle Visual Editor */
    override fun editingToggleVisualEditor(): String {
        return """Toggle Visual Editor"""
    }


    /** Underline text */
    override fun editingUnderlineText(): String {
        return """Underline text"""
    }


    /** Unordered list */
    override fun editingUnorderedList(): String {
        return """Unordered list"""
    }


    /** Warning, cloze deletions will not work until you switch the type at the top to Cloze. */
    override fun editingWarningClozeDeletionsWillNotWork(): String {
        return """Warning, cloze deletions will not work until you switch the type at the top to Cloze."""
    }


    /** {$empty_count} of {$existing_count} cards empty ({$template_names}). */
    override fun emptyCardsCountLine(`emptyCount`: Int, `existingCount`: Int, `templateNames`: String): String {
        return """${`emptyCount`} of ${`existingCount`} cards empty (${`templateNames`})."""
    }


    /** Delete */
    override fun emptyCardsDeleteButton(): String {
        return """Delete"""
    }


    /** Delete Empty Cards */
    override fun emptyCardsDeleteEmptyCards(): String {
        return """Delete Empty Cards"""
    }


    /** Delete Empty Notes */
    override fun emptyCardsDeleteEmptyNotes(): String {
        return """Delete Empty Notes"""
    }


    /** Deleted {$cards} cards. */
    override fun emptyCardsDeletedCount(`cards`: Int): String {
        return """Deleted ${`cards`} cards."""
    }


    /** Deleting... */
    override fun emptyCardsDeleting(): String {
        return """Deleting..."""
    }


    /** Empty cards for {$notetype}: */
    override fun emptyCardsForNoteType(`notetype`: String): String {
        return """Empty cards for ${`notetype`}:"""
    }


    /** No empty cards. */
    override fun emptyCardsNotFound(): String {
        return """No empty cards."""
    }


    /** Keep notes with no valid cards */
    override fun emptyCardsPreserveNotesCheckbox(): String {
        return """Keep notes with no valid cards"""
    }


    /** Empty Cards */
    override fun emptyCardsWindowTitle(): String {
        return """Empty Cards"""
    }


    /** A maximum of 100 tags can be selected. Listing the
tags you want instead of the ones you don't want is usually simpler, and there
is no need to select child tags if you have selected a parent tag. */
    override fun errors100TagsMax(): String {
        return """A maximum of 100 tags can be selected. Listing the
tags you want instead of the ones you don't want is usually simpler, and there
is no need to select child tags if you have selected a parent tag."""
    }


    /** An error occurred while accessing the database.

Possible causes:

- Antivirus, firewall, backup, or synchronization software may be
interfering with Anki. Try disabling such software and see if the
problem goes away.
- Your disk may be full.
- The Documents/Anki folder may be on a network drive.
- Files in the Documents/Anki folder may not be writeable.
- Your hard disk may have errors.

It's a good idea to run Tools>Check Database to ensure your collection is not corrupt. */
    override fun errorsAccessingDb(): String {
        return """An error occurred while accessing the database.

Possible causes:

- Antivirus, firewall, backup, or synchronization software may be
interfering with Anki. Try disabling such software and see if the
problem goes away.
- Your disk may be full.
- The Documents/Anki folder may be on a network drive.
- Files in the Documents/Anki folder may not be writeable.
- Your hard disk may have errors.

It's a good idea to run Tools>Check Database to ensure your collection is not corrupt."""
    }


    /** # Error

An error occurred. Please start Anki while holding down the shift key,
which will temporarily disable the add-ons you have installed.

If the issue only occurs when add-ons are enabled, please use the
Tools > Add-ons menu item to disable some add-ons and restart Anki,
repeating until you discover the add-on that is causing the problem.

When you've discovered the add-on that is causing the problem, please
report the issue to the add-on author.

Debug info: */
    override fun errorsAddonsActivePopup(): String {
        return """# Error

An error occurred. Please start Anki while holding down the shift key,
which will temporarily disable the add-ons you have installed.

If the issue only occurs when add-ons are enabled, please use the
Tools > Add-ons menu item to disable some add-ons and restart Anki,
repeating until you discover the add-on that is causing the problem.

When you've discovered the add-on that is causing the problem, please
report the issue to the add-on author.

Debug info:"""
    }


    /** Error in directive '{$directive}': {$error} */
    override fun errorsBadDirective(`directive`: String, `error`: String): String {
        return """Error in directive '${`directive`}': ${`error`}"""
    }


    /** This collection requires a newer version of Anki to open. */
    override fun errorsCollectionTooNew(): String {
        return """This collection requires a newer version of Anki to open."""
    }


    /** Copied to clipboard */
    override fun errorsCopiedToClipboard(): String {
        return """Copied to clipboard"""
    }


    /** Copy Debug Info */
    override fun errorsCopyDebugInfoButton(): String {
        return """Copy Debug Info"""
    }


    /** This action can only be used on a filtered deck. */
    override fun errorsFilteredDeckRequired(): String {
        return """This action can only be used on a filtered deck."""
    }


    /** Filtered decks can not have child decks. */
    override fun errorsFilteredParentDeck(): String {
        return """Filtered decks can not have child decks."""
    }


    /** Your database appears to be in an inconsistent state. Please use the Check Database action. */
    override fun errorsInconsistentDbState(): String {
        return """Your database appears to be in an inconsistent state. Please use the Check Database action."""
    }


    /** This deck contains timestamps in the future. Please contact the deck author and ask them to fix the issue. */
    override fun errorsInvalidIds(): String {
        return """This deck contains timestamps in the future. Please contact the deck author and ask them to fix the issue."""
    }


    /** Invalid input: {$details} */
    override fun errorsInvalidInputDetails(`details`: String): String {
        return """Invalid input: ${`details`}"""
    }


    /** Invalid input. */
    override fun errorsInvalidInputEmpty(): String {
        return """Invalid input."""
    }


    /** The problem may be caused by an add-on. */
    override fun errorsMayBeAddon(): String {
        return """The problem may be caused by an add-on."""
    }


    /** Please select notes from only one note type. */
    override fun errorsMultipleNotetypesSelected(): String {
        return """Please select notes from only one note type."""
    }


    /** No updates available. */
    override fun errorsNoUpdatesAvailable(): String {
        return """No updates available."""
    }


    /** '{$option}' not set */
    override fun errorsOptionNotSet(`option`: String): String {
        return """'${`option`}' not set"""
    }


    /** A number was invalid or out of range. */
    override fun errorsParseNumberFail(): String {
        return """A number was invalid or out of range."""
    }


    /** Please use the Check Database action, then try again. */
    override fun errorsPleaseCheckDatabase(): String {
        return """Please use the Check Database action, then try again."""
    }


    /** Please use the Check Media action, then try again. */
    override fun errorsPleaseCheckMedia(): String {
        return """Please use the Check Media action, then try again."""
    }


    /** # Error

An error occurred. Please use **Tools > Check Database** to see if
that fixes the problem.

If problems persist, please report the problem on our .
Please copy and paste the information below into your report. */
    override fun errorsStandardPopup(): String {
        return """# Error

An error occurred. Please use **Tools > Check Database** to see if
that fixes the problem.

If problems persist, please report the problem on our .
Please copy and paste the information below into your report."""
    }


    /** Anki encountered a problem. Please follow the troubleshooting steps. */
    override fun errorsStandardPopup2(): String {
        return """Anki encountered a problem. Please follow the troubleshooting steps."""
    }


    /** Troubleshooting */
    override fun errorsTroubleshootingButton(): String {
        return """Troubleshooting"""
    }


    /** Anki was unable to open your collection file. If problems persist after restarting your computer, please use the Open Backup button in the profile manager.

Debug info: */
    override fun errorsUnableOpenCollection(): String {
        return """Anki was unable to open your collection file. If problems persist after restarting your computer, please use the Open Backup button in the profile manager.

Debug info:"""
    }


    /** Secure connection failed. Please ensure Windows updates are installed, then try again. */
    override fun errorsWindowsSslUpdates(): String {
        return """Secure connection failed. Please ensure Windows updates are installed, then try again."""
    }


    /** The TTS service failed. Please ensure Windows updates are installed, try restarting your computer, or try a different voice. */
    override fun errorsWindowsTtsRuntimeError(): String {
        return """The TTS service failed. Please ensure Windows updates are installed, try restarting your computer, or try a different voice."""
    }


    /** All Decks */
    override fun exportingAllDecks(): String {
        return """All Decks"""
    }


    /** Anki 2.0 Deck */
    override fun exportingAnki20Deck(): String {
        return """Anki 2.0 Deck"""
    }


    /** Anki Collection Package */
    override fun exportingAnkiCollectionPackage(): String {
        return """Anki Collection Package"""
    }


    /** Anki Deck Package */
    override fun exportingAnkiDeckPackage(): String {
        return """Anki Deck Package"""
    }


    /** {$count} cards exported. */
    override fun exportingCardExported(`count`: Int): String {
        return """${`count`} cards exported."""
    }


    /** Cards in Plain Text */
    override fun exportingCardsInPlainText(): String {
        return """Cards in Plain Text"""
    }


    /** collection */
    override fun exportingCollection(): String {
        return """collection"""
    }


    /** Collection exported. */
    override fun exportingCollectionExported(): String {
        return """Collection exported."""
    }


    /** Please update to the latest Anki version, then import the .colpkg/.apkg file again. */
    override fun exportingColpkgTooNew(): String {
        return """Please update to the latest Anki version, then import the .colpkg/.apkg file again."""
    }


    /** Couldn't save file: {$val} */
    override fun exportingCouldntSaveFile(`val`: TranslateArg): String {
        return """Couldn't save file: ${`val`}"""
    }


    /** Export... */
    override fun exportingExport(): String {
        return """Export..."""
    }


    /** <b>Export format</b>: */
    override fun exportingExportFormat(): String {
        return """<b>Export format</b>:"""
    }


    /** Exported {$count} media files */
    override fun exportingExportedMediaFile(`count`: Int): String {
        return """Exported ${`count`} media files"""
    }


    /** Exporting file... */
    override fun exportingExportingFile(): String {
        return """Exporting file..."""
    }


    /** <b>Include</b>: */
    override fun exportingInclude(): String {
        return """<b>Include</b>:"""
    }


    /** Include deck name */
    override fun exportingIncludeDeck(): String {
        return """Include deck name"""
    }


    /** Include deck presets */
    override fun exportingIncludeDeckConfigs(): String {
        return """Include deck presets"""
    }


    /** Include unique identifier */
    override fun exportingIncludeGuid(): String {
        return """Include unique identifier"""
    }


    /** Include HTML and media references */
    override fun exportingIncludeHtmlAndMediaReferences(): String {
        return """Include HTML and media references"""
    }


    /** Include media */
    override fun exportingIncludeMedia(): String {
        return """Include media"""
    }


    /** Include note type name */
    override fun exportingIncludeNotetype(): String {
        return """Include note type name"""
    }


    /** Include scheduling information */
    override fun exportingIncludeSchedulingInformation(): String {
        return """Include scheduling information"""
    }


    /** Include tags */
    override fun exportingIncludeTags(): String {
        return """Include tags"""
    }


    /** {$count} notes exported. */
    override fun exportingNoteExported(`count`: Int): String {
        return """${`count`} notes exported."""
    }


    /** Notes in Plain Text */
    override fun exportingNotesInPlainText(): String {
        return """Notes in Plain Text"""
    }


    /** Processed {$count} media files... */
    override fun exportingProcessedMediaFiles(`count`: Int): String {
        return """Processed ${`count`} media files..."""
    }


    /** Selected Notes */
    override fun exportingSelectedNotes(): String {
        return """Selected Notes"""
    }


    /** Support older Anki versions (slower/larger files) */
    override fun exportingSupportOlderAnkiVersions(): String {
        return """Support older Anki versions (slower/larger files)"""
    }


    /** Add Field */
    override fun fieldsAddField(): String {
        return """Add Field"""
    }


    /** Collapse by default */
    override fun fieldsCollapseByDefault(): String {
        return """Collapse by default"""
    }


    /** Delete field from {$val}? */
    override fun fieldsDeleteFieldFrom(`val`: TranslateArg): String {
        return """Delete field from ${`val`}?"""
    }


    /** Description */
    override fun fieldsDescription(): String {
        return """Description"""
    }


    /** Text to show inside the field when it's empty */
    override fun fieldsDescriptionPlaceholder(): String {
        return """Text to show inside the field when it's empty"""
    }


    /** Editing Font */
    override fun fieldsEditingFont(): String {
        return """Editing Font"""
    }


    /** Exclude from unqualified searches (slower) */
    override fun fieldsExcludeFromSearch(): String {
        return """Exclude from unqualified searches (slower)"""
    }


    /** Field: */
    override fun fieldsField(): String {
        return """Field:"""
    }


    /** This is a required field, and can not be deleted. */
    override fun fieldsFieldIsRequired(): String {
        return """This is a required field, and can not be deleted."""
    }


    /** Field name: */
    override fun fieldsFieldName(): String {
        return """Field name:"""
    }


    /** Fields for {$val} */
    override fun fieldsFieldsFor(`val`: TranslateArg): String {
        return """Fields for ${`val`}"""
    }


    /** Font: */
    override fun fieldsFont(): String {
        return """Font:"""
    }


    /** Use HTML editor by default */
    override fun fieldsHtmlByDefault(): String {
        return """Use HTML editor by default"""
    }


    /** The field name should not start with #, ^ or /. */
    override fun fieldsNameFirstLetterNotValid(): String {
        return """The field name should not start with #, ^ or /."""
    }


    /** The field name should not contain :, ",  or . */
    override fun fieldsNameInvalidLetter(): String {
        return """The field name should not contain :, ",  or ."""
    }


    /** New position (1...{$val}): */
    override fun fieldsNewPosition1(`val`: TranslateArg): String {
        return """New position (1...${`val`}):"""
    }


    /** Notes require at least one field. */
    override fun fieldsNotesRequireAtLeastOneField(): String {
        return """Notes require at least one field."""
    }


    /** Reverse text direction (RTL) */
    override fun fieldsReverseTextDirectionRtl(): String {
        return """Reverse text direction (RTL)"""
    }


    /** Size: */
    override fun fieldsSize(): String {
        return """Size:"""
    }


    /** Sort by this field in the browser */
    override fun fieldsSortByThisFieldInThe(): String {
        return """Sort by this field in the browser"""
    }


    /** That field name is already used. */
    override fun fieldsThatFieldNameIsAlreadyUsed(): String {
        return """That field name is already used."""
    }


    /** {$changed} of {$total} notes updated */
    override fun findreplaceNotesUpdated(`total`: Int, `changed`: Int): String {
        return """${`changed`} of ${`total`} notes updated"""
    }


    /** For more information, see {$link} in the manual. */
    override fun helpForMoreInfo(`link`: String): String {
        return """For more information, see ${`link`} in the manual."""
    }


    /** Whoops! There doesn't seem to be an explanation for this setting yet.

You can help us complete this help page on {$link}. */
    override fun helpNoExplanation(`link`: String): String {
        return """Whoops! There doesn't seem to be an explanation for this setting yet.

You can help us complete this help page on ${`link`}."""
    }


    /** OK */
    override fun helpOk(): String {
        return """OK"""
    }


    /** Open {$name} in the manual */
    override fun helpOpenManualChapter(`name`: String): String {
        return """Open ${`name`} in the manual"""
    }


    /** Aborted: {$val} */
    override fun importingAborted(`val`: TranslateArg): String {
        return """Aborted: ${`val`}"""
    }


    /** Added */
    override fun importingAdded(): String {
        return """Added"""
    }


    /** Added duplicate with first field: {$val} */
    override fun importingAddedDuplicateWithFirstField(`val`: TranslateArg): String {
        return """Added duplicate with first field: ${`val`}"""
    }


    /** New note added */
    override fun importingAddedNewNote(): String {
        return """New note added"""
    }


    /** All supported formats {$val} */
    override fun importingAllSupportedFormats(`val`: TranslateArg): String {
        return """All supported formats ${`val`}"""
    }


    /** Allow HTML in fields */
    override fun importingAllowHtmlInFields(): String {
        return """Allow HTML in fields"""
    }


    /** Enable this if the file contains HTML formatting. E.g. if the file contains the string
'&lt;br&gt;', it will appear as a line break on your card. On the other hand, with this
option disabled, the literal characters '&lt;br&gt;' will be rendered. */
    override fun importingAllowHtmlInFieldsHelp(): String {
        return """Enable this if the file contains HTML formatting. E.g. if the file contains the string
'&lt;br&gt;', it will appear as a line break on your card. On the other hand, with this
option disabled, the literal characters '&lt;br&gt;' will be rendered."""
    }


    /** Import any learning progress */
    override fun importingAlsoImportProgress(): String {
        return """Import any learning progress"""
    }


    /** .anki files are from a very old version of Anki. You can import them with add-on 175027074 or with Anki 2.0, available on the Anki website. */
    override fun importingAnkiFilesAreFromAVery(): String {
        return """.anki files are from a very old version of Anki. You can import them with add-on 175027074 or with Anki 2.0, available on the Anki website."""
    }


    /** .anki2 files are not directly importable - please import the .apkg or .zip file you have received instead. */
    override fun importingAnki2FilesAreNotDirectlyImportable(): String {
        return """.anki2 files are not directly importable - please import the .apkg or .zip file you have received instead."""
    }


    /** Appeared twice in file: {$val} */
    override fun importingAppearedTwiceInFile(`val`: TranslateArg): String {
        return """Appeared twice in file: ${`val`}"""
    }


    /** By default, Anki will detect the character between fields, such as a tab, comma, and so on. If Anki is detecting the character incorrectly, you can enter it here. Use \t to represent tab. */
    override fun importingByDefaultAnkiWillDetectThe(): String {
        return """By default, Anki will detect the character between fields, such as a tab, comma, and so on. If Anki is detecting the character incorrectly, you can enter it here. Use \t to represent tab."""
    }


    /** Cloze note types cannot be merged with regular note types.
You may still import the file with '' disabled. */
    override fun importingCannotMergeNotetypesOfDifferentKinds(): String {
        return """Cloze note types cannot be merged with regular note types.
You may still import the file with '' disabled."""
    }


    /** {$count} cards added. */
    override fun importingCardsAdded(`count`: Int): String {
        return """${`count`} cards added."""
    }


    /** Change */
    override fun importingChange(): String {
        return """Change"""
    }


    /** Colon */
    override fun importingColon(): String {
        return """Colon"""
    }


    /** Comma */
    override fun importingComma(): String {
        return """Comma"""
    }


    /** {$count} notes were not imported, because their note type has changed. */
    override fun importingConflictingNotesSkipped(`count`: Int): String {
        return """${`count`} notes were not imported, because their note type has changed."""
    }


    /** {$count} notes were not imported, because their note type has changed, and '' was not enabled. */
    override fun importingConflictingNotesSkipped2(`count`: Int): String {
        return """${`count`} notes were not imported, because their note type has changed, and '' was not enabled."""
    }


    /** Imported cards will be placed in this deck. */
    override fun importingDeckHelp(): String {
        return """Imported cards will be placed in this deck."""
    }


    /** Details */
    override fun importingDetails(): String {
        return """Details"""
    }


    /** Duplicate */
    override fun importingDuplicate(): String {
        return """Duplicate"""
    }


    /** Duplicate note added */
    override fun importingDuplicateNoteAdded(): String {
        return """Duplicate note added"""
    }


    /** Empty first field: {$val} */
    override fun importingEmptyFirstField(`val`: TranslateArg): String {
        return """Empty first field: ${`val`}"""
    }


    /** Note skipped, as an up-to-date copy is already in your collection */
    override fun importingExistingNoteSkipped(): String {
        return """Note skipped, as an up-to-date copy is already in your collection"""
    }


    /** Existing notes */
    override fun importingExistingNotes(): String {
        return """Existing notes"""
    }


    /** What to do if an imported note matches an existing one.

- ``: Update the existing note.
- ``: Do nothing.
- ``: Create a new note. */
    override fun importingExistingNotesHelp(): String {
        return """What to do if an imported note matches an existing one.

- ``: Update the existing note.
- ``: Do nothing.
- ``: Create a new note."""
    }


    /** {$count} notes already present in your collection. */
    override fun importingExistingNotesSkipped(`count`: Int): String {
        return """${`count`} notes already present in your collection."""
    }


    /** Extracting data... */
    override fun importingExtracting(): String {
        return """Extracting data..."""
    }


    /** Import failed. Debugging info: */
    override fun importingFailedDebugInfo(): String {
        return """Import failed. Debugging info:"""
    }


    /** Failed to import media file: {$debugInfo} */
    override fun importingFailedToImportMediaFile(`debugInfo`: String): String {
        return """Failed to import media file: ${`debugInfo`}"""
    }


    /** Field mapping */
    override fun importingFieldMapping(): String {
        return """Field mapping"""
    }


    /** Field <b>{$val}</b> of file is: */
    override fun importingFieldOfFileIs(`val`: TranslateArg): String {
        return """Field <b>${`val`}</b> of file is:"""
    }


    /** Field separator */
    override fun importingFieldSeparator(): String {
        return """Field separator"""
    }


    /** Field separator (guessed) */
    override fun importingFieldSeparatorGuessed(): String {
        return """Field separator (guessed)"""
    }


    /** The character separating fields in the text file. You can use the preview to check
if the fields are separated correctly.

Please note that if this character appears in any field itself, the field has to be
quoted accordingly to the CSV standard. Spreadsheet programs like LibreOffice will
do this automatically.

It cannot be changed if the text file forces use of a specific separator via a file header.
If a file header is not present, Anki will try to guess what the separator is. */
    override fun importingFieldSeparatorHelp(): String {
        return """The character separating fields in the text file. You can use the preview to check
if the fields are separated correctly.

Please note that if this character appears in any field itself, the field has to be
quoted accordingly to the CSV standard. Spreadsheet programs like LibreOffice will
do this automatically.

It cannot be changed if the text file forces use of a specific separator via a file header.
If a file header is not present, Anki will try to guess what the separator is."""
    }


    /** Fields separated by: {$val} */
    override fun importingFieldsSeparatedBy(`val`: TranslateArg): String {
        return """Fields separated by: ${`val`}"""
    }


    /** File */
    override fun importingFile(): String {
        return """File"""
    }


    /** The file you selected is empty. */
    override fun importingFileEmpty(): String {
        return """The file you selected is empty."""
    }


    /** File must contain at least one column that can be mapped to a note field. */
    override fun importingFileMustContainFieldColumn(): String {
        return """File must contain at least one column that can be mapped to a note field."""
    }


    /** File version unknown, trying import anyway. */
    override fun importingFileVersionUnknownTryingImportAnyway(): String {
        return """File version unknown, trying import anyway."""
    }


    /** First field matched: {$val} */
    override fun importingFirstFieldMatched(`val`: TranslateArg): String {
        return """First field matched: ${`val`}"""
    }


    /** Gathering data... */
    override fun importingGathering(): String {
        return """Gathering data..."""
    }


    /** Identical */
    override fun importingIdentical(): String {
        return """Identical"""
    }


    /** Ignore field */
    override fun importingIgnoreField(): String {
        return """Ignore field"""
    }


    /** Ignore lines where first field matches existing note */
    override fun importingIgnoreLinesWhereFirstFieldMatches(): String {
        return """Ignore lines where first field matches existing note"""
    }


    /** <ignored> */
    override fun importingIgnored(): String {
        return """<ignored>"""
    }


    /** Import even if existing note has same first field */
    override fun importingImportEvenIfExistingNoteHas(): String {
        return """Import even if existing note has same first field"""
    }


    /** Import Log */
    override fun importingImportLog(): String {
        return """Import Log"""
    }


    /** Import options */
    override fun importingImportOptions(): String {
        return """Import options"""
    }


    /** Importing collection... */
    override fun importingImportingCollection(): String {
        return """Importing collection..."""
    }


    /** Importing complete. */
    override fun importingImportingComplete(): String {
        return """Importing complete."""
    }


    /** Importing file... */
    override fun importingImportingFile(): String {
        return """Importing file..."""
    }


    /** Include reviews */
    override fun importingIncludeReviews(): String {
        return """Include reviews"""
    }


    /** If enabled, any previous reviews that the deck sharer included will also be imported.
Otherwise, all cards will be imported as new cards, and any "leech" or "marked"
tags will be removed. */
    override fun importingIncludeReviewsHelp(): String {
        return """If enabled, any previous reviews that the deck sharer included will also be imported.
Otherwise, all cards will be imported as new cards, and any "leech" or "marked"
tags will be removed."""
    }


    /** Invalid file. Please restore from backup. */
    override fun importingInvalidFilePleaseRestoreFromBackup(): String {
        return """Invalid file. Please restore from backup."""
    }


    /** Map to {$val} */
    override fun importingMapTo(`val`: TranslateArg): String {
        return """Map to ${`val`}"""
    }


    /** Map to Tags */
    override fun importingMapToTags(): String {
        return """Map to Tags"""
    }


    /** mapped to <b>{$val}</b> */
    override fun importingMappedTo(`val`: TranslateArg): String {
        return """mapped to <b>${`val`}</b>"""
    }


    /** mapped to <b>Tags</b> */
    override fun importingMappedToTags(): String {
        return """mapped to <b>Tags</b>"""
    }


    /** Match scope */
    override fun importingMatchScope(): String {
        return """Match scope"""
    }


    /** Only existing notes with the same note type will be checked for duplicates. This can
additionally be restricted to notes with cards in the same deck. */
    override fun importingMatchScopeHelp(): String {
        return """Only existing notes with the same note type will be checked for duplicates. This can
additionally be restricted to notes with cards in the same deck."""
    }


    /** Merge note types */
    override fun importingMergeNotetypes(): String {
        return """Merge note types"""
    }


    /** If checked, and you or the deck author altered the schema of a note type, Anki will
merge the two versions instead of keeping both.

Altering a note type's schema means adding, removing, or reordering fields or templates,
or changing the sort field.
As a counterexample, changing the front side of an existing template does *not* constitute
a schema change.

Warning: This will require a one-way sync, and may mark existing notes as modified. */
    override fun importingMergeNotetypesHelp(): String {
        return """If checked, and you or the deck author altered the schema of a note type, Anki will
merge the two versions instead of keeping both.

Altering a note type's schema means adding, removing, or reordering fields or templates,
or changing the sort field.
As a counterexample, changing the front side of an existing template does *not* constitute
a schema change.

Warning: This will require a one-way sync, and may mark existing notes as modified."""
    }


    /** Mnemosyne 2.0 Deck (*.db) */
    override fun importingMnemosyne20DeckDb(): String {
        return """Mnemosyne 2.0 Deck (*.db)"""
    }


    /** Multi-character separators are not supported. Please enter one character only. */
    override fun importingMulticharacterSeparatorsAreNotSupportedPlease(): String {
        return """Multi-character separators are not supported. Please enter one character only."""
    }


    /** A new deck will be created: {$name} */
    override fun importingNewDeckWillBeCreated(`name`: String): String {
        return """A new deck will be created: ${`name`}"""
    }


    /** No notes found in file. */
    override fun importingNoNotesInFile(): String {
        return """No notes found in file."""
    }


    /** {$count} notes added */
    override fun importingNoteAdded(`count`: Int): String {
        return """${`count`} notes added"""
    }


    /** {$count} notes imported. */
    override fun importingNoteImported(`count`: Int): String {
        return """${`count`} notes imported."""
    }


    /** Note skipped, as its first field is empty */
    override fun importingNoteSkippedDueToEmptyFirstField(): String {
        return """Note skipped, as its first field is empty"""
    }


    /** Note skipped, as its deck was missing */
    override fun importingNoteSkippedDueToMissingDeck(): String {
        return """Note skipped, as its deck was missing"""
    }


    /** Note skipped, as its notetype was missing */
    override fun importingNoteSkippedDueToMissingNotetype(): String {
        return """Note skipped, as its notetype was missing"""
    }


    /** Note not updated, as note type has been modified since you first imported the note */
    override fun importingNoteSkippedUpdateDueToNotetype(): String {
        return """Note not updated, as note type has been modified since you first imported the note"""
    }


    /** Note not updated, as note type has been modified since you first imported the note, and '' was not enabled */
    override fun importingNoteSkippedUpdateDueToNotetype2(): String {
        return """Note not updated, as note type has been modified since you first imported the note, and '' was not enabled"""
    }


    /** {$count} notes unchanged */
    override fun importingNoteUnchanged(`count`: Int): String {
        return """${`count`} notes unchanged"""
    }


    /** {$count} notes updated */
    override fun importingNoteUpdated(`count`: Int): String {
        return """${`count`} notes updated"""
    }


    /** Note updated, as file had newer version */
    override fun importingNoteUpdatedAsFileHadNewer(): String {
        return """Note updated, as file had newer version"""
    }


    /** {$count} new notes imported. */
    override fun importingNotesAdded(`count`: Int): String {
        return """${`count`} new notes imported."""
    }


    /** Notes added from file: {$val} */
    override fun importingNotesAddedFromFile(`val`: TranslateArg): String {
        return """Notes added from file: ${`val`}"""
    }


    /** {$count} notes could not be imported. */
    override fun importingNotesFailed(`count`: Int): String {
        return """${`count`} notes could not be imported."""
    }


    /** Notes found in file: {$val} */
    override fun importingNotesFoundInFile(`val`: TranslateArg): String {
        return """Notes found in file: ${`val`}"""
    }


    /** {$notes} notes found in file. Of those: */
    override fun importingNotesFoundInFile2(`notes`: Int): String {
        return """${`notes`} notes found in file. Of those:"""
    }


    /** Notes skipped, as up-to-date copies are already in your collection: {$val} */
    override fun importingNotesSkippedAsTheyreAlreadyIn(`val`: TranslateArg): String {
        return """Notes skipped, as up-to-date copies are already in your collection: ${`val`}"""
    }


    /** Notes not updated, as note type has been modified since you first imported the notes: {$val} */
    override fun importingNotesSkippedUpdateDueToNotetype(`val`: TranslateArg): String {
        return """Notes not updated, as note type has been modified since you first imported the notes: ${`val`}"""
    }


    /** Notes that could not be imported as note type has changed: {$val} */
    override fun importingNotesThatCouldNotBeImported(`val`: TranslateArg): String {
        return """Notes that could not be imported as note type has changed: ${`val`}"""
    }


    /** {$count} notes were used to update existing ones. */
    override fun importingNotesUpdated(`count`: Int): String {
        return """${`count`} notes were used to update existing ones."""
    }


    /** Notes updated, as file had newer version: {$val} */
    override fun importingNotesUpdatedAsFileHadNewer(`val`: TranslateArg): String {
        return """Notes updated, as file had newer version: ${`val`}"""
    }


    /** Note type and deck */
    override fun importingNotetypeAndDeck(): String {
        return """Note type and deck"""
    }


    /** Newly-imported notes will have this note type, and only existing notes with this
note type will be updated.

You can choose which fields in the file correspond to which note type fields with the
mapping tool. */
    override fun importingNotetypeHelp(): String {
        return """Newly-imported notes will have this note type, and only existing notes with this
note type will be updated.

You can choose which fields in the file correspond to which note type fields with the
mapping tool."""
    }


    /** Overview */
    override fun importingOverview(): String {
        return """Overview"""
    }


    /** Packaged Anki Deck/Collection (*.apkg *.colpkg *.zip) */
    override fun importingPackagedAnkiDeckcollectionApkgColpkgZip(): String {
        return """Packaged Anki Deck/Collection (*.apkg *.colpkg *.zip)"""
    }


    /** Pauker 1.8 Lesson (*.pau.gz) */
    override fun importingPauker18LessonPaugz(): String {
        return """Pauker 1.8 Lesson (*.pau.gz)"""
    }


    /** Pipe */
    override fun importingPipe(): String {
        return """Pipe"""
    }


    /** Preserve */
    override fun importingPreserve(): String {
        return """Preserve"""
    }


    /** Only the first {$count} columns are shown. If this doesn't seem right, try changing the field separator. */
    override fun importingPreviewTruncated(`count`: Int): String {
        return """Only the first ${`count`} columns are shown. If this doesn't seem right, try changing the field separator."""
    }


    /** Processed {$count} cards... */
    override fun importingProcessedCards(`count`: Int): String {
        return """Processed ${`count`} cards..."""
    }


    /** Imported {$count} media files */
    override fun importingProcessedMediaFile(`count`: Int): String {
        return """Imported ${`count`} media files"""
    }


    /** Processed {$count} notes... */
    override fun importingProcessedNotes(`count`: Int): String {
        return """Processed ${`count`} notes..."""
    }


    /** '{$row}' had {$found} fields, expected {$expected} */
    override fun importingRowsHadNum1dFieldsExpectedNum2d(`row`: String, `found`: TranslateArg, `expected`: TranslateArg): String {
        return """'${`row`}' had ${`found`} fields, expected ${`expected`}"""
    }


    /** Selected file was not in UTF-8 format. Please see the importing section of the manual. */
    override fun importingSelectedFileWasNotInUtf8(): String {
        return """Selected file was not in UTF-8 format. Please see the importing section of the manual."""
    }


    /** Semicolon */
    override fun importingSemicolon(): String {
        return """Semicolon"""
    }


    /** Show */
    override fun importingShow(): String {
        return """Show"""
    }


    /** Skipped */
    override fun importingSkipped(): String {
        return """Skipped"""
    }


    /** Status */
    override fun importingStatus(): String {
        return """Status"""
    }


    /** Supermemo XML export (*.xml) */
    override fun importingSupermemoXmlExportXml(): String {
        return """Supermemo XML export (*.xml)"""
    }


    /** Tab */
    override fun importingTab(): String {
        return """Tab"""
    }


    /** Tag all notes */
    override fun importingTagAllNotes(): String {
        return """Tag all notes"""
    }


    /** These tags will be added to both newly-imported and updated notes. */
    override fun importingTagAllNotesHelp(): String {
        return """These tags will be added to both newly-imported and updated notes."""
    }


    /** Tag modified notes: */
    override fun importingTagModifiedNotes(): String {
        return """Tag modified notes:"""
    }


    /** Tag updated notes */
    override fun importingTagUpdatedNotes(): String {
        return """Tag updated notes"""
    }


    /** These tags will be added to any updated notes. */
    override fun importingTagUpdatedNotesHelp(): String {
        return """These tags will be added to any updated notes."""
    }


    /** Text separated by tabs or semicolons (*) */
    override fun importingTextSeparatedByTabsOrSemicolons(): String {
        return """Text separated by tabs or semicolons (*)"""
    }


    /** The first field of the note type must be mapped. */
    override fun importingTheFirstFieldOfTheNote(): String {
        return """The first field of the note type must be mapped."""
    }


    /** The provided file is not a valid .apkg file. */
    override fun importingTheProvidedFileIsNotA(): String {
        return """The provided file is not a valid .apkg file."""
    }


    /** This file does not appear to be a valid .apkg file. If you're getting this error from a file downloaded from AnkiWeb, chances are that your download failed. Please try again, and if the problem persists, please try again with a different browser. */
    override fun importingThisFileDoesNotAppearTo(): String {
        return """This file does not appear to be a valid .apkg file. If you're getting this error from a file downloaded from AnkiWeb, chances are that your download failed. Please try again, and if the problem persists, please try again with a different browser."""
    }


    /** This will delete your existing collection and replace it with the data in the file you're importing. Are you sure? */
    override fun importingThisWillDeleteYourExistingCollection(): String {
        return """This will delete your existing collection and replace it with the data in the file you're importing. Are you sure?"""
    }


    /** Unable to import {$filename}: file type not supported */
    override fun importingUnableToImportFilename(`filename`: String): String {
        return """Unable to import ${`filename`}: file type not supported"""
    }


    /** Unable to import from a read-only file. */
    override fun importingUnableToImportFromAReadonly(): String {
        return """Unable to import from a read-only file."""
    }


    /** Unknown file format. */
    override fun importingUnknownFileFormat(): String {
        return """Unknown file format."""
    }


    /** Update */
    override fun importingUpdate(): String {
        return """Update"""
    }


    /** Always */
    override fun importingUpdateAlways(): String {
        return """Always"""
    }


    /** Update existing notes when first field matches */
    override fun importingUpdateExistingNotesWhenFirstField(): String {
        return """Update existing notes when first field matches"""
    }


    /** If newer */
    override fun importingUpdateIfNewer(): String {
        return """If newer"""
    }


    /** Never */
    override fun importingUpdateNever(): String {
        return """Never"""
    }


    /** Update notes */
    override fun importingUpdateNotes(): String {
        return """Update notes"""
    }


    /** When to update an existing note in your collection. By default, this is only done
if the matching imported note was more recently modified. */
    override fun importingUpdateNotesHelp(): String {
        return """When to update an existing note in your collection. By default, this is only done
if the matching imported note was more recently modified."""
    }


    /** Update note types */
    override fun importingUpdateNotetypes(): String {
        return """Update note types"""
    }


    /** When to update an existing note type in your collection. By default, this is only done
if the matching imported note type was more recently modified. Changes to template text
and styling can always be imported, but for schema changes (e.g. the number or order of
fields has changed), the '' option will also need to be enabled. */
    override fun importingUpdateNotetypesHelp(): String {
        return """When to update an existing note type in your collection. By default, this is only done
if the matching imported note type was more recently modified. Changes to template text
and styling can always be imported, but for schema changes (e.g. the number or order of
fields has changed), the '' option will also need to be enabled."""
    }


    /** Updated */
    override fun importingUpdated(): String {
        return """Updated"""
    }


    /** Updates */
    override fun importingUpdates(): String {
        return """Updates"""
    }


    /** Import any deck presets */
    override fun importingWithDeckConfigs(): String {
        return """Import any deck presets"""
    }


    /** If enabled, any deck options that the deck sharer included will also be imported.
Otherwise, all decks will be assigned the default preset. */
    override fun importingWithDeckConfigsHelp(): String {
        return """If enabled, any deck options that the deck sharer included will also be imported.
Otherwise, all decks will be assigned the default preset."""
    }


    /** Ctrl */
    override fun keyboardCtrl(): String {
        return """Ctrl"""
    }


    /** Shift */
    override fun keyboardShift(): String {
        return """Shift"""
    }


    /** Error executing {$val}. */
    override fun mediaErrorExecuting(`val`: TranslateArg): String {
        return """Error executing ${`val`}."""
    }


    /** Error running {$val} */
    override fun mediaErrorRunning(`val`: TranslateArg): String {
        return """Error running ${`val`}"""
    }


    /** For security reasons, '{$val}' is not allowed on cards. You can still use it by placing the command in a different package, and importing that package in the LaTeX header instead. */
    override fun mediaForSecurityReasonsIsNot(`val`: TranslateArg): String {
        return """For security reasons, '${`val`}' is not allowed on cards. You can still use it by placing the command in a different package, and importing that package in the LaTeX header instead."""
    }


    /** Generated file: {$val} */
    override fun mediaGeneratedFile(`val`: TranslateArg): String {
        return """Generated file: ${`val`}"""
    }


    /** Have you installed latex and dvipng/dvisvgm? */
    override fun mediaHaveYouInstalledLatexAndDvipngdvisvgm(): String {
        return """Have you installed latex and dvipng/dvisvgm?"""
    }


    /** Recording...<br>Time: {$secs} */
    override fun mediaRecordingtime(`secs`: String): String {
        return """Recording...<br>Time: ${`secs`}"""
    }


    /** Sound and video on cards will not function until mpv or mplayer is installed. */
    override fun mediaSoundAndVideoOnCardsWill(): String {
        return """Sound and video on cards will not function until mpv or mplayer is installed."""
    }


    /** Tag Missing */
    override fun mediaCheckAddTag(): String {
        return """Tag Missing"""
    }


    /** All LaTeX rendered. */
    override fun mediaCheckAllLatexRendered(): String {
        return """All LaTeX rendered."""
    }


    /** Check Media */
    override fun mediaCheckCheckMediaAction(): String {
        return """Check Media"""
    }


    /** Checked {$count}... */
    override fun mediaCheckChecked(`count`: Int): String {
        return """Checked ${`count`}..."""
    }


    /** Delete Unused */
    override fun mediaCheckDeleteUnused(): String {
        return """Delete Unused"""
    }


    /** {$count} files moved to the trash. */
    override fun mediaCheckDeleteUnusedComplete(`count`: Int): String {
        return """${`count`} files moved to the trash."""
    }


    /** Delete unused media? */
    override fun mediaCheckDeleteUnusedConfirm(): String {
        return """Delete unused media?"""
    }


    /** Empty Trash */
    override fun mediaCheckEmptyTrash(): String {
        return """Empty Trash"""
    }


    /** Extracted images: {$count} */
    override fun mediaCheckExtractedCount(`count`: Int): String {
        return """Extracted images: ${`count`}"""
    }


    /** {$count} files remaining. */
    override fun mediaCheckFilesRemaining(`count`: Int): String {
        return """${`count`} files remaining."""
    }


    /** Missing files: {$count} */
    override fun mediaCheckMissingCount(`count`: Int): String {
        return """Missing files: ${`count`}"""
    }


    /** Missing: {$filename} */
    override fun mediaCheckMissingFile(`filename`: String): String {
        return """Missing: ${`filename`}"""
    }


    /** The following files are referenced by cards, but were not found in the media folder: */
    override fun mediaCheckMissingHeader(): String {
        return """The following files are referenced by cards, but were not found in the media folder:"""
    }


    /** missing-media */
    override fun mediaCheckMissingMediaTag(): String {
        return """missing-media"""
    }


    /** {$notetype}: {$card_type} ({$side}) */
    override fun mediaCheckNotetypeTemplate(`notetype`: String, `cardType`: String, `side`: String): String {
        return """${`notetype`}: ${`cardType`} (${`side`})"""
    }


    /** Over 100MB: {$count} */
    override fun mediaCheckOversizeCount(`count`: Int): String {
        return """Over 100MB: ${`count`}"""
    }


    /** Over 100MB: {$filename} */
    override fun mediaCheckOversizeFile(`filename`: String): String {
        return """Over 100MB: ${`filename`}"""
    }


    /** Files over 100MB can not be synced with AnkiWeb. */
    override fun mediaCheckOversizeHeader(): String {
        return """Files over 100MB can not be synced with AnkiWeb."""
    }


    /** Renamed files: {$count} */
    override fun mediaCheckRenamedCount(`count`: Int): String {
        return """Renamed files: ${`count`}"""
    }


    /** Renamed: {$old} -> {$new} */
    override fun mediaCheckRenamedFile(`old`: String, `new`: String): String {
        return """Renamed: ${`old`} -> ${`new`}"""
    }


    /** Some files have been renamed for compatibility: */
    override fun mediaCheckRenamedHeader(): String {
        return """Some files have been renamed for compatibility:"""
    }


    /** Render LaTeX */
    override fun mediaCheckRenderLatex(): String {
        return """Render LaTeX"""
    }


    /** Restore Deleted */
    override fun mediaCheckRestoreTrash(): String {
        return """Restore Deleted"""
    }


    /** Subfolders: {$count} */
    override fun mediaCheckSubfolderCount(`count`: Int): String {
        return """Subfolders: ${`count`}"""
    }


    /** Folder: {$filename} */
    override fun mediaCheckSubfolderFile(`filename`: String): String {
        return """Folder: ${`filename`}"""
    }


    /** Folders inside the media folder are not supported. */
    override fun mediaCheckSubfolderHeader(): String {
        return """Folders inside the media folder are not supported."""
    }


    /** Anki can not detect used files when you use  references in media/LaTeX tags. The media/LaTeX tags should be placed on individual notes instead.

Referencing templates: */
    override fun mediaCheckTemplateReferencesFieldHeader(): String {
        return """Anki can not detect used files when you use  references in media/LaTeX tags. The media/LaTeX tags should be placed on individual notes instead.

Referencing templates:"""
    }


    /** Trash folder: {$count} files, {$megs}MB */
    override fun mediaCheckTrashCount(`count`: Int, `megs`: TranslateArg): String {
        return """Trash folder: ${`count`} files, ${`megs`}MB"""
    }


    /** The trash folder is now empty. */
    override fun mediaCheckTrashEmptied(): String {
        return """The trash folder is now empty."""
    }


    /** Restored deleted files to the media folder. */
    override fun mediaCheckTrashRestored(): String {
        return """Restored deleted files to the media folder."""
    }


    /** Unused files: {$count} */
    override fun mediaCheckUnusedCount(`count`: Int): String {
        return """Unused files: ${`count`}"""
    }


    /** Unused: {$filename} */
    override fun mediaCheckUnusedFile(`filename`: String): String {
        return """Unused: ${`filename`}"""
    }


    /** The following files were found in the media folder, but do not appear to be used on any cards: */
    override fun mediaCheckUnusedHeader(): String {
        return """The following files were found in the media folder, but do not appear to be used on any cards:"""
    }


    /** Check Media */
    override fun mediaCheckWindowTitle(): String {
        return """Check Media"""
    }


    /** Error details: {$details} */
    override fun networkDetails(`details`: String): String {
        return """Error details: ${`details`}"""
    }


    /** Please check your internet connection. */
    override fun networkOffline(): String {
        return """Please check your internet connection."""
    }


    /** A network error occurred. */
    override fun networkOther(): String {
        return """A network error occurred."""
    }


    /** Your proxy requires authentication. */
    override fun networkProxyAuth(): String {
        return """Your proxy requires authentication."""
    }


    /** Connection timed out. Please try again. If you see frequent timeouts, please try a different network connection. */
    override fun networkTimeout(): String {
        return """Connection timed out. Please try again. If you see frequent timeouts, please try a different network connection."""
    }


    /** No image to show. */
    override fun notetypeErrorNoImageToShow(): String {
        return """No image to show."""
    }


    /** Add: {$val} */
    override fun notetypesAdd(`val`: TranslateArg): String {
        return """Add: ${`val`}"""
    }


    /** Add Note Type */
    override fun notetypesAddNoteType(): String {
        return """Add Note Type"""
    }


    /** Add Reverse */
    override fun notetypesAddReverseField(): String {
        return """Add Reverse"""
    }


    /** Back Extra */
    override fun notetypesBackExtraField(): String {
        return """Back Extra"""
    }


    /** Back */
    override fun notetypesBackField(): String {
        return """Back"""
    }


    /** Basic */
    override fun notetypesBasicName(): String {
        return """Basic"""
    }


    /** Basic (optional reversed card) */
    override fun notetypesBasicOptionalReversedName(): String {
        return """Basic (optional reversed card)"""
    }


    /** Basic (and reversed card) */
    override fun notetypesBasicReversedName(): String {
        return """Basic (and reversed card)"""
    }


    /** Basic (type in the answer) */
    override fun notetypesBasicTypeAnswerName(): String {
        return """Basic (type in the answer)"""
    }


    /** Card 1 */
    override fun notetypesCard1Name(): String {
        return """Card 1"""
    }


    /** Card 2 */
    override fun notetypesCard2Name(): String {
        return """Card 2"""
    }


    /** Cards */
    override fun notetypesCards(): String {
        return """Cards"""
    }


    /** Change Note Type (Ctrl+N) */
    override fun notetypesChangeNoteTypeCtrlandn(): String {
        return """Change Note Type (Ctrl+N)"""
    }


    /** Choose Note Type */
    override fun notetypesChooseNoteType(): String {
        return """Choose Note Type"""
    }


    /** Clone: {$val} */
    override fun notetypesClone(`val`: TranslateArg): String {
        return """Clone: ${`val`}"""
    }


    /** Cloze */
    override fun notetypesClozeName(): String {
        return """Cloze"""
    }


    /** Comments */
    override fun notetypesCommentsField(): String {
        return """Comments"""
    }


    /** {$val} copy */
    override fun notetypesCopy(`val`: TranslateArg): String {
        return """${`val`} copy"""
    }


    /** Create scalable images with dvisvgm */
    override fun notetypesCreateScalableImagesWithDvisvgm(): String {
        return """Create scalable images with dvisvgm"""
    }


    /** Delete this note type and all its cards? */
    override fun notetypesDeleteThisNoteTypeAndAll(): String {
        return """Delete this note type and all its cards?"""
    }


    /** Delete this unused note type? */
    override fun notetypesDeleteThisUnusedNoteType(): String {
        return """Delete this unused note type?"""
    }


    /** An error occurred when generating an image occlusion note */
    override fun notetypesErrorGeneratingCloze(): String {
        return """An error occurred when generating an image occlusion note"""
    }


    /** An error occurred while fetching an image occlusion note */
    override fun notetypesErrorGettingImagecloze(): String {
        return """An error occurred while fetching an image occlusion note"""
    }


    /** Error loading image occlusion. Is your Anki version up to date? */
    override fun notetypesErrorLoadingImageOcclusion(): String {
        return """Error loading image occlusion. Is your Anki version up to date?"""
    }


    /** Fields */
    override fun notetypesFields(): String {
        return """Fields"""
    }


    /** Footer */
    override fun notetypesFooter(): String {
        return """Footer"""
    }


    /** Front */
    override fun notetypesFrontField(): String {
        return """Front"""
    }


    /** Header */
    override fun notetypesHeader(): String {
        return """Header"""
    }


    /** Hide All, Guess One */
    override fun notetypesHideAllGuessOne(): String {
        return """Hide All, Guess One"""
    }


    /** Hide One, Guess One */
    override fun notetypesHideOneGuessOne(): String {
        return """Hide One, Guess One"""
    }


    /** Image */
    override fun notetypesImage(): String {
        return """Image"""
    }


    /** Image Occlusion */
    override fun notetypesImageOcclusionName(): String {
        return """Image Occlusion"""
    }


    /** Paste Image from Clipboard */
    override fun notetypesIoPasteImageFromClipboard(): String {
        return """Paste Image from Clipboard"""
    }


    /** Select Image */
    override fun notetypesIoSelectImage(): String {
        return """Select Image"""
    }


    /** You must make at least one occlusion. */
    override fun notetypesNoOcclusionCreated(): String {
        return """You must make at least one occlusion."""
    }


    /** Unable to add. Either you have not added any occlusions, or the first field is empty. */
    override fun notetypesNoOcclusionCreated2(): String {
        return """Unable to add. Either you have not added any occlusions, or the first field is empty."""
    }


    /** Note Types */
    override fun notetypesNoteTypes(): String {
        return """Note Types"""
    }


    /** Note Type */
    override fun notetypesNotetype(): String {
        return """Note Type"""
    }


    /** Occlusion */
    override fun notetypesOcclusion(): String {
        return """Occlusion"""
    }


    /** Mask */
    override fun notetypesOcclusionMask(): String {
        return """Mask"""
    }


    /** Note */
    override fun notetypesOcclusionNote(): String {
        return """Note"""
    }


    /** Options */
    override fun notetypesOptions(): String {
        return """Options"""
    }


    /** Please add another note type first. */
    override fun notetypesPleaseAddAnotherNoteTypeFirst(): String {
        return """Please add another note type first."""
    }


    /** Text */
    override fun notetypesTextField(): String {
        return """Text"""
    }


    /** Toggle Masks */
    override fun notetypesToggleMasks(): String {
        return """Toggle Masks"""
    }


    /** Type */
    override fun notetypesType(): String {
        return """Type"""
    }


    /** AnkiWeb Account */
    override fun preferencesAccount(): String {
        return """AnkiWeb Account"""
    }


    /** Always */
    override fun preferencesAlways(): String {
        return """Always"""
    }


    /** AnkiHub provides collaborative deck editing and additional study tools. A paid subscription is required to access certain features. */
    override fun preferencesAnkihubIntro(): String {
        return """AnkiHub provides collaborative deck editing and additional study tools. A paid subscription is required to access certain features."""
    }


    /** Not currently logged in to AnkiHub. */
    override fun preferencesAnkihubNotLoggedIn(): String {
        return """Not currently logged in to AnkiHub."""
    }


    /** AnkiWeb is a free service that lets you keep your flashcard data in sync across your devices, and provides a way to recover the data if your device breaks or is lost. */
    override fun preferencesAnkiwebIntro(): String {
        return """AnkiWeb is a free service that lets you keep your flashcard data in sync across your devices, and provides a way to recover the data if your device breaks or is lost."""
    }


    /** Answer keys */
    override fun preferencesAnswerKeys(): String {
        return """Answer keys"""
    }


    /** Appearance */
    override fun preferencesAppearance(): String {
        return """Appearance"""
    }


    /** Automatically sync on profile open/close */
    override fun preferencesAutomaticallySyncOnProfileOpenclose(): String {
        return """Automatically sync on profile open/close"""
    }


    /** Anki periodically backs up your collection. After backups are more than 2 days old,
Anki will start removing some of them to free up disk space. */
    override fun preferencesBackupExplanation(): String {
        return """Anki periodically backs up your collection. After backups are more than 2 days old,
Anki will start removing some of them to free up disk space."""
    }


    /** Backups */
    override fun preferencesBackups(): String {
        return """Backups"""
    }


    /** Basic */
    override fun preferencesBasic(): String {
        return """Basic"""
    }


    /** Browsing */
    override fun preferencesBrowsing(): String {
        return """Browsing"""
    }


    /** Change deck depending on note type */
    override fun preferencesChangeDeckDependingOnNoteType(): String {
        return """Change deck depending on note type"""
    }


    /** Changes will take effect when you restart Anki. */
    override fun preferencesChangesWillTakeEffectWhenYou(): String {
        return """Changes will take effect when you restart Anki."""
    }


    /** Check for add-on updates */
    override fun preferencesCheckForAddonUpdates(): String {
        return """Check for add-on updates"""
    }


    /** Check for program updates */
    override fun preferencesCheckForUpdates(): String {
        return """Check for program updates"""
    }


    /** Self-hosted sync server */
    override fun preferencesCustomSyncUrl(): String {
        return """Self-hosted sync server"""
    }


    /** For advanced users - please see the manual */
    override fun preferencesCustomSyncUrlDisclaimer(): String {
        return """For advanced users - please see the manual"""
    }


    /** Daily backups to keep: */
    override fun preferencesDailyBackups(): String {
        return """Daily backups to keep:"""
    }


    /** Default deck */
    override fun preferencesDefaultDeck(): String {
        return """Default deck"""
    }


    /** Default search text */
    override fun preferencesDefaultSearchText(): String {
        return """Default search text"""
    }


    /** e.g. "deck:current" */
    override fun preferencesDefaultSearchTextExample(): String {
        return """e.g. "deck:current""""
    }


    /** Distractions */
    override fun preferencesDistractions(): String {
        return """Distractions"""
    }


    /** Editing */
    override fun preferencesEditing(): String {
        return """Editing"""
    }


    /** Experiments */
    override fun preferencesExperimentalFeaturesTab(): String {
        return """Experiments"""
    }


    /** Full screen only */
    override fun preferencesFullScreenOnly(): String {
        return """Full screen only"""
    }


    /** General */
    override fun preferencesGeneral(): String {
        return """General"""
    }


    /** Generate LaTeX images (security risk) */
    override fun preferencesGenerateLatexImagesAutomatically(): String {
        return """Generate LaTeX images (security risk)"""
    }


    /** Hide bottom bar during review */
    override fun preferencesHideBottomBarDuringReview(): String {
        return """Hide bottom bar during review"""
    }


    /** Hide top bar during review */
    override fun preferencesHideTopBarDuringReview(): String {
        return """Hide top bar during review"""
    }


    /** hours past midnight */
    override fun preferencesHoursPastMidnight(): String {
        return """hours past midnight"""
    }


    /** Ignore accents in search (slower) */
    override fun preferencesIgnoreAccentsInSearch(): String {
        return """Ignore accents in search (slower)"""
    }


    /** Import/Export */
    override fun preferencesImportExport(): String {
        return """Import/Export"""
    }


    /** Interrupt current audio when answering */
    override fun preferencesInterruptCurrentAudioWhenAnswering(): String {
        return """Interrupt current audio when answering"""
    }


    /** Language */
    override fun preferencesLanguage(): String {
        return """Language"""
    }


    /** LaTeX image generation is disabled in the preferences. */
    override fun preferencesLatexGenerationDisabled(): String {
        return """LaTeX image generation is disabled in the preferences."""
    }


    /** Learn ahead limit */
    override fun preferencesLearnAheadLimit(): String {
        return """Learn ahead limit"""
    }


    /** Legacy timezone handling (buggy, but required for AnkiDroid <= 2.14) */
    override fun preferencesLegacyTimezoneHandling(): String {
        return """Legacy timezone handling (buggy, but required for AnkiDroid <= 2.14)"""
    }


    /** Log-in successful. Save preferences and sync now? */
    override fun preferencesLoginSuccessfulSyncNow(): String {
        return """Log-in successful. Save preferences and sync now?"""
    }


    /** Media */
    override fun preferencesMedia(): String {
        return """Media"""
    }


    /** Media is not backed up. Please create a periodic backup of your Anki folder to be safe. */
    override fun preferencesMediaIsNotBackedUp(): String {
        return """Media is not backed up. Please create a periodic backup of your Anki folder to be safe."""
    }


    /** Minimalist mode */
    override fun preferencesMinimalistMode(): String {
        return """Minimalist mode"""
    }


    /** Make the interface more compact/less fancy */
    override fun preferencesMinimalistModeTooltip(): String {
        return """Make the interface more compact/less fancy"""
    }


    /** mins */
    override fun preferencesMins(): String {
        return """mins"""
    }


    /** Minutes between automatic backups: */
    override fun preferencesMinutesBetweenBackups(): String {
        return """Minutes between automatic backups:"""
    }


    /** Monthly backups to keep: */
    override fun preferencesMonthlyBackups(): String {
        return """Monthly backups to keep:"""
    }


    /** Syncing */
    override fun preferencesNetwork(): String {
        return """Syncing"""
    }


    /** Network timeout */
    override fun preferencesNetworkTimeout(): String {
        return """Network timeout"""
    }


    /** Next day starts at */
    override fun preferencesNextDayStartsAt(): String {
        return """Next day starts at"""
    }


    /** Not currently logged in to AnkiWeb. */
    override fun preferencesNotLoggedIn(): String {
        return """Not currently logged in to AnkiWeb."""
    }


    /** Note */
    override fun preferencesNote(): String {
        return """Note"""
    }


    /** On next sync, force changes in one direction */
    override fun preferencesOnNextSyncForceChangesIn(): String {
        return """On next sync, force changes in one direction"""
    }


    /** Paste clipboard images as PNG */
    override fun preferencesPasteClipboardImagesAsPng(): String {
        return """Paste clipboard images as PNG"""
    }


    /** Paste without shift key strips formatting */
    override fun preferencesPasteWithoutShiftKeyStripsFormatting(): String {
        return """Paste without shift key strips formatting"""
    }


    /** Periodically sync media */
    override fun preferencesPeriodicallySyncMedia(): String {
        return """Periodically sync media"""
    }


    /** Please restart Anki to complete language change. */
    override fun preferencesPleaseRestartAnkiToCompleteLanguage(): String {
        return """Please restart Anki to complete language change."""
    }


    /** Preferences */
    override fun preferencesPreferences(): String {
        return """Preferences"""
    }


    /** Reduce motion */
    override fun preferencesReduceMotion(): String {
        return """Reduce motion"""
    }


    /** Disable various animations and transitions of the user interface */
    override fun preferencesReduceMotionTooltip(): String {
        return """Disable various animations and transitions of the user interface"""
    }


    /** Reset Window Sizes */
    override fun preferencesResetWindowSizes(): String {
        return """Reset Window Sizes"""
    }


    /** Window sizes and locations have been reset. */
    override fun preferencesResetWindowSizesComplete(): String {
        return """Window sizes and locations have been reset."""
    }


    /** Review */
    override fun preferencesReview(): String {
        return """Review"""
    }


    /** Reviewer */
    override fun preferencesReviewer(): String {
        return """Reviewer"""
    }


    /** Scheduler */
    override fun preferencesScheduler(): String {
        return """Scheduler"""
    }


    /** Scheduling */
    override fun preferencesScheduling(): String {
        return """Scheduling"""
    }


    /** Enter an unused shortcut key, or leave empty to disable. */
    override fun preferencesShortcutPlaceholder(): String {
        return """Enter an unused shortcut key, or leave empty to disable."""
    }


    /** Show learning cards with larger steps before reviews */
    override fun preferencesShowLearningCardsWithLargerSteps(): String {
        return """Show learning cards with larger steps before reviews"""
    }


    /** Show next review time above answer buttons */
    override fun preferencesShowNextReviewTimeAboveAnswer(): String {
        return """Show next review time above answer buttons"""
    }


    /** Show play buttons on cards with audio */
    override fun preferencesShowPlayButtonsOnCardsWith(): String {
        return """Show play buttons on cards with audio"""
    }


    /** Show remaining card count */
    override fun preferencesShowRemainingCardCount(): String {
        return """Show remaining card count"""
    }


    /** Some settings will take effect after you restart Anki. */
    override fun preferencesSomeSettingsWillTakeEffectAfter(): String {
        return """Some settings will take effect after you restart Anki."""
    }


    /** Spacebar (or enter) also answers card */
    override fun preferencesSpacebarRatesCard(): String {
        return """Spacebar (or enter) also answers card"""
    }


    /** Style */
    override fun preferencesStyle(): String {
        return """Style"""
    }


    /** Synchronize audio and images too */
    override fun preferencesSynchronizeAudioAndImagesToo(): String {
        return """Synchronize audio and images too"""
    }


    /** Synchronization */
    override fun preferencesTabSynchronisation(): String {
        return """Synchronization"""
    }


    /** Theme */
    override fun preferencesTheme(): String {
        return """Theme"""
    }


    /** Dark */
    override fun preferencesThemeDark(): String {
        return """Dark"""
    }


    /** Follow System */
    override fun preferencesThemeFollowSystem(): String {
        return """Follow System"""
    }


    /** Light */
    override fun preferencesThemeLight(): String {
        return """Light"""
    }


    /** Third-party services are unaffiliated with and not endorsed by Anki. Use of these services may require payment. */
    override fun preferencesThirdPartyDescription(): String {
        return """Third-party services are unaffiliated with and not endorsed by Anki. Use of these services may require payment."""
    }


    /** Third-Party Services */
    override fun preferencesThirdPartyServices(): String {
        return """Third-Party Services"""
    }


    /** Timebox time limit */
    override fun preferencesTimeboxTimeLimit(): String {
        return """Timebox time limit"""
    }


    /** Updates */
    override fun preferencesUpdates(): String {
        return """Updates"""
    }


    /** Allow Once */
    override fun preferencesUrlSchemeAllowOnce(): String {
        return """Allow Once"""
    }


    /** Always Allow */
    override fun preferencesUrlSchemeAlwaysAllow(): String {
        return """Always Allow"""
    }


    /** Allowed URL Schemes (space-separated): */
    override fun preferencesUrlSchemePrompt(): String {
        return """Allowed URL Schemes (space-separated):"""
    }


    /** Blocked attempt to open `{$link}`, which may be a security issue.

If you trust the deck author and wish to proceed, you can add `{$scheme}` to your allowed URL Schemes. */
    override fun preferencesUrlSchemeWarning(`link`: String, `scheme`: String): String {
        return """Blocked attempt to open `${`link`}`, which may be a security issue.

If you trust the deck author and wish to proceed, you can add `${`scheme`}` to your allowed URL Schemes."""
    }


    /** URL Schemes */
    override fun preferencesUrlSchemes(): String {
        return """URL Schemes"""
    }


    /** User Interface */
    override fun preferencesUserInterface(): String {
        return """User Interface"""
    }


    /** User interface size */
    override fun preferencesUserInterfaceSize(): String {
        return """User interface size"""
    }


    /** V3 scheduler */
    override fun preferencesV3Scheduler(): String {
        return """V3 scheduler"""
    }


    /** Video driver */
    override fun preferencesVideoDriver(): String {
        return """Video driver"""
    }


    /** ANGLE (may work better than OpenGL) */
    override fun preferencesVideoDriverAngle(): String {
        return """ANGLE (may work better than OpenGL)"""
    }


    /** default */
    override fun preferencesVideoDriverDefault(): String {
        return """default"""
    }


    /** OpenGL (recommended on Macs) */
    override fun preferencesVideoDriverOpenglMac(): String {
        return """OpenGL (recommended on Macs)"""
    }


    /** OpenGL (faster, may cause issues) */
    override fun preferencesVideoDriverOpenglOther(): String {
        return """OpenGL (faster, may cause issues)"""
    }


    /** Software (not recommended) */
    override fun preferencesVideoDriverSoftwareMac(): String {
        return """Software (not recommended)"""
    }


    /** Software (slower) */
    override fun preferencesVideoDriverSoftwareOther(): String {
        return """Software (slower)"""
    }


    /** Weekly backups to keep: */
    override fun preferencesWeeklyBackups(): String {
        return """Weekly backups to keep:"""
    }


    /** When adding, default to current deck */
    override fun preferencesWhenAddingDefaultToCurrentDeck(): String {
        return """When adding, default to current deck"""
    }


    /** You can restore backups via File > Switch Profile. */
    override fun preferencesYouCanRestoreBackupsViaFileswitch(): String {
        return """You can restore backups via File > Switch Profile."""
    }


    /** Anki could not read your profile data. Window sizes and your sync login details have been forgotten. */
    override fun profilesAnkiCouldNotReadYourProfile(): String {
        return """Anki could not read your profile data. Window sizes and your sync login details have been forgotten."""
    }


    /** Anki could not rename your profile because it could not rename the profile folder on disk. Please ensure you have permission to write to Documents/Anki and no other programs are accessing your profile folders, then try again. */
    override fun profilesAnkiCouldNotRenameYourProfile(): String {
        return """Anki could not rename your profile because it could not rename the profile folder on disk. Please ensure you have permission to write to Documents/Anki and no other programs are accessing your profile folders, then try again."""
    }


    /** Backup created. */
    override fun profilesBackupCreated(): String {
        return """Backup created."""
    }


    /** Backup creation failed: {$reason} */
    override fun profilesBackupCreationFailed(`reason`: String): String {
        return """Backup creation failed: ${`reason`}"""
    }


    /** No changes since latest backup. */
    override fun profilesBackupUnchanged(): String {
        return """No changes since latest backup."""
    }


    /** Are you sure you wish to display Anki's interface in {$lang}? */
    override fun profilesConfirmLangChoice(`lang`: String): String {
        return """Are you sure you wish to display Anki's interface in ${`lang`}?"""
    }


    /** Anki could not create its data folder. Please see the File Locations section of the manual, and ensure that location is not read-only. */
    override fun profilesCouldNotCreateDataFolder(): String {
        return """Anki could not create its data folder. Please see the File Locations section of the manual, and ensure that location is not read-only."""
    }


    /** Creating Backup... */
    override fun profilesCreatingBackup(): String {
        return """Creating Backup..."""
    }


    /** Downgrade && Quit */
    override fun profilesDowngradeAndQuit(): String {
        return """Downgrade && Quit"""
    }


    /** Folder already exists. */
    override fun profilesFolderAlreadyExists(): String {
        return """Folder already exists."""
    }


    /** This folder stores all of your Anki data in a single location,
to make backups easy. To tell Anki to use a different location,
please see:

{$link} */
    override fun profilesFolderReadme(`link`: String): String {
        return """This folder stores all of your Anki data in a single location,
to make backups easy. To tell Anki to use a different location,
please see:

${`link`}"""
    }


    /** Open */
    override fun profilesOpen(): String {
        return """Open"""
    }


    /** Open Backup... */
    override fun profilesOpenBackup(): String {
        return """Open Backup..."""
    }


    /** Please remove the folder {$val} and try again. */
    override fun profilesPleaseRemoveTheFolderAnd(`val`: TranslateArg): String {
        return """Please remove the folder ${`val`} and try again."""
    }


    /** Preferences Corrupt */
    override fun profilesPrefsCorruptTitle(): String {
        return """Preferences Corrupt"""
    }


    /** Anki's prefs21.db file was corrupt and has been recreated. If you were using multiple profiles, please add them back using the same names to recover your cards. */
    override fun profilesPrefsFileIsCorrupt(): String {
        return """Anki's prefs21.db file was corrupt and has been recreated. If you were using multiple profiles, please add them back using the same names to recover your cards."""
    }


    /** Profile Corrupt */
    override fun profilesProfileCorrupt(): String {
        return """Profile Corrupt"""
    }


    /** Requested profile does not exist. */
    override fun profilesProfileDoesNotExist(): String {
        return """Requested profile does not exist."""
    }


    /** Profiles */
    override fun profilesProfiles(): String {
        return """Profiles"""
    }


    /** Quit */
    override fun profilesQuit(): String {
        return """Quit"""
    }


    /** User 1 */
    override fun profilesUser1(): String {
        return """User 1"""
    }


    /** &About */
    override fun qtAccelAbout(): String {
        return """&About"""
    }


    /** About Anki... */
    override fun qtAccelAboutMac(): String {
        return """About Anki..."""
    }


    /** &Cards */
    override fun qtAccelCards(): String {
        return """&Cards"""
    }


    /** &Check Database */
    override fun qtAccelCheckDatabase(): String {
        return """&Check Database"""
    }


    /** Check &Media */
    override fun qtAccelCheckMedia(): String {
        return """Check &Media"""
    }


    /** Create &Backup */
    override fun qtAccelCreateBackup(): String {
        return """Create &Backup"""
    }


    /** &Edit */
    override fun qtAccelEdit(): String {
        return """&Edit"""
    }


    /** E&xit */
    override fun qtAccelExit(): String {
        return """E&xit"""
    }


    /** &Export... */
    override fun qtAccelExport(): String {
        return """&Export..."""
    }


    /** &Export Notes... */
    override fun qtAccelExportNotes(): String {
        return """&Export Notes..."""
    }


    /** &File */
    override fun qtAccelFile(): String {
        return """&File"""
    }


    /** Fil&ter */
    override fun qtAccelFilter(): String {
        return """Fil&ter"""
    }


    /** &Find */
    override fun qtAccelFind(): String {
        return """&Find"""
    }


    /** Find and Re&place... */
    override fun qtAccelFindAndReplace(): String {
        return """Find and Re&place..."""
    }


    /** Find &Duplicates... */
    override fun qtAccelFindDuplicates(): String {
        return """Find &Duplicates..."""
    }


    /** &Reset */
    override fun qtAccelForget(): String {
        return """&Reset"""
    }


    /** Toggle &Full Screen */
    override fun qtAccelFullScreen(): String {
        return """Toggle &Full Screen"""
    }


    /** &Go */
    override fun qtAccelGo(): String {
        return """&Go"""
    }


    /** &Guide */
    override fun qtAccelGuide(): String {
        return """&Guide"""
    }


    /** &Help */
    override fun qtAccelHelp(): String {
        return """&Help"""
    }


    /** &Import... */
    override fun qtAccelImport(): String {
        return """&Import..."""
    }


    /** &Info... */
    override fun qtAccelInfo(): String {
        return """&Info..."""
    }


    /** &Invert Selection */
    override fun qtAccelInvertSelection(): String {
        return """&Invert Selection"""
    }


    /** &Layout */
    override fun qtAccelLayout(): String {
        return """&Layout"""
    }


    /** &Auto */
    override fun qtAccelLayoutAuto(): String {
        return """&Auto"""
    }


    /** &Horizontal */
    override fun qtAccelLayoutHorizontal(): String {
        return """&Horizontal"""
    }


    /** &Vertical */
    override fun qtAccelLayoutVertical(): String {
        return """&Vertical"""
    }


    /** &Revert to Backup */
    override fun qtAccelLoadBackup(): String {
        return """&Revert to Backup"""
    }


    /** &Next Card */
    override fun qtAccelNextCard(): String {
        return """&Next Card"""
    }


    /** N&ote */
    override fun qtAccelNote(): String {
        return """N&ote"""
    }


    /** &Notes */
    override fun qtAccelNotes(): String {
        return """&Notes"""
    }


    /** &Preferences */
    override fun qtAccelPreferences(): String {
        return """&Preferences"""
    }


    /** &Previous Card */
    override fun qtAccelPreviousCard(): String {
        return """&Previous Card"""
    }


    /** &Redo */
    override fun qtAccelRedo(): String {
        return """&Redo"""
    }


    /** &Reset Zoom */
    override fun qtAccelResetZoom(): String {
        return """&Reset Zoom"""
    }


    /** Select &All */
    override fun qtAccelSelectAll(): String {
        return """Select &All"""
    }


    /** Select &Notes */
    override fun qtAccelSelectNotes(): String {
        return """Select &Notes"""
    }


    /** Set &Due Date... */
    override fun qtAccelSetDueDate(): String {
        return """Set &Due Date..."""
    }


    /** &Support Anki */
    override fun qtAccelSupportAnki(): String {
        return """&Support Anki"""
    }


    /** &Switch Profile */
    override fun qtAccelSwitchProfile(): String {
        return """&Switch Profile"""
    }


    /** Toggle Sidebar */
    override fun qtAccelToggleSidebar(): String {
        return """Toggle Sidebar"""
    }


    /** &Tools */
    override fun qtAccelTools(): String {
        return """&Tools"""
    }


    /** &Undo */
    override fun qtAccelUndo(): String {
        return """&Undo"""
    }


    /** &View */
    override fun qtAccelView(): String {
        return """&View"""
    }


    /** Zoom Editor &In */
    override fun qtAccelZoomEditorIn(): String {
        return """Zoom Editor &In"""
    }


    /** Zoom Editor &Out */
    override fun qtAccelZoomEditorOut(): String {
        return """Zoom Editor &Out"""
    }


    /** Zoom &In */
    override fun qtAccelZoomIn(): String {
        return """Zoom &In"""
    }


    /** Zoom &Out */
    override fun qtAccelZoomOut(): String {
        return """Zoom &Out"""
    }


    /** Add-on will be installed when a profile is opened. */
    override fun qtMiscAddonWillBeInstalledWhenA(): String {
        return """Add-on will be installed when a profile is opened."""
    }


    /** Add-ons */
    override fun qtMiscAddons(): String {
        return """Add-ons"""
    }


    /** All cards, notes, and media for this profile will be deleted. Are you sure? */
    override fun qtMiscAllCardsNotesAndMediaFor(): String {
        return """All cards, notes, and media for this profile will be deleted. Are you sure?"""
    }


    /** All cards, notes, and media for the profile "{$name}" will be deleted. Are you sure? */
    override fun qtMiscAllCardsNotesAndMediaFor2(`name`: String): String {
        return """All cards, notes, and media for the profile "${`name`}" will be deleted. Are you sure?"""
    }


    /** Anki Already Running */
    override fun qtMiscAnkiIsRunning(): String {
        return """Anki Already Running"""
    }


    /** <h1>Anki Updated</h1>Anki {$val} has been released.<br><br> */
    override fun qtMiscAnkiUpdatedankiHasBeenReleased(`val`: TranslateArg): String {
        return """<h1>Anki Updated</h1>Anki ${`val`} has been released.<br><br>"""
    }


    /** Backup successfully restored. Automatic syncing and backups have been disabled for now. To enable them again, close the profile or restart Anki. */
    override fun qtMiscAutomaticSyncingAndBackupsHaveBeen(): String {
        return """Backup successfully restored. Automatic syncing and backups have been disabled for now. To enable them again, close the profile or restart Anki."""
    }


    /** Back Side Only */
    override fun qtMiscBackSideOnly(): String {
        return """Back Side Only"""
    }


    /** Backing Up... */
    override fun qtMiscBackingUp(): String {
        return """Backing Up..."""
    }


    /** Browse */
    override fun qtMiscBrowse(): String {
        return """Browse"""
    }


    /** Change Note Type (Ctrl+N) */
    override fun qtMiscChangeNoteTypeCtrlandn(): String {
        return """Change Note Type (Ctrl+N)"""
    }


    /** Check the files in the media directory */
    override fun qtMiscCheckTheFilesInTheMedia(): String {
        return """Check the files in the media directory"""
    }


    /** Choose Deck */
    override fun qtMiscChooseDeck(): String {
        return """Choose Deck"""
    }


    /** Choose Note Type */
    override fun qtMiscChooseNoteType(): String {
        return """Choose Note Type"""
    }


    /** Closing... */
    override fun qtMiscClosing(): String {
        return """Closing..."""
    }


    /** Configure interface language and options */
    override fun qtMiscConfigureInterfaceLanguageAndOptions(): String {
        return """Configure interface language and options"""
    }


    /** Copy to Clipboard */
    override fun qtMiscCopyToClipboard(): String {
        return """Copy to Clipboard"""
    }


    /** Create Filtered Deck... */
    override fun qtMiscCreateFilteredDeck(): String {
        return """Create Filtered Deck..."""
    }


    /** Debug Console */
    override fun qtMiscDebugConsole(): String {
        return """Debug Console"""
    }


    /** Deck will be imported when a profile is opened. */
    override fun qtMiscDeckWillBeImportedWhenA(): String {
        return """Deck will be imported when a profile is opened."""
    }


    /** Downloading update: {$count}MB/{$total}MB */
    override fun qtMiscDownloadingUpdate(`count`: Int, `total`: Int): String {
        return """Downloading update: ${`count`}MB/${`total`}MB"""
    }


    /** Empty Cards... */
    override fun qtMiscEmptyCards(): String {
        return """Empty Cards..."""
    }


    /** Error */
    override fun qtMiscError(): String {
        return """Error"""
    }


    /** Error during startup: {$val} */
    override fun qtMiscErrorDuringStartup(`val`: TranslateArg): String {
        return """Error during startup: ${`val`}"""
    }


    /** Error loading '{$mode}' graphics driver. Please start Anki again to try the next driver. {$context} */
    override fun qtMiscErrorLoadingGraphicsDriver(`mode`: String, `context`: String): String {
        return """Error loading '${`mode`}' graphics driver. Please start Anki again to try the next driver. ${`context`}"""
    }


    /** If the existing instance of Anki is not responding, please close it using your task manager, or restart your computer. */
    override fun qtMiscIfInstanceIsNotResponding(): String {
        return """If the existing instance of Anki is not responding, please close it using your task manager, or restart your computer."""
    }


    /** Ignore this update */
    override fun qtMiscIgnoreThisUpdate(): String {
        return """Ignore this update"""
    }


    /** In order to ensure your collection works correctly when moved between devices, Anki requires your computer's internal clock to be set correctly. The internal clock can be wrong even if your system is showing the correct local time.<br><br>Please go to the time settings on your computer and check the following:<br><br>- AM/PM<br>- Clock drift<br>- Day, month and year<br>- Timezone<br>- Daylight savings<br><br>Difference to correct time: {$val}. */
    override fun qtMiscInOrderToEnsureYourCollection(`val`: TranslateArg): String {
        return """In order to ensure your collection works correctly when moved between devices, Anki requires your computer's internal clock to be set correctly. The internal clock can be wrong even if your system is showing the correct local time.<br><br>Please go to the time settings on your computer and check the following:<br><br>- AM/PM<br>- Clock drift<br>- Day, month and year<br>- Timezone<br>- Daylight savings<br><br>Difference to correct time: ${`val`}."""
    }


    /** Your video driver is incompatible. Please start Anki again, and Anki will switch to a slower, more compatible mode. */
    override fun qtMiscIncompatibleVideoDriver(): String {
        return """Your video driver is incompatible. Please start Anki again, and Anki will switch to a slower, more compatible mode."""
    }


    /** Invalid property found on card. Please use Tools>Check Database, and if the problem comes up again, please ask on the support site. */
    override fun qtMiscInvalidPropertyFoundOnCardPlease(): String {
        return """Invalid property found on card. Please use Tools>Check Database, and if the problem comes up again, please ask on the support site."""
    }


    /** Responsive layout enabled */
    override fun qtMiscLayoutAutoEnabled(): String {
        return """Responsive layout enabled"""
    }


    /** Horizontal layout enabled */
    override fun qtMiscLayoutHorizontalEnabled(): String {
        return """Horizontal layout enabled"""
    }


    /** Vertical layout enabled */
    override fun qtMiscLayoutVerticalEnabled(): String {
        return """Vertical layout enabled"""
    }


    /** Loading... */
    override fun qtMiscLoading(): String {
        return """Loading..."""
    }


    /** Manage */
    override fun qtMiscManage(): String {
        return """Manage"""
    }


    /** Manage Note Types */
    override fun qtMiscManageNoteTypes(): String {
        return """Manage Note Types"""
    }


    /** Name exists. */
    override fun qtMiscNameExists(): String {
        return """Name exists."""
    }


    /** No usable temporary folder found. Make sure C:\\temp exists or TEMP in your environment points to a valid, writable folder. */
    override fun qtMiscNoTempFolder(): String {
        return """No usable temporary folder found. Make sure C:\\temp exists or TEMP in your environment points to a valid, writable folder."""
    }


    /** <non-unicode text> */
    override fun qtMiscNonUnicodeText(): String {
        return """<non-unicode text>"""
    }


    /** Optimizing... */
    override fun qtMiscOptimizing(): String {
        return """Optimizing..."""
    }


    /** Please ensure a profile is open and Anki is not busy, then try again. */
    override fun qtMiscPleaseEnsureAProfileIsOpen(): String {
        return """Please ensure a profile is open and Anki is not busy, then try again."""
    }


    /** (please select 1 card) */
    override fun qtMiscPleaseSelect1Card(): String {
        return """(please select 1 card)"""
    }


    /** Please select a deck. */
    override fun qtMiscPleaseSelectADeck(): String {
        return """Please select a deck."""
    }


    /** Please use File>Import to import this file. */
    override fun qtMiscPleaseUseFileimportToImportThis(): String {
        return """Please use File>Import to import this file."""
    }


    /** Processing... */
    override fun qtMiscProcessing(): String {
        return """Processing..."""
    }


    /** Replace your collection with an earlier backup? */
    override fun qtMiscReplaceYourCollectionWithAnEarlier(): String {
        return """Replace your collection with an earlier backup?"""
    }


    /** Replace your collection with an earlier backup from {$val}? */
    override fun qtMiscReplaceYourCollectionWithAnEarlier2(`val`: TranslateArg): String {
        return """Replace your collection with an earlier backup from ${`val`}?"""
    }


    /** Revert to backup */
    override fun qtMiscRevertToBackup(): String {
        return """Revert to backup"""
    }


    /** {$count} seconds */
    override fun qtMiscSecond(`count`: Int): String {
        return """${`count`} seconds"""
    }


    /** "Segoe UI" */
    override fun qtMiscSegoeUi(): String {
        return """"Segoe UI""""
    }


    /** Shift key was held down. Skipping automatic syncing and add-on loading. */
    override fun qtMiscShiftKeyWasHeldDownSkipping(): String {
        return """Shift key was held down. Skipping automatic syncing and add-on loading."""
    }


    /** Shortcut key: Left arrow */
    override fun qtMiscShortcutKeyLeftArrow(): String {
        return """Shortcut key: Left arrow"""
    }


    /** Shortcut key: Right arrow or Enter */
    override fun qtMiscShortcutKeyRightArrowOrEnter(): String {
        return """Shortcut key: Right arrow or Enter"""
    }


    /** Stats */
    override fun qtMiscStats(): String {
        return """Stats"""
    }


    /** Study Deck... */
    override fun qtMiscStudyDeck(): String {
        return """Study Deck..."""
    }


    /** Sync */
    override fun qtMiscSync(): String {
        return """Sync"""
    }


    /** Target Deck (Ctrl+D) */
    override fun qtMiscTargetDeckCtrlandd(): String {
        return """Target Deck (Ctrl+D)"""
    }


    /** The following character can not be used: {$val} */
    override fun qtMiscTheFollowingCharacterCanNotBe(`val`: TranslateArg): String {
        return """The following character can not be used: ${`val`}"""
    }


    /** The requested change will require a full upload of the database when you next synchronize your collection. If you have reviews or other changes waiting on another device that haven't been synchronized here yet, they will be lost. Continue? */
    override fun qtMiscTheRequestedChangeWillRequireA(): String {
        return """The requested change will require a full upload of the database when you next synchronize your collection. If you have reviews or other changes waiting on another device that haven't been synchronized here yet, they will be lost. Continue?"""
    }


    /** There must be at least one profile. */
    override fun qtMiscThereMustBeAtLeastOne(): String {
        return """There must be at least one profile."""
    }


    /** This file exists. Are you sure you want to overwrite it? */
    override fun qtMiscThisFileExistsAreYouSure(): String {
        return """This file exists. Are you sure you want to overwrite it?"""
    }


    /** Unable to access Anki media folder. The permissions on your system's temporary folder may be incorrect. */
    override fun qtMiscUnableToAccessAnkiMediaFolder(): String {
        return """Unable to access Anki media folder. The permissions on your system's temporary folder may be incorrect."""
    }


    /** Unable to record. Please ensure a microphone is connected, and Anki has permission to use the microphone.
If other programs are using your microphone, closing them may help.

Original error: {$error} */
    override fun qtMiscUnableToRecord(`error`: String): String {
        return """Unable to record. Please ensure a microphone is connected, and Anki has permission to use the microphone.
If other programs are using your microphone, closing them may help.

Original error: ${`error`}"""
    }


    /** Unexpected response code: {$val} */
    override fun qtMiscUnexpectedResponseCode(`val`: TranslateArg): String {
        return """Unexpected response code: ${`val`}"""
    }


    /** Would you like to download it now? */
    override fun qtMiscWouldYouLikeToDownloadIt(): String {
        return """Would you like to download it now?"""
    }


    /** Your collection file appears to be corrupt. This can happen when the file is copied or moved while Anki is open, or when the collection is stored on a network or cloud drive. If problems persist after restarting your computer, please open an automatic backup from the profile screen. */
    override fun qtMiscYourCollectionFileAppearsToBe(): String {
        return """Your collection file appears to be corrupt. This can happen when the file is copied or moved while Anki is open, or when the collection is stored on a network or cloud drive. If problems persist after restarting your computer, please open an automatic backup from the profile screen."""
    }


    /** Your computer's storage may be full. Please delete some unneeded files, then try again. */
    override fun qtMiscYourComputersStorageMayBeFull(): String {
        return """Your computer's storage may be full. Please delete some unneeded files, then try again."""
    }


    /** Your firewall or antivirus program is preventing Anki from creating a connection to itself. Please add an exception for Anki. */
    override fun qtMiscYourFirewallOrAntivirusProgramIs(): String {
        return """Your firewall or antivirus program is preventing Anki from creating a connection to itself. Please add an exception for Anki."""
    }


    /** Always include question side when replaying audio */
    override fun schedulingAlwaysIncludeQuestionSideWhenReplaying(): String {
        return """Always include question side when replaying audio"""
    }


    /** {$amount}d */
    override fun schedulingAnswerButtonTimeDays(`amount`: Int): String {
        return """${`amount`}d"""
    }


    /** {$amount}h */
    override fun schedulingAnswerButtonTimeHours(`amount`: Int): String {
        return """${`amount`}h"""
    }


    /** {$amount}m */
    override fun schedulingAnswerButtonTimeMinutes(`amount`: Int): String {
        return """${`amount`}m"""
    }


    /** {$amount}mo */
    override fun schedulingAnswerButtonTimeMonths(`amount`: Int): String {
        return """${`amount`}mo"""
    }


    /** {$amount}s */
    override fun schedulingAnswerButtonTimeSeconds(`amount`: Int): String {
        return """${`amount`}s"""
    }


    /** {$amount}y */
    override fun schedulingAnswerButtonTimeYears(`amount`: Int): String {
        return """${`amount`}y"""
    }


    /** At least one step is required. */
    override fun schedulingAtLeastOneStepIsRequired(): String {
        return """At least one step is required."""
    }


    /** Automatically play audio */
    override fun schedulingAutomaticallyPlayAudio(): String {
        return """Automatically play audio"""
    }


    /** One or more cards were buried, and will be shown tomorrow. You can {$unburyThem} if you wish to see them immediately. */
    override fun schedulingBuriedCardsFound(`unburyThem`: String): String {
        return """One or more cards were buried, and will be shown tomorrow. You can ${`unburyThem`} if you wish to see them immediately."""
    }


    /** Bury related new cards until the next day */
    override fun schedulingBuryRelatedNewCardsUntilThe(): String {
        return """Bury related new cards until the next day"""
    }


    /** Bury related reviews until the next day */
    override fun schedulingBuryRelatedReviewsUntilTheNext(): String {
        return """Bury related reviews until the next day"""
    }


    /** Congratulations! You have finished this deck for now. */
    override fun schedulingCongratulationsFinished(): String {
        return """Congratulations! You have finished this deck for now."""
    }


    /** custom study */
    override fun schedulingCustomStudy(): String {
        return """custom study"""
    }


    /** days */
    override fun schedulingDays(): String {
        return """days"""
    }


    /** {$count} decks updated. */
    override fun schedulingDeckUpdated(`count`: Int): String {
        return """${`count`} decks updated."""
    }


    /** Description */
    override fun schedulingDescription(): String {
        return """Description"""
    }


    /** Easy bonus */
    override fun schedulingEasyBonus(): String {
        return """Easy bonus"""
    }


    /** Easy interval */
    override fun schedulingEasyInterval(): String {
        return """Easy interval"""
    }


    /** (end) */
    override fun schedulingEnd(): String {
        return """(end)"""
    }


    /** Reset {$cards} cards. */
    override fun schedulingForgotCards(`cards`: Int): String {
        return """Reset ${`cards`} cards."""
    }


    /** General */
    override fun schedulingGeneral(): String {
        return """General"""
    }


    /** Graded {$cards} cards. */
    override fun schedulingGradedCardsDone(`cards`: Int): String {
        return """Graded ${`cards`} cards."""
    }


    /** Graduating interval */
    override fun schedulingGraduatingInterval(): String {
        return """Graduating interval"""
    }


    /** Hard interval */
    override fun schedulingHardInterval(): String {
        return """Hard interval"""
    }


    /** If you wish to study outside of the regular schedule, you can use the {$customStudy} feature. */
    override fun schedulingHowToCustomStudy(`customStudy`: String): String {
        return """If you wish to study outside of the regular schedule, you can use the ${`customStudy`} feature."""
    }


    /** Ignore answer times longer than */
    override fun schedulingIgnoreAnswerTimesLongerThan(): String {
        return """Ignore answer times longer than"""
    }


    /** Interval modifier */
    override fun schedulingIntervalModifier(): String {
        return """Interval modifier"""
    }


    /** Lapses */
    override fun schedulingLapses(): String {
        return """Lapses"""
    }


    /** lapses */
    override fun schedulingLapses2(): String {
        return """lapses"""
    }


    /** There are {$remaining} learning cards due later today. */
    override fun schedulingLearnRemaining(`remaining`: Int): String {
        return """There are ${`remaining`} learning cards due later today."""
    }


    /** Learning */
    override fun schedulingLearning(): String {
        return """Learning"""
    }


    /** Leech action */
    override fun schedulingLeechAction(): String {
        return """Leech action"""
    }


    /** Leech threshold */
    override fun schedulingLeechThreshold(): String {
        return """Leech threshold"""
    }


    /** Maximum interval */
    override fun schedulingMaximumInterval(): String {
        return """Maximum interval"""
    }


    /** Maximum reviews/day */
    override fun schedulingMaximumReviewsday(): String {
        return """Maximum reviews/day"""
    }


    /** Minimum interval */
    override fun schedulingMinimumInterval(): String {
        return """Minimum interval"""
    }


    /** Mix new cards and reviews */
    override fun schedulingMixNewCardsAndReviews(): String {
        return """Mix new cards and reviews"""
    }


    /** New Cards */
    override fun schedulingNewCards(): String {
        return """New Cards"""
    }


    /** New cards/day */
    override fun schedulingNewCardsday(): String {
        return """New cards/day"""
    }


    /** New interval */
    override fun schedulingNewInterval(): String {
        return """New interval"""
    }


    /** New options group name: */
    override fun schedulingNewOptionsGroupName(): String {
        return """New options group name:"""
    }


    /** The next learning card will be ready in {$amount} hours. */
    override fun schedulingNextLearnDue(`unit`: String, `amount`: Int): String {
        return """The next learning card will be ready in ${`amount`} hours."""
    }


    /** Options group: */
    override fun schedulingOptionsGroup(): String {
        return """Options group:"""
    }


    /** Order */
    override fun schedulingOrder(): String {
        return """Order"""
    }


    /** (parent limit: {$val}) */
    override fun schedulingParentLimit(`val`: TranslateArg): String {
        return """(parent limit: ${`val`})"""
    }


    /** Reset repetition and lapse counts */
    override fun schedulingResetCounts(): String {
        return """Reset repetition and lapse counts"""
    }


    /** Restore original position where possible */
    override fun schedulingRestorePosition(): String {
        return """Restore original position where possible"""
    }


    /** Review */
    override fun schedulingReview(): String {
        return """Review"""
    }


    /** Reviews */
    override fun schedulingReviews(): String {
        return """Reviews"""
    }


    /** seconds */
    override fun schedulingSeconds(): String {
        return """seconds"""
    }


    /** Set all decks below {$val} to this option group? */
    override fun schedulingSetAllDecksBelowTo(`val`: TranslateArg): String {
        return """Set all decks below ${`val`} to this option group?"""
    }


    /** Set due date of {$cards} cards. */
    override fun schedulingSetDueDateDone(`cards`: Int): String {
        return """Set due date of ${`cards`} cards."""
    }


    /** Show cards in how many days? */
    override fun schedulingSetDueDatePrompt(`cards`: Int): String {
        return """Show cards in how many days?"""
    }


    /** 0 = today
1! = tomorrow + change interval to 1
3-7 = random choice of 3-7 days */
    override fun schedulingSetDueDatePromptHint(): String {
        return """0 = today
1! = tomorrow + change interval to 1
3-7 = random choice of 3-7 days"""
    }


    /** Set for all subdecks */
    override fun schedulingSetForAllSubdecks(): String {
        return """Set for all subdecks"""
    }


    /** Show on-screen timer */
    override fun schedulingShowAnswerTimer(): String {
        return """Show on-screen timer"""
    }


    /** Show new cards after reviews */
    override fun schedulingShowNewCardsAfterReviews(): String {
        return """Show new cards after reviews"""
    }


    /** Show new cards before reviews */
    override fun schedulingShowNewCardsBeforeReviews(): String {
        return """Show new cards before reviews"""
    }


    /** Show new cards in order added */
    override fun schedulingShowNewCardsInOrderAdded(): String {
        return """Show new cards in order added"""
    }


    /** Show new cards in random order */
    override fun schedulingShowNewCardsInRandomOrder(): String {
        return """Show new cards in random order"""
    }


    /** Starting ease */
    override fun schedulingStartingEase(): String {
        return """Starting ease"""
    }


    /** Steps (in minutes) */
    override fun schedulingStepsInMinutes(): String {
        return """Steps (in minutes)"""
    }


    /** Steps must be numbers. */
    override fun schedulingStepsMustBeNumbers(): String {
        return """Steps must be numbers."""
    }


    /** Tag Only */
    override fun schedulingTagOnly(): String {
        return """Tag Only"""
    }


    /** The default configuration can't be removed. */
    override fun schedulingTheDefaultConfigurationCantBeRemoved(): String {
        return """The default configuration can't be removed."""
    }


    /** {$amount} days */
    override fun schedulingTimeSpanDays(`amount`: Int): String {
        return """${`amount`} days"""
    }


    /** {$amount} hours */
    override fun schedulingTimeSpanHours(`amount`: Int): String {
        return """${`amount`} hours"""
    }


    /** {$amount} minutes */
    override fun schedulingTimeSpanMinutes(`amount`: Int): String {
        return """${`amount`} minutes"""
    }


    /** {$amount} months */
    override fun schedulingTimeSpanMonths(`amount`: Int): String {
        return """${`amount`} months"""
    }


    /** {$amount} seconds */
    override fun schedulingTimeSpanSeconds(`amount`: Int): String {
        return """${`amount`} seconds"""
    }


    /** {$amount} years */
    override fun schedulingTimeSpanYears(`amount`: Int): String {
        return """${`amount`} years"""
    }


    /** There are more new cards available, but the daily limit has been
reached. You can increase the limit in the options, but please
bear in mind that the more new cards you introduce, the higher
your short-term review workload will become. */
    override fun schedulingTodayNewLimitReached(): String {
        return """There are more new cards available, but the daily limit has been
reached. You can increase the limit in the options, but please
bear in mind that the more new cards you introduce, the higher
your short-term review workload will become."""
    }


    /** Today's review limit has been reached, but there are still cards
waiting to be reviewed. For optimum memory, consider increasing
the daily limit in the options. */
    override fun schedulingTodayReviewLimitReached(): String {
        return """Today's review limit has been reached, but there are still cards
waiting to be reviewed. For optimum memory, consider increasing
the daily limit in the options."""
    }


    /** unbury them */
    override fun schedulingUnburyThem(): String {
        return """unbury them"""
    }


    /** Update */
    override fun schedulingUpdateButton(): String {
        return """Update"""
    }


    /** Scheduler updated successfully. */
    override fun schedulingUpdateDone(): String {
        return """Scheduler updated successfully."""
    }


    /** Later */
    override fun schedulingUpdateLaterButton(): String {
        return """Later"""
    }


    /** Learn More */
    override fun schedulingUpdateMoreInfoButton(): String {
        return """Learn More"""
    }


    /** Your collection needs to be upgraded to the V2 scheduler.
Please select  before proceeding. */
    override fun schedulingUpdateRequired(): String {
        return """Your collection needs to be upgraded to the V2 scheduler.
Please select  before proceeding."""
    }


    /** Anki 2.1 comes with a new scheduler, which fixes a number of issues that previous Anki versions had. Updating to it is recommended. */
    override fun schedulingUpdateSoon(): String {
        return """Anki 2.1 comes with a new scheduler, which fixes a number of issues that previous Anki versions had. Updating to it is recommended."""
    }


    /** Your changes will affect multiple decks. If you wish to change only the current deck, please add a new options group first. */
    override fun schedulingYourChangesWillAffectMultipleDecks(): String {
        return """Your changes will affect multiple decks. If you wish to change only the current deck, please add a new options group first."""
    }


    /** Card Modified */
    override fun searchCardModified(): String {
        return """Card Modified"""
    }


    /** a group `(...)` was found, but there was nothing between the brackets to search for. If you want to search for literal brackets, wrap them in double quotes: `"( )"`. */
    override fun searchEmptyGroup(): String {
        return """a group `(...)` was found, but there was nothing between the brackets to search for. If you want to search for literal brackets, wrap them in double quotes: `"( )"`."""
    }


    /** a pair of double quotes `""` was found, but there was nothing between them to search for. If you want to search for literal double quotes, prepend backslashes: `\"\"`. */
    override fun searchEmptyQuote(): String {
        return """a pair of double quotes `""` was found, but there was nothing between them to search for. If you want to search for literal double quotes, prepend backslashes: `\"\"`."""
    }


    /** expected an answer button between 1-4 in "`{$context}`", but found "`{$provided}`". */
    override fun searchInvalidAnswerButton(`context`: String, `provided`: String): String {
        return """expected an answer button between 1-4 in "`${`context`}`", but found "`${`provided`}`"."""
    }


    /** `{$term}` was given an invalid argument '`{$argument}`'. */
    override fun searchInvalidArgument(`term`: String, `argument`: String): String {
        return """`${`term`}` was given an invalid argument '`${`argument`}`'."""
    }


    /** `flag:` must be followed by a valid flag number: `1` (red), `2` (orange), `3` (green), `4` (blue), `5` (pink), `6` (turquoise), `7` (purple) or `0` (no flag). */
    override fun searchInvalidFlag2(): String {
        return """`flag:` must be followed by a valid flag number: `1` (red), `2` (orange), `3` (green), `4` (blue), `5` (pink), `6` (turquoise), `7` (purple) or `0` (no flag)."""
    }


    /** expected a whole number less than or equal to 0 in "`{$context}`", but found "`{$provided}`". */
    override fun searchInvalidNegativeWholeNumber(`context`: String, `provided`: String): String {
        return """expected a whole number less than or equal to 0 in "`${`context`}`", but found "`${`provided`}`"."""
    }


    /** expected a number in "`{$context}`", but found "`{$provided}`". */
    override fun searchInvalidNumber(`context`: String, `provided`: String): String {
        return """expected a number in "`${`context`}`", but found "`${`provided`}`"."""
    }


    /** please check for typing mistakes. */
    override fun searchInvalidOther(): String {
        return """please check for typing mistakes."""
    }


    /** expected a positive whole number in "`{$context}`", but found "`{$provided}`". */
    override fun searchInvalidPositiveWholeNumber(`context`: String, `provided`: String): String {
        return """expected a positive whole number in "`${`context`}`", but found "`${`provided`}`"."""
    }


    /** `prop:{$val}` must be followed by one of the following comparison operators: `=`, `!=`, `<`, `>`, `<=` or `>=`. */
    override fun searchInvalidPropOperator(`val`: TranslateArg): String {
        return """`prop:${`val`}` must be followed by one of the following comparison operators: `=`, `!=`, `<`, `>`, `<=` or `>=`."""
    }


    /** Invalid search: {$reason} */
    override fun searchInvalidSearch(`reason`: String): String {
        return """Invalid search: ${`reason`}"""
    }


    /** expected a whole number in "`{$context}`", but found "`{$provided}`". */
    override fun searchInvalidWholeNumber(`context`: String, `provided`: String): String {
        return """expected a whole number in "`${`context`}`", but found "`${`provided`}`"."""
    }


    /** an `and` was found but it is not connecting two search terms. If you want to search for the word itself, wrap it in double quotes: `"and"`. */
    override fun searchMisplacedAnd(): String {
        return """an `and` was found but it is not connecting two search terms. If you want to search for the word itself, wrap it in double quotes: `"and"`."""
    }


    /** an `or` was found but it is not connecting two search terms. If you want to search for the word itself, wrap it in double quotes: `"or"`. */
    override fun searchMisplacedOr(): String {
        return """an `or` was found but it is not connecting two search terms. If you want to search for the word itself, wrap it in double quotes: `"or"`."""
    }


    /** a colon `:` was found, but there was no keyword preceding it. If you want to search for a literal `:`, prepend a backslash: `\:`. */
    override fun searchMissingKey(): String {
        return """a colon `:` was found, but there was no keyword preceding it. If you want to search for a literal `:`, prepend a backslash: `\:`."""
    }


    /** Note Modified */
    override fun searchNoteModified(): String {
        return """Note Modified"""
    }


    /** an opening bracket `(` was found, but there was no closing bracket `)` following it. If you want to search for a literal `(`, wrap it in double quotes or prepend a backslash: `"("` or `\(` . */
    override fun searchUnclosedGroup(): String {
        return """an opening bracket `(` was found, but there was no closing bracket `)` following it. If you want to search for a literal `(`, wrap it in double quotes or prepend a backslash: `"("` or `\(` ."""
    }


    /** an opening double quote `"` was found, but there was no second one to close it. If you want to search for a literal `"`, prepend a backslash: `\"`. */
    override fun searchUnclosedQuote(): String {
        return """an opening double quote `"` was found, but there was no second one to close it. If you want to search for a literal `"`, prepend a backslash: `\"`."""
    }


    /** the escape sequence `{$val}` is not defined. If you want to search for a literal backslash `\`, prepend another one: `\\`. */
    override fun searchUnknownEscape(`val`: TranslateArg): String {
        return """the escape sequence `${`val`}` is not defined. If you want to search for a literal backslash `\`, prepend another one: `\\`."""
    }


    /** a closing bracket `)` was found, but there was no opening bracket `(` preceding it. If you want to search for a literal `)`, wrap it in double quotes or prepend a backslash: `")"` or `\)`. */
    override fun searchUnopenedGroup(): String {
        return """a closing bracket `)` was found, but there was no opening bracket `(` preceding it. If you want to search for a literal `)`, wrap it in double quotes or prepend a backslash: `")"` or `\)`."""
    }


    /** View in browser */
    override fun searchViewInBrowser(): String {
        return """View in browser"""
    }


    /** The number of new cards you have added. */
    override fun statisticsAddedSubtitle(): String {
        return """The number of new cards you have added."""
    }


    /** Added */
    override fun statisticsAddedTitle(): String {
        return """Added"""
    }


    /** {$amount} of {$total} ({$percent}%) */
    override fun statisticsAmountOfTotalWithPercentage(`amount`: Int, `total`: Int, `percent`: TranslateArg): String {
        return """${`amount`} of ${`total`} (${`percent`}%)"""
    }


    /** Button */
    override fun statisticsAnswerButtonsButtonNumber(): String {
        return """Button"""
    }


    /** Times pressed */
    override fun statisticsAnswerButtonsButtonPressed(): String {
        return """Times pressed"""
    }


    /** The number of times you have pressed each button. */
    override fun statisticsAnswerButtonsSubtitle(): String {
        return """The number of times you have pressed each button."""
    }


    /** Answer Buttons */
    override fun statisticsAnswerButtonsTitle(): String {
        return """Answer Buttons"""
    }


    /** Average */
    override fun statisticsAverage(): String {
        return """Average"""
    }


    /** {$average-seconds}s () */
    override fun statisticsAverageAnswerTime(`averageSeconds`: Double, `cardsPerMinute`: Double): String {
        return """${`averageSeconds`}s ()"""
    }


    /** Average answer time */
    override fun statisticsAverageAnswerTimeLabel(): String {
        return """Average answer time"""
    }


    /** Average difficulty */
    override fun statisticsAverageDifficulty(): String {
        return """Average difficulty"""
    }


    /** Average ease */
    override fun statisticsAverageEase(): String {
        return """Average ease"""
    }


    /** Average for days studied */
    override fun statisticsAverageForDaysStudied(): String {
        return """Average for days studied"""
    }


    /** Average interval */
    override fun statisticsAverageInterval(): String {
        return """Average interval"""
    }


    /** Average over period */
    override fun statisticsAverageOverPeriod(): String {
        return """Average over period"""
    }


    /** Average retrievability */
    override fun statisticsAverageRetrievability(): String {
        return """Average retrievability"""
    }


    /** Average stability */
    override fun statisticsAverageStability(): String {
        return """Average stability"""
    }


    /** Backlog */
    override fun statisticsBacklogCheckbox(): String {
        return """Backlog"""
    }


    /** Calendar */
    override fun statisticsCalendarTitle(): String {
        return """Calendar"""
    }


    /** The higher the difficulty, the slower stability will increase. */
    override fun statisticsCardDifficultySubtitle2(): String {
        return """The higher the difficulty, the slower stability will increase."""
    }


    /** Card Difficulty */
    override fun statisticsCardDifficultyTitle(): String {
        return """Card Difficulty"""
    }


    /** {$cards} cards with {$percent} difficulty */
    override fun statisticsCardDifficultyTooltip(`cards`: Int, `percent`: TranslateArg): String {
        return """${`cards`} cards with ${`percent`} difficulty"""
    }


    /** The lower the ease, the more frequently a card will appear. */
    override fun statisticsCardEaseSubtitle(): String {
        return """The lower the ease, the more frequently a card will appear."""
    }


    /** Card Ease */
    override fun statisticsCardEaseTitle(): String {
        return """Card Ease"""
    }


    /** {$cards} cards with {$percent} ease */
    override fun statisticsCardEaseTooltip(`cards`: Int, `percent`: TranslateArg): String {
        return """${`cards`} cards with ${`percent`} ease"""
    }


    /** Card Retrievability */
    override fun statisticsCardRetrievabilityTitle(): String {
        return """Card Retrievability"""
    }


    /** The delay at which retrievability falls to 90%. */
    override fun statisticsCardStabilitySubtitle(): String {
        return """The delay at which retrievability falls to 90%."""
    }


    /** Card Stability */
    override fun statisticsCardStabilityTitle(): String {
        return """Card Stability"""
    }


    /** {$cards} cards */
    override fun statisticsCards(`cards`: Int): String {
        return """${`cards`} cards"""
    }


    /** {$cards} cards due */
    override fun statisticsCardsDue(`cards`: Int): String {
        return """${`cards`} cards due"""
    }


    /** {$count} cards/day */
    override fun statisticsCardsPerDay(`count`: Int): String {
        return """${`count`} cards/day"""
    }


    /** {$cards-per-minute} cards/minute */
    override fun statisticsCardsPerMin(`cardsPerMinute`: Double): String {
        return """${`cardsPerMinute`} cards/minute"""
    }


    /** Buried */
    override fun statisticsCountsBuriedCards(): String {
        return """Buried"""
    }


    /** Filtered */
    override fun statisticsCountsFilteredCards(): String {
        return """Filtered"""
    }


    /** Learning */
    override fun statisticsCountsLearningCards(): String {
        return """Learning"""
    }


    /** Mature */
    override fun statisticsCountsMatureCards(): String {
        return """Mature"""
    }


    /** New */
    override fun statisticsCountsNewCards(): String {
        return """New"""
    }


    /** Relearning */
    override fun statisticsCountsRelearningCards(): String {
        return """Relearning"""
    }


    /** Separate suspended/buried cards */
    override fun statisticsCountsSeparateSuspendedBuriedCards(): String {
        return """Separate suspended/buried cards"""
    }


    /** Suspended */
    override fun statisticsCountsSuspendedCards(): String {
        return """Suspended"""
    }


    /** Card Counts */
    override fun statisticsCountsTitle(): String {
        return """Card Counts"""
    }


    /** Total */
    override fun statisticsCountsTotalCards(): String {
        return """Total"""
    }


    /** Young */
    override fun statisticsCountsYoungCards(): String {
        return """Young"""
    }


    /** Daily load */
    override fun statisticsDailyLoad(): String {
        return """Daily load"""
    }


    /** {$daysStart}-{$daysEnd} days ago */
    override fun statisticsDaysAgoRange(`daysStart`: Int, `daysEnd`: Int): String {
        return """${`daysStart`}-${`daysEnd`} days ago"""
    }


    /** {$days} days ago */
    override fun statisticsDaysAgoSingle(`days`: Int): String {
        return """${`days`} days ago"""
    }


    /** Days studied */
    override fun statisticsDaysStudied(): String {
        return """Days studied"""
    }


    /** Due */
    override fun statisticsDueCount(): String {
        return """Due"""
    }


    /** Due */
    override fun statisticsDueDate(): String {
        return """Due"""
    }


    /** New #{$number} */
    override fun statisticsDueForNewCard(`number`: TranslateArg): String {
        return """New #${`number`}"""
    }


    /** Due tomorrow */
    override fun statisticsDueTomorrow(): String {
        return """Due tomorrow"""
    }


    /** {$amount}d */
    override fun statisticsElapsedTimeDays(`amount`: Int): String {
        return """${`amount`}d"""
    }


    /** {$amount}h */
    override fun statisticsElapsedTimeHours(`amount`: Int): String {
        return """${`amount`}h"""
    }


    /** {$amount}m */
    override fun statisticsElapsedTimeMinutes(`amount`: Int): String {
        return """${`amount`}m"""
    }


    /** {$amount}mo */
    override fun statisticsElapsedTimeMonths(`amount`: Int): String {
        return """${`amount`}mo"""
    }


    /** {$amount}s */
    override fun statisticsElapsedTimeSeconds(`amount`: Int): String {
        return """${`amount`}s"""
    }


    /** {$amount}y */
    override fun statisticsElapsedTimeYears(`amount`: Int): String {
        return """${`amount`}y"""
    }


    /** Estimated total knowledge */
    override fun statisticsEstimatedTotalKnowledge(): String {
        return """Estimated total knowledge"""
    }


    /** The number of reviews due in the future. */
    override fun statisticsFutureDueSubtitle(): String {
        return """The number of reviews due in the future."""
    }


    /** Future Due */
    override fun statisticsFutureDueTitle(): String {
        return """Future Due"""
    }


    /** {$correct}/{$total} correct ({$percent}%) */
    override fun statisticsHoursCorrect(`correct`: Int, `total`: Int, `percent`: TranslateArg): String {
        return """${`correct`}/${`total`} correct (${`percent`}%)"""
    }


    /** → (not 'Again') */
    override fun statisticsHoursCorrectInfo(): String {
        return """→ (not 'Again')"""
    }


    /** 📈 {$percent}% correct ({$reviews}) */
    override fun statisticsHoursCorrectReviews(`percent`: TranslateArg, `reviews`: Int): String {
        return """📈 ${`percent`}% correct (${`reviews`})"""
    }


    /** From {$hourStart}:00~{$hourEnd}:00 */
    override fun statisticsHoursRange(`hourStart`: Int, `hourEnd`: Int): String {
        return """From ${`hourStart`}:00~${`hourEnd`}:00"""
    }


    /** 📊 {$reviews} reviews */
    override fun statisticsHoursReviews(`reviews`: Int): String {
        return """📊 ${`reviews`} reviews"""
    }


    /** Review success rate for each hour of the day. */
    override fun statisticsHoursSubtitle(): String {
        return """Review success rate for each hour of the day."""
    }


    /** Hourly Breakdown */
    override fun statisticsHoursTitle(): String {
        return """Hourly Breakdown"""
    }


    /** In {$daysStart}-{$daysEnd} days */
    override fun statisticsInDaysRange(`daysStart`: Int, `daysEnd`: Int): String {
        return """In ${`daysStart`}-${`daysEnd`} days"""
    }


    /** In {$days} days */
    override fun statisticsInDaysSingle(`days`: Int): String {
        return """In ${`days`} days"""
    }


    /** in {$amount} days */
    override fun statisticsInTimeSpanDays(`amount`: Int): String {
        return """in ${`amount`} days"""
    }


    /** in {$amount} hours */
    override fun statisticsInTimeSpanHours(`amount`: Int): String {
        return """in ${`amount`} hours"""
    }


    /** in {$amount} minutes */
    override fun statisticsInTimeSpanMinutes(`amount`: Int): String {
        return """in ${`amount`} minutes"""
    }


    /** in {$amount} months */
    override fun statisticsInTimeSpanMonths(`amount`: Int): String {
        return """in ${`amount`} months"""
    }


    /** in {$amount} seconds */
    override fun statisticsInTimeSpanSeconds(`amount`: Int): String {
        return """in ${`amount`} seconds"""
    }


    /** in {$amount} years */
    override fun statisticsInTimeSpanYears(`amount`: Int): String {
        return """in ${`amount`} years"""
    }


    /** {$cards} cards with a {$daysStart}~{$daysEnd} day interval */
    override fun statisticsIntervalsDayRange(`cards`: Int, `daysStart`: Int, `daysEnd`: Int): String {
        return """${`cards`} cards with a ${`daysStart`}~${`daysEnd`} day interval"""
    }


    /** {$cards} cards with a {$day} day interval */
    override fun statisticsIntervalsDaySingle(`cards`: Int, `day`: TranslateArg): String {
        return """${`cards`} cards with a ${`day`} day interval"""
    }


    /** Delays until review cards are shown again. */
    override fun statisticsIntervalsSubtitle(): String {
        return """Delays until review cards are shown again."""
    }


    /** Review Intervals */
    override fun statisticsIntervalsTitle(): String {
        return """Review Intervals"""
    }


    /** Median difficulty */
    override fun statisticsMedianDifficulty(): String {
        return """Median difficulty"""
    }


    /** Median ease */
    override fun statisticsMedianEase(): String {
        return """Median ease"""
    }


    /** Median interval */
    override fun statisticsMedianInterval(): String {
        return """Median interval"""
    }


    /** Median stability */
    override fun statisticsMedianStability(): String {
        return """Median stability"""
    }


    /** {$memorized} cards memorized */
    override fun statisticsMemorized(`memorized`: String): String {
        return """${`memorized`} cards memorized"""
    }


    /** {$count} minutes/day */
    override fun statisticsMinutesPerDay(`count`: Int): String {
        return """${`count`} minutes/day"""
    }


    /** NO DATA */
    override fun statisticsNoData(): String {
        return """NO DATA"""
    }


    /** {$notes} notes */
    override fun statisticsNotes(`notes`: Int): String {
        return """${`notes`} notes"""
    }


    /** last 12 months */
    override fun statisticsRange1YearHistory(): String {
        return """last 12 months"""
    }


    /** all history */
    override fun statisticsRangeAllHistory(): String {
        return """all history"""
    }


    /** all */
    override fun statisticsRangeAllTime(): String {
        return """all"""
    }


    /** collection */
    override fun statisticsRangeCollection(): String {
        return """collection"""
    }


    /** deck */
    override fun statisticsRangeDeck(): String {
        return """deck"""
    }


    /** Search */
    override fun statisticsRangeSearch(): String {
        return """Search"""
    }


    /** The probability of recalling a card today. */
    override fun statisticsRetrievabilitySubtitle(): String {
        return """The probability of recalling a card today."""
    }


    /** {$cards} cards with {$percent} retrievability */
    override fun statisticsRetrievabilityTooltip(`cards`: Int, `percent`: TranslateArg): String {
        return """${`cards`} cards with ${`percent`} retrievability"""
    }


    /** {$reviews} reviews */
    override fun statisticsReviews(`reviews`: Int): String {
        return """${`reviews`} reviews"""
    }


    /** The number of questions you have answered. */
    override fun statisticsReviewsCountSubtitle(): String {
        return """The number of questions you have answered."""
    }


    /** {$count} reviews/day */
    override fun statisticsReviewsPerDay(`count`: Int): String {
        return """${`count`} reviews/day"""
    }


    /** Time */
    override fun statisticsReviewsTimeCheckbox(): String {
        return """Time"""
    }


    /** The time taken to answer the questions. */
    override fun statisticsReviewsTimeSubtitle(): String {
        return """The time taken to answer the questions."""
    }


    /** Reviews */
    override fun statisticsReviewsTitle(): String {
        return """Reviews"""
    }


    /** Running total */
    override fun statisticsRunningTotal(): String {
        return """Running total"""
    }


    /** Save PDF */
    override fun statisticsSavePdf(): String {
        return """Save PDF"""
    }


    /** Saved. */
    override fun statisticsSaved(): String {
        return """Saved."""
    }


    /** {$cards} cards with a {$daysStart}~{$daysEnd} day stability */
    override fun statisticsStabilityDayRange(`cards`: Int, `daysStart`: Int, `daysEnd`: Int): String {
        return """${`cards`} cards with a ${`daysStart`}~${`daysEnd`} day stability"""
    }


    /** {$cards} cards with a {$day} day stability */
    override fun statisticsStabilityDaySingle(`cards`: Int, `day`: TranslateArg): String {
        return """${`cards`} cards with a ${`day`} day stability"""
    }


    /** stats */
    override fun statisticsStats(): String {
        return """stats"""
    }


    /** Studied 
 today
({$secs-per-card}s/card) */
    override fun statisticsStudiedToday(`unit`: String, `secsPerCard`: Int, `amount`: Int, `cards`: Int): String {
        return """Studied 
 today
(${`secsPerCard`}s/card)"""
    }


    /** Statistics */
    override fun statisticsTitle(): String {
        return """Statistics"""
    }


    /** Again count: */
    override fun statisticsTodayAgainCount(): String {
        return """Again count:"""
    }


    /** Correct answers on mature cards: {$correct}/{$total} ({$percent}%) */
    override fun statisticsTodayCorrectMature(`correct`: Int, `total`: Int, `percent`: TranslateArg): String {
        return """Correct answers on mature cards: ${`correct`}/${`total`} (${`percent`}%)"""
    }


    /** No cards have been studied today. */
    override fun statisticsTodayNoCards(): String {
        return """No cards have been studied today."""
    }


    /** No mature cards were studied today. */
    override fun statisticsTodayNoMatureCards(): String {
        return """No mature cards were studied today."""
    }


    /** Today */
    override fun statisticsTodayTitle(): String {
        return """Today"""
    }


    /** Learn: {$learnCount}, Review: {$reviewCount}, Relearn: {$relearnCount}, Filtered: {$filteredCount} */
    override fun statisticsTodayTypeCounts(`learnCount`: Int, `reviewCount`: Int, `relearnCount`: Int, `filteredCount`: Int): String {
        return """Learn: ${`learnCount`}, Review: ${`reviewCount`}, Relearn: ${`relearnCount`}, Filtered: ${`filteredCount`}"""
    }


    /** Total */
    override fun statisticsTotal(): String {
        return """Total"""
    }


    /** All */
    override fun statisticsTrueRetentionAll(): String {
        return """All"""
    }


    /** All time */
    override fun statisticsTrueRetentionAllTime(): String {
        return """All time"""
    }


    /** Count */
    override fun statisticsTrueRetentionCount(): String {
        return """Count"""
    }


    /** Fail */
    override fun statisticsTrueRetentionFail(): String {
        return """Fail"""
    }


    /** Mature */
    override fun statisticsTrueRetentionMature(): String {
        return """Mature"""
    }


    /** Last month */
    override fun statisticsTrueRetentionMonth(): String {
        return """Last month"""
    }


    /** N/A */
    override fun statisticsTrueRetentionNotApplicable(): String {
        return """N/A"""
    }


    /** Pass */
    override fun statisticsTrueRetentionPass(): String {
        return """Pass"""
    }


    /** Range */
    override fun statisticsTrueRetentionRange(): String {
        return """Range"""
    }


    /** Retention */
    override fun statisticsTrueRetentionRetention(): String {
        return """Retention"""
    }


    /** Pass rate of cards with an interval ≥ 1 day. */
    override fun statisticsTrueRetentionSubtitle(): String {
        return """Pass rate of cards with an interval ≥ 1 day."""
    }


    /** Retention */
    override fun statisticsTrueRetentionTitle(): String {
        return """Retention"""
    }


    /** Today */
    override fun statisticsTrueRetentionToday(): String {
        return """Today"""
    }


    /** If you are using FSRS, your retention is expected to be close to your desired retention. Please keep in mind that data for a single day is noisy, so it's better to look at monthly data. */
    override fun statisticsTrueRetentionTooltip(): String {
        return """If you are using FSRS, your retention is expected to be close to your desired retention. Please keep in mind that data for a single day is noisy, so it's better to look at monthly data."""
    }


    /** Total */
    override fun statisticsTrueRetentionTotal(): String {
        return """Total"""
    }


    /** Last week */
    override fun statisticsTrueRetentionWeek(): String {
        return """Last week"""
    }


    /** Last year */
    override fun statisticsTrueRetentionYear(): String {
        return """Last year"""
    }


    /** Yesterday */
    override fun statisticsTrueRetentionYesterday(): String {
        return """Yesterday"""
    }


    /** Young */
    override fun statisticsTrueRetentionYoung(): String {
        return """Young"""
    }


    /** Again */
    override fun studyingAgain(): String {
        return """Again"""
    }


    /** All Buried Cards */
    override fun studyingAllBuriedCards(): String {
        return """All Buried Cards"""
    }


    /** Answer time elapsed */
    override fun studyingAnswerTimeElapsed(): String {
        return """Answer time elapsed"""
    }


    /** Audio -5s */
    override fun studyingAudio5s(): String {
        return """Audio -5s"""
    }


    /** Audio +5s */
    override fun studyingAudioAnd5s(): String {
        return """Audio +5s"""
    }


    /** Buried Siblings */
    override fun studyingBuriedSiblings(): String {
        return """Buried Siblings"""
    }


    /** Bury */
    override fun studyingBury(): String {
        return """Bury"""
    }


    /** Bury Card */
    override fun studyingBuryCard(): String {
        return """Bury Card"""
    }


    /** Bury Note */
    override fun studyingBuryNote(): String {
        return """Bury Note"""
    }


    /** {$count} cards studied in */
    override fun studyingCardStudiedIn(`count`: Int): String {
        return """${`count`} cards studied in"""
    }


    /** {$cards} cards studied in
{$minutes} minutes. */
    override fun studyingCardStudiedInMinute(`cards`: Int, `minutes`: String): String {
        return """${`cards`} cards studied in
${`minutes`} minutes."""
    }


    /** Card suspended. */
    override fun studyingCardSuspended(): String {
        return """Card suspended."""
    }


    /** Card was a leech. */
    override fun studyingCardWasALeech(): String {
        return """Card was a leech."""
    }


    /** {$count} cards buried. */
    override fun studyingCardsBuried(`count`: Int): String {
        return """${`count`} cards buried."""
    }


    /** Cards will be automatically returned to their original decks after you review them. */
    override fun studyingCardsWillBeAutomaticallyReturnedTo(): String {
        return """Cards will be automatically returned to their original decks after you review them."""
    }


    /** Continue */
    override fun studyingContinue(): String {
        return """Continue"""
    }


    /** Counts differ from the deck list, because burying is enabled. Some cards have been excluded, and others may have taken their place. */
    override fun studyingCountsDiffer(): String {
        return """Counts differ from the deck list, because burying is enabled. Some cards have been excluded, and others may have taken their place."""
    }


    /** Delete Note */
    override fun studyingDeleteNote(): String {
        return """Delete Note"""
    }


    /** Deleting this deck from the deck list will return all remaining cards to their original deck. */
    override fun studyingDeletingThisDeckFromTheDeck(): String {
        return """Deleting this deck from the deck list will return all remaining cards to their original deck."""
    }


    /** Easy */
    override fun studyingEasy(): String {
        return """Easy"""
    }


    /** Edit */
    override fun studyingEdit(): String {
        return """Edit"""
    }


    /** Empty */
    override fun studyingEmpty(): String {
        return """Empty"""
    }


    /** Finish */
    override fun studyingFinish(): String {
        return """Finish"""
    }


    /** Flag Card */
    override fun studyingFlagCard(): String {
        return """Flag Card"""
    }


    /** Good */
    override fun studyingGood(): String {
        return """Good"""
    }


    /** Hard */
    override fun studyingHard(): String {
        return """Hard"""
    }


    /** It has been suspended. */
    override fun studyingItHasBeenSuspended(): String {
        return """It has been suspended."""
    }


    /** Manually Buried Cards */
    override fun studyingManuallyBuriedCards(): String {
        return """Manually Buried Cards"""
    }


    /** Mark Note */
    override fun studyingMarkNote(): String {
        return """Mark Note"""
    }


    /** {$count} minutes. */
    override fun studyingMinute(`count`: Int): String {
        return """${`count`} minutes."""
    }


    /** More */
    override fun studyingMore(): String {
        return """More"""
    }


    /** No cards are due yet. */
    override fun studyingNoCardsAreDueYet(): String {
        return """No cards are due yet."""
    }


    /** Note suspended. */
    override fun studyingNoteSuspended(): String {
        return """Note suspended."""
    }


    /** Pause Audio */
    override fun studyingPauseAudio(): String {
        return """Pause Audio"""
    }


    /** Please run Tools>Empty Cards */
    override fun studyingPleaseRunToolsemptyCards(): String {
        return """Please run Tools>Empty Cards"""
    }


    /** Question time elapsed */
    override fun studyingQuestionTimeElapsed(): String {
        return """Question time elapsed"""
    }


    /** Record Own Voice */
    override fun studyingRecordOwnVoice(): String {
        return """Record Own Voice"""
    }


    /** Replay Own Voice */
    override fun studyingReplayOwnVoice(): String {
        return """Replay Own Voice"""
    }


    /** Show Answer */
    override fun studyingShowAnswer(): String {
        return """Show Answer"""
    }


    /** Space */
    override fun studyingSpace(): String {
        return """Space"""
    }


    /** Study Now */
    override fun studyingStudyNow(): String {
        return """Study Now"""
    }


    /** Suspend */
    override fun studyingSuspend(): String {
        return """Suspend"""
    }


    /** Suspend Note */
    override fun studyingSuspendNote(): String {
        return """Suspend Note"""
    }


    /** This is a special deck for studying outside of the normal schedule. */
    override fun studyingThisIsASpecialDeckFor(): String {
        return """This is a special deck for studying outside of the normal schedule."""
    }


    /** To Review */
    override fun studyingToReview(): String {
        return """To Review"""
    }


    /** Type answer: unknown field {$val} */
    override fun studyingTypeAnswerUnknownField(`val`: TranslateArg): String {
        return """Type answer: unknown field ${`val`}"""
    }


    /** Unbury */
    override fun studyingUnbury(): String {
        return """Unbury"""
    }


    /** What would you like to unbury? */
    override fun studyingWhatWouldYouLikeToUnbury(): String {
        return """What would you like to unbury?"""
    }


    /** You haven't recorded your voice yet. */
    override fun studyingYouHaventRecordedYourVoiceYet(): String {
        return """You haven't recorded your voice yet."""
    }


    /** Abort */
    override fun syncAbortButton(): String {
        return """Abort"""
    }


    /** <h1>Account Required</h1>
A free account is required to keep your collection synchronized. Please <a href="{$link}">sign up</a> for an account, then enter your details below. */
    override fun syncAccountRequired(`link`: String): String {
        return """<h1>Account Required</h1>
A free account is required to keep your collection synchronized. Please <a href="${`link`}">sign up</a> for an account, then enter your details below."""
    }


    /** Added/modified: {$up}↑ {$down}↓ */
    override fun syncAddedUpdatedCount(`up`: TranslateArg, `down`: TranslateArg): String {
        return """Added/modified: ${`up`}↑ ${`down`}↓"""
    }


    /** AnkiHub Add-on Installation */
    override fun syncAnkihubAddonInstallation(): String {
        return """AnkiHub Add-on Installation"""
    }


    /** AnkiHub Login */
    override fun syncAnkihubDialogHeading(): String {
        return """AnkiHub Login"""
    }


    /** Unable to log in to AnkiHub with the provided credentials. */
    override fun syncAnkihubLoginFailed(): String {
        return """Unable to log in to AnkiHub with the provided credentials."""
    }


    /** Username or Email: */
    override fun syncAnkihubUsernameLabel(): String {
        return """Username or Email:"""
    }


    /** Email: */
    override fun syncAnkiwebIdLabel(): String {
        return """Email:"""
    }


    /** Cancel */
    override fun syncCancelButton(): String {
        return """Cancel"""
    }


    /** Checking... */
    override fun syncChecking(): String {
        return """Checking..."""
    }


    /** Your Anki version is too old. Please update to the latest version to continue syncing. */
    override fun syncClientTooOld(): String {
        return """Your Anki version is too old. Please update to the latest version to continue syncing."""
    }


    /** Unable to sync - your clock is not set to the correct time. */
    override fun syncClockOff(): String {
        return """Unable to sync - your clock is not set to the correct time."""
    }


    /** Collection sync complete. */
    override fun syncCollectionComplete(): String {
        return """Collection sync complete."""
    }


    /** Local collection has no cards. Download from AnkiWeb? */
    override fun syncConfirmEmptyDownload(): String {
        return """Local collection has no cards. Download from AnkiWeb?"""
    }


    /** AnkiWeb collection has no cards. Replace it with local collection? */
    override fun syncConfirmEmptyUpload(): String {
        return """AnkiWeb collection has no cards. Replace it with local collection?"""
    }


    /** Only one copy of Anki can sync to your account at once. Please wait a few minutes, then try again. */
    override fun syncConflict(): String {
        return """Only one copy of Anki can sync to your account at once. Please wait a few minutes, then try again."""
    }


    /** Your decks here and on AnkiWeb differ in such a way that they can't be merged together, so it's necessary to overwrite the decks on one side with the decks from the other.

If you choose download, Anki will fetch the collection from AnkiWeb, and any changes you have made on this device since the last sync will be lost.

If you choose upload, Anki will send this device's data to AnkiWeb, and any changes that are waiting on AnkiWeb will be lost.

After all devices are in sync, future reviews and added cards can be merged automatically. */
    override fun syncConflictExplanation(): String {
        return """Your decks here and on AnkiWeb differ in such a way that they can't be merged together, so it's necessary to overwrite the decks on one side with the decks from the other.

If you choose download, Anki will fetch the collection from AnkiWeb, and any changes you have made on this device since the last sync will be lost.

If you choose upload, Anki will send this device's data to AnkiWeb, and any changes that are waiting on AnkiWeb will be lost.

After all devices are in sync, future reviews and added cards can be merged automatically."""
    }


    /** There is a conflict between decks on this device and AnkiWeb. You must choose which version to keep:

- Select **** to replace decks here with AnkiWeb’s version. You will lose any changes you made on this device since your last sync.
- Select **** to overwrite AnkiWeb’s versions with decks from this device, and delete any changes on AnkiWeb.

Once the conflict is resolved, syncing will work as usual. */
    override fun syncConflictExplanation2(): String {
        return """There is a conflict between decks on this device and AnkiWeb. You must choose which version to keep:

- Select **** to replace decks here with AnkiWeb’s version. You will lose any changes you made on this device since your last sync.
- Select **** to overwrite AnkiWeb’s versions with decks from this device, and delete any changes on AnkiWeb.

Once the conflict is resolved, syncing will work as usual."""
    }


    /** Connecting... */
    override fun syncConnecting(): String {
        return """Connecting..."""
    }


    /** Download from AnkiWeb */
    override fun syncDownloadFromAnkiweb(): String {
        return """Download from AnkiWeb"""
    }


    /** Downloading from AnkiWeb... */
    override fun syncDownloadingFromAnkiweb(): String {
        return """Downloading from AnkiWeb..."""
    }


    /** Log In */
    override fun syncLogInButton(): String {
        return """Log In"""
    }


    /** Log Out */
    override fun syncLogOutButton(): String {
        return """Log Out"""
    }


    /** Media sync aborted. */
    override fun syncMediaAborted(): String {
        return """Media sync aborted."""
    }


    /** Media sync aborting... */
    override fun syncMediaAborting(): String {
        return """Media sync aborting..."""
    }


    /** Added: {$up}↑ {$down}↓ */
    override fun syncMediaAddedCount(`up`: TranslateArg, `down`: TranslateArg): String {
        return """Added: ${`up`}↑ ${`down`}↓"""
    }


    /** Checked: {$count} */
    override fun syncMediaCheckedCount(`count`: Int): String {
        return """Checked: ${`count`}"""
    }


    /** Media sync complete. */
    override fun syncMediaComplete(): String {
        return """Media sync complete."""
    }


    /** Media sync disabled. */
    override fun syncMediaDisabled(): String {
        return """Media sync disabled."""
    }


    /** Media sync failed. */
    override fun syncMediaFailed(): String {
        return """Media sync failed."""
    }


    /** Media Log */
    override fun syncMediaLogButton(): String {
        return """Media Log"""
    }


    /** Media Sync Log */
    override fun syncMediaLogTitle(): String {
        return """Media Sync Log"""
    }


    /** Removed: {$up}↑ {$down}↓ */
    override fun syncMediaRemovedCount(`up`: TranslateArg, `down`: TranslateArg): String {
        return """Removed: ${`up`}↑ ${`down`}↓"""
    }


    /** Media sync starting... */
    override fun syncMediaStarting(): String {
        return """Media sync starting..."""
    }


    /** Anki is currently syncing. Please wait for the sync to complete, then try again. */
    override fun syncMustWaitForEnd(): String {
        return """Anki is currently syncing. Please wait for the sync to complete, then try again."""
    }


    /** Password: */
    override fun syncPasswordLabel(): String {
        return """Password:"""
    }


    /** Please sync again. If this message keeps appearing, please post on the support site. */
    override fun syncResyncRequired(): String {
        return """Please sync again. If this message keeps appearing, please post on the support site."""
    }


    /** Please use the Check Database function, then sync again. If problems persist, please force a one-way sync in the preferences screen. */
    override fun syncSanityCheckFailed(): String {
        return """Please use the Check Database function, then sync again. If problems persist, please force a one-way sync in the preferences screen."""
    }


    /** AnkiWeb encountered a problem. Please try again in a few minutes. */
    override fun syncServerError(): String {
        return """AnkiWeb encountered a problem. Please try again in a few minutes."""
    }


    /** Sign in */
    override fun syncSignIn(): String {
        return """Sign in"""
    }


    /** Syncing... */
    override fun syncSyncing(): String {
        return """Syncing..."""
    }


    /** Upload to AnkiWeb */
    override fun syncUploadToAnkiweb(): String {
        return """Upload to AnkiWeb"""
    }


    /** Your collection file is too large to send to AnkiWeb. You can reduce its size by removing any unwanted decks (optionally exporting them first), and then using Check Database to shrink the file size down.

{$details} (uncompressed) */
    override fun syncUploadTooLarge(`details`: String): String {
        return """Your collection file is too large to send to AnkiWeb. You can reduce its size by removing any unwanted decks (optionally exporting them first), and then using Check Database to shrink the file size down.

${`details`} (uncompressed)"""
    }


    /** Uploading to AnkiWeb... */
    override fun syncUploadingToAnkiweb(): String {
        return """Uploading to AnkiWeb..."""
    }


    /** Email or password was incorrect; please try again. */
    override fun syncWrongPass(): String {
        return """Email or password was incorrect; please try again."""
    }


    /** {$action} redone */
    override fun undoActionRedone(`action`: String): String {
        return """${`action`} redone"""
    }


    /** {$action} undone */
    override fun undoActionUndone(`action`: String): String {
        return """${`action`} undone"""
    }


    /** Redo */
    override fun undoRedo(): String {
        return """Redo"""
    }


    /** Redo {$action} */
    override fun undoRedoAction(`action`: String): String {
        return """Redo ${`action`}"""
    }


    /** Undo */
    override fun undoUndo(): String {
        return """Undo"""
    }


    /** Undo {$val} */
    override fun undoUndoAction(`val`: TranslateArg): String {
        return """Undo ${`val`}"""
    }

}