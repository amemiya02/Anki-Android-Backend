// SPDX-License-Identifier: GPL-3.0-or-later

package net.ankiweb.rsdroid.database

import android.content.ContentResolver
import android.database.CharArrayBuffer
import android.database.ContentObserver
import android.database.Cursor
import android.database.DataSetObserver
import android.net.Uri
import android.os.Bundle
import org.slf4j.LoggerFactory

private val logger = LoggerFactory.getLogger(AnkiDatabaseCursor::class.java)

/**
 * Base class for all database cursors, abstracting database methods to a common interface
 * Throwing on non-database-related cursor-methods
 *
 * This is useful because cursors are an android-specific implementation and not a database-specific
 * implementation, and many of the methods are not relevant.
 */
abstract class AnkiDatabaseCursor : Cursor {
    override fun isFirst(): Boolean = position == 0

    override fun isBeforeFirst(): Boolean = position < 0

    abstract override fun getCount(): Int

    abstract override fun getPosition(): Int

    abstract override fun getColumnIndex(columnName: String): Int

    @Throws(IllegalArgumentException::class)
    abstract override fun getColumnIndexOrThrow(columnName: String): Int

    abstract override fun getColumnName(columnIndex: Int): String

    abstract override fun getColumnNames(): Array<String>

    abstract override fun getColumnCount(): Int

    abstract override fun getString(columnIndex: Int): String?

    abstract override fun getShort(columnIndex: Int): Short

    abstract override fun getInt(columnIndex: Int): Int

    abstract override fun getLong(columnIndex: Int): Long

    abstract override fun getFloat(columnIndex: Int): Float

    abstract override fun getDouble(columnIndex: Int): Double

    abstract override fun isNull(columnIndex: Int): Boolean

    abstract override fun close()

    abstract override fun isClosed(): Boolean

    abstract override fun getType(columnIndex: Int): Int

    override fun getBlob(columnIndex: Int): ByteArray = throw NotImplementedException()

    override fun setNotificationUri(
        cr: ContentResolver,
        uri: Uri,
    ): Unit = throw NotImplementedException()

    @Deprecated("Deprecated in Java")
    override fun deactivate() {
        logger.warn("deactivate - not implemented - throwing")
        throw NotImplementedException()
    }

    override fun copyStringToBuffer(
        columnIndex: Int,
        buffer: CharArrayBuffer,
    ): Unit = throw NotImplementedException()

    @Deprecated("Deprecated in Java")
    override fun requery(): Boolean {
        logger.warn("requery - not implemented - throwing")
        throw NotImplementedException()
    }

    override fun getNotificationUri(): Uri = throw NotImplementedException()

    override fun getWantsAllOnMoveCalls(): Boolean = false

    override fun setExtras(extras: Bundle): Unit = throw NotImplementedException()

    override fun getExtras(): Bundle = throw NotImplementedException()

    override fun respond(extras: Bundle): Bundle = throw NotImplementedException()

    abstract override fun moveToPosition(nextPositionGlobal: Int): Boolean

    override fun registerContentObserver(observer: ContentObserver) {
        logger.warn("Not implemented: registerContentObserver - shouldn't matter unless requery() is called")
    }

    override fun unregisterContentObserver(observer: ContentObserver) {
        logger.warn("Not implemented: unregisterContentObserver - shouldn't matter unless requery() is called")
    }

    override fun registerDataSetObserver(observer: DataSetObserver) {
        logger.warn("Not implemented: registerDataSetObserver - shouldn't matter unless requery() is called")
    }

    override fun unregisterDataSetObserver(observer: DataSetObserver) {
        logger.warn("Not implemented: unregisterDataSetObserver - shouldn't matter unless requery() is called")
    }

    override fun isLast(): Boolean = position == lastPosition

    override fun isAfterLast(): Boolean = position >= count

    override fun move(offset: Int): Boolean = moveToPosition(position + offset)

    override fun moveToLast(): Boolean {
        val toMoveTo = lastPosition
        return moveToPosition(toMoveTo)
    }

    override fun moveToFirst(): Boolean = moveToPosition(0)

    override fun moveToNext(): Boolean {
        val toMoveTo = position + 1
        return moveToPosition(toMoveTo)
    }

    override fun moveToPrevious(): Boolean {
        val toMoveTo = position - 1
        return moveToPosition(toMoveTo)
    }

    protected val lastPosition: Int
        get() = count - 1
}
